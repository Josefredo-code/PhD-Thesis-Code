%% ============================================================
%  Generator Torque Curve - NREL 5 MW
% ============================================================

clear; clc;

%% ============================================================
% FIGURE STYLE
% ============================================================

axesFontSize   = 16;
legendFontSize = 14;
colourbarSize  = 14;
lineWidth      = 2.4;

figureWidth  = 20;  % cm
figureHeight = 14;  % cm

set(groot, 'DefaultAxesFontSize', axesFontSize);
set(groot, 'DefaultTextInterpreter', 'latex');
set(groot, 'DefaultAxesTickLabelInterpreter', 'latex');
set(groot, 'DefaultLegendInterpreter', 'latex');
set(groot, 'DefaultLegendFontSize', legendFontSize);

% Keep axis labels the same size as the axes text
set(groot, 'DefaultAxesLabelFontSizeMultiplier', 1.0);

%% ============================================================
%  COLOUR PALETTE
% ============================================================

green_colors = [
    0.05 0.30 0.20;
    0.20 0.50 0.35;
    0.55 0.75 0.60
];

blue_colors = [
    0.10 0.20 0.40;
    0.25 0.45 0.70;
    0.55 0.70 0.85
];

%% ============================================================
%  TURBINE PARAMETERS
% ============================================================

rho        = 1.225;
R          = 63;
lambda_opt = 7.55;
Cp_max     = 0.48;

%% ---- Wind-speed regions ----
v_cut_in  = 3;
v_rated   = 11.4;
v_cut_out = 25;

%% ---- Wind-speed vector ----
v = linspace(0,30,500);

%% ---- Torque constant ----
K = (pi*rho*R^5*Cp_max)/(2*lambda_opt^3);

%% ---- Rotor speed ----
omega_r = lambda_opt .* v ./ R;

%% ---- Region 2 torque ----
tau_region2 = K .* omega_r.^2;

%% ---- Initialise torque ----
torque = zeros(size(v));

idx_R1 = v < v_cut_in;
idx_R2 = (v >= v_cut_in) & (v < v_rated);
idx_R3 = (v >= v_rated) & (v <= v_cut_out);
idx_R4 = v > v_cut_out;

torque(idx_R1) = 0;
torque(idx_R2) = tau_region2(idx_R2);

rated_torque = max(tau_region2(idx_R2));

torque(idx_R3) = rated_torque;
torque(idx_R4) = 0;

%% ============================================================
%  PLOTTING
% ============================================================

figure( ...
    'Color','w', ...
    'Name','NREL 5 MW Generator Torque Curve', ...
    'Units','centimeters', ...
    'Position',[2 2 figureWidth figureHeight]);

hold on;
grid on;
box on;

torque_color = blue_colors(1,:);
region_color = [0.40 0.40 0.40];
limit_color  = [0.25 0.25 0.25];

plot( ...
    v,torque, ...
    'Color',torque_color, ...
    'LineWidth',lineWidth);

xline(v_cut_in,'--', ...
    'Color',limit_color, ...
    'LineWidth',1.5, ...
    'HandleVisibility','off');

xline(v_rated,'--', ...
    'Color',limit_color, ...
    'LineWidth',1.5, ...
    'HandleVisibility','off');

xline(v_cut_out,'--', ...
    'Color',limit_color, ...
    'LineWidth',1.5, ...
    'HandleVisibility','off');

%% ---- Region annotations ----
y_text = 0.90*rated_torque;

text(6.5,y_text,'Region 2', ...
    'Color',region_color, ...
    'FontSize',axesFontSize, ...
    'HorizontalAlignment','center');

text(18,y_text,'Region 3', ...
    'Color',region_color, ...
    'FontSize',axesFontSize, ...
    'HorizontalAlignment','center');

text(27.5,y_text,'Region 4', ...
    'Color',region_color, ...
    'FontSize',axesFontSize, ...
    'HorizontalAlignment','center');

%% ---- Axis labels ----
xlabel('Wind Speed [m/s]');
ylabel('Generator Torque [N\,m]');

xlim([0 30]);
ylim([0 4.1e6]);

%% ---- Axis appearance ----
ax = gca;
ax.LineWidth = 1.0;
ax.GridAlpha = 0.18;
ax.MinorGridAlpha = 0.10;

%% ============================================================
%  EXPORT
% ============================================================

fileName = 'TorqueCurveNREL5MW.pdf';

exportgraphics( ...
    gcf, ...
    fileName, ...
    'ContentType','vector', ...
    'BackgroundColor','white');

disp(['Saved: ',fullfile(pwd,fileName)]);