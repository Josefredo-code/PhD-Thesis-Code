function [S,Hw,Pwave,Te] = PiersonMoskowitz(w,Tp,Hs)
% PIERSONMOSKOWITZ
% Generates a Pierson-Moskowitz wave spectrum.
%
% Inputs:
%   w  - Angular frequency vector [rad/s]
%   Tp - Peak period [s]
%   Hs - Significant wave height [m]
%
% Outputs:
%   S      - Spectral density [m^2/Hz]
%   Hw     - Wave component amplitudes [m]
%   Pwave  - Wave power per unit crest width [W/m]
%   Te     - Energy period [s]

nw = length(w);

% Convert angular frequency to frequency [Hz]
f = w/(2*pi);

% Pierson-Moskowitz parameters expressed in terms of Hs and Tp
A = (5/16)*Hs^2/Tp^4;
B = (5/4)/Tp^4;

m0    = 0;
m_1   = 0;
Pwave = 0;

Hw = zeros(1,nw);
S  = zeros(1,nw);

%% ---- Pierson-Moskowitz spectrum ----
for i = 2:nw

    fc = 0.5*(f(i) + f(i-1));
    df = f(i) - f(i-1);

    S(i) = A/fc^5 * exp(-B/fc^4);

    % Spectral moments
    m0  = m0  + S(i)*df;
    m_1 = m_1 + S(i)/fc*df;
end

%% ---- Normalise spectrum to prescribed Hs ----
% Enforces Hs = 4*sqrt(m0)
alpha = Hs^2/(16*m0);

m0  = 0;
m_1 = 0;

for i = 2:nw

    df = f(i) - f(i-1);

    S(i) = alpha*S(i);

    % Wave amplitude of each discrete component
    Hw(i) = sqrt(2*S(i)*df);

    % Recalculate spectral moments after normalisation
    m0  = m0  + S(i)*df;
    m_1 = m_1 + S(i)/f(i)*df;

    % Deep-water wave power contribution
    Pwave = Pwave + ...
        0.25*1025*9.81^2*Hw(i)^2/w(i);
end

%% ---- Energy period ----
Te = m_1/m0;

end