%% ============================================================
%  Wave Spectrum Fundamentals
%
%  Figure 1 - Effect of Hs
%  Figure 2 - Effect of Tp
%  Figure 3 - Effect of gamma
%  Figure 4 - Pierson-Moskowitz vs JONSWAP
%
%  Spectral density expressed in m^2/(rad/s)
% ============================================================

clear; clc; close all;

%% ============================================================
%  FIGURE STYLE
% ============================================================

set(groot, 'DefaultAxesFontSize', 16);
set(groot, 'DefaultTextInterpreter', 'latex');
set(groot, 'DefaultAxesTickLabelInterpreter', 'latex');
set(groot, 'DefaultLegendInterpreter', 'latex');
set(groot, 'DefaultLegendFontSize', 14);
set(groot, 'DefaultAxesLabelFontSizeMultiplier', 1.2);

%% ============================================================
%  FREQUENCY GRID
% ============================================================

dw = 0.005;
w  = 0.05:dw:3.0;      % Angular frequency [rad/s]

%% ============================================================
%  COLOUR PALETTE
% ============================================================

% Green tones
green_colors = [
    0.05 0.30 0.20;
    0.20 0.50 0.35;
    0.55 0.75 0.60
];

% Blue tones
blue_colors = [
    0.10 0.20 0.40;
    0.25 0.45 0.70;
    0.55 0.70 0.85
];

%% ============================================================
%  FIGURE 1 - EFFECT OF Hs
% ============================================================

Hs_cases = [1.5 3.0 5.0];

Tp_fixed    = 8.0;
gamma_fixed = 3.3;

figure('Color','w','Name','Effect of Hs');
hold on;
grid on;
box on;

for k = 1:length(Hs_cases)

    Hs = Hs_cases(k);

    [S,~,~,~] = JONSWAP( ...
        w, ...
        Tp_fixed, ...
        Hs, ...
        gamma_fixed);

    plot( ...
        w, ...
        S, ...
        'Color',green_colors(k,:), ...
        'LineWidth',2.4, ...
        'DisplayName',sprintf('$H_s=%.1f$ m',Hs));

end

xlabel('$\omega$ [rad/s]');
ylabel('$S(\omega)$ [m$^2$/(rad/s)]');

xlim([0 2]);

legend('Location','northeast');

exportgraphics( ...
    gcf, ...
    'WaveSpectrum_Hs.pdf', ...
    'ContentType','vector');

%% ============================================================
%  FIGURE 2 - EFFECT OF Tp
% ============================================================

Tp_cases = [6 8 12];

Hs_fixed    = 3.0;
gamma_fixed = 3.3;

figure('Color','w','Name','Effect of Tp');
hold on;
grid on;
box on;

for k = 1:length(Tp_cases)

    Tp = Tp_cases(k);

    [S,~,~,~] = JONSWAP( ...
        w, ...
        Tp, ...
        Hs_fixed, ...
        gamma_fixed);

    plot( ...
        w, ...
        S, ...
        'Color',blue_colors(k,:), ...
        'LineWidth',2.4, ...
        'DisplayName',sprintf('$T_p=%.0f$ s',Tp));

end

xlabel('$\omega$ [rad/s]');
ylabel('$S(\omega)$ [m$^2$/(rad/s)]');

xlim([0 2]);

legend('Location','northeast');

exportgraphics( ...
    gcf, ...
    'WaveSpectrum_Tp.pdf', ...
    'ContentType','vector');

%% ============================================================
%  FIGURE 3 - EFFECT OF gamma
% ============================================================

gamma_cases = [1.0 3.3 7.0];

Hs_fixed = 3.0;
Tp_fixed = 8.0;

figure('Color','w','Name','Effect of gamma');
hold on;
grid on;
box on;

for k = 1:length(gamma_cases)

    gamma = gamma_cases(k);

    [S,~,~,~] = JONSWAP( ...
        w, ...
        Tp_fixed, ...
        Hs_fixed, ...
        gamma);

    plot( ...
        w, ...
        S, ...
        'Color',green_colors(k,:), ...
        'LineWidth',2.4, ...
        'DisplayName',sprintf('$\\gamma=%.1f$',gamma));

end

xlabel('$\omega$ [rad/s]');
ylabel('$S(\omega)$ [m$^2$/(rad/s)]');

xlim([0 2]);

legend('Location','northeast');

exportgraphics( ...
    gcf, ...
    'WaveSpectrum_Gamma.pdf', ...
    'ContentType','vector');

%% ============================================================
%  FIGURE 4 - PIERSON-MOSKOWITZ vs JONSWAP
% ============================================================

Hs_compare    = 3.0;
Tp_compare    = 8.0;
gamma_compare = 3.3;

[S_J,~,~,~] = JONSWAP( ...
    w, ...
    Tp_compare, ...
    Hs_compare, ...
    gamma_compare);

[S_PM,~,~,~] = PiersonMoskowitz( ...
    w, ...
    Tp_compare, ...
    Hs_compare);

figure('Color','w','Name','PM vs JONSWAP');
hold on;
grid on;
box on;

plot( ...
    w, ...
    S_PM, ...
    '--', ...
    'Color',blue_colors(1,:), ...
    'LineWidth',2.4, ...
    'DisplayName','Pierson--Moskowitz');

plot( ...
    w, ...
    S_J, ...
    '-', ...
    'Color',green_colors(1,:), ...
    'LineWidth',2.4, ...
    'DisplayName','JONSWAP ($\gamma=3.3$)');

xlabel('$\omega$ [rad/s]');
ylabel('$S(\omega)$ [m$^2$/(rad/s)]');

xlim([0 2]);

legend('Location','northeast');

exportgraphics( ...
    gcf, ...
    'WaveSpectrum_PM_vs_JONSWAP.pdf', ...
    'ContentType','vector');

%% ============================================================
%  FINISHED
% ============================================================

disp('Figures saved:');
disp('  WaveSpectrum_Hs.pdf');
disp('  WaveSpectrum_Tp.pdf');
disp('  WaveSpectrum_Gamma.pdf');
disp('  WaveSpectrum_PM_vs_JONSWAP.pdf');