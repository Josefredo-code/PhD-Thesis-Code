load('Results.mat');

%% ============================================================
%  UNWEIGHTED OBJECTIVE COMPONENTS
% ============================================================

nB  = length(b_values);
nKs = length(ks_values);

phiKs     = nan(nB,nKs);
phiB      = nan(nB,nKs);
phiLambda = nan(nB,nKs);
phiAccel  = nan(nB,nKs);
phiU      = nan(nB,nKs);
phiGamma  = gamma_opt;

for i = 1:nB
    for j = 1:nKs

        % Representative midpoint of the uncertain plant region
        bCandidate = 0.5*(b_values(i)+b_max(i));
        ksCandidate = 0.5*(ks_values(j)+ks_max(j));

        % Normalised plant-related terms
        phiKs(i,j) = ...
            ((ksCandidate-ks_domain_min)/ ...
            (ks_domain_max-ks_domain_min))^2;

        phiB(i,j) = ...
            ((bCandidate-b_domain_min)/ ...
            (b_domain_max-b_domain_min))^2;

        % Time-domain signals
        h1Current = h1{i,j}(:);
        wCurrent  = w(:);
        zCurrent  = z{i,j}(:);
        uCurrent  = u{i,j}(:);
        tCurrent  = t(:);

        % Unweighted closed-loop terms
        lambdaCurrent = h1Current-wCurrent;

        phiLambda(i,j) = ...
            trapz(tCurrent,lambdaCurrent.^2);

        phiAccel(i,j) = ...
            trapz(tCurrent,zCurrent.^2);

        phiU(i,j) = ...
            trapz(tCurrent,uCurrent.^2);
    end
end

%% ============================================================
%  DISPLAY COMPONENT SCALES
% ============================================================

componentNames = {
    'Normalised stiffness';
    'Normalised damping';
    'Road holding';
    'Body acceleration';
    'Control effort';
    'H-infinity bound'
};

componentData = {
    phiKs;
    phiB;
    phiLambda;
    phiAccel;
    phiU;
    phiGamma
};

fprintf('\nUnweighted objective components\n');
fprintf('-----------------------------------------------\n');
fprintf('%-24s %12s %12s %12s\n', ...
    'Component','Minimum','Median','Maximum');

for componentIndex = 1:numel(componentData)

    values = componentData{componentIndex};
    values = values(isfinite(values));

    fprintf('%-24s %12.4e %12.4e %12.4e\n', ...
        componentNames{componentIndex}, ...
        min(values), ...
        median(values), ...
        max(values));
end