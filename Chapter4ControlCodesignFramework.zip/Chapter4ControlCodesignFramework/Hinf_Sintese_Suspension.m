function [gamma, K, Av, Bu, Bwv, Czi, Dzui, Dzwi] =Hinf_Sintese_Suspension (m1,m2,kt,b_min,b_max,ks_min,ks_max,xii,Zmin,Zmax,Gmin)

%Vertices of Polytopic System
Av{1}=[
      -b_min/m2,  b_min/m2,  -ks_min/m2,  ks_min/m2;
       b_min/m1,  -b_min/m1,  ks_min/m1,  -(ks_min+kt)/m1;
       1,       0,      0,      0;
       0,       1,      0,      0;
];

Av{2}=[
      -b_min/m2,  b_min/m2,  -ks_max/m2,  ks_max/m2;
       b_min/m1,  -b_min/m1,  ks_max/m1,  -(ks_max+kt)/m1;
       1,       0,      0,      0;
       0,       1,      0,      0;
];


Av{3}=[
      -b_max/m2,  b_max/m2,  -ks_min/m2,  ks_min/m2;
       b_max/m1,  -b_max/m1,  ks_min/m1,  -(ks_min+kt)/m1;
       1,       0,      0,      0;
       0,       1,      0,      0;
];


Av{4}=[
      -b_max/m2,  b_max/m2,  -ks_max/m2,  ks_max/m2;
       b_max/m1,  -b_max/m1,  ks_max/m1,  -(ks_max+kt)/m1;
       1,       0,      0,      0;
       0,       1,      0,      0;
];

Bu = [
     1/m2;
     -1/m1;
      0;
      0;
  ];

Bwv = [
     0;
     1/m1;
      0;
      0;
  ];
%%

A=rolmipvar(Av,'A',4,1); %(Vertices, 'label', Amount of vertices, degree of homogeneous polinomy ) %A(alpha)Lemma2
Bwi=Bwv; %Bw(alpha)Lemma2
Czi=[0 0 1 1]; %Cz(alpha)Lemma2
Dzwi=0; %Dzw(alpha)Lemma2
Dzui=0; %Dzu(alpha)Lemma2

%Dimensions
n=length(Av{1});
nu=size(Bu,2);
nwi=size(Bwv,2);
nzi=size(Czi,1);

%Slack variables
G=rolmipvar(n,n,'G','sym',4,0); %G from Lemma 2
Z=sdpvar(nu,n,'full'); %Z from Lemma 2
Hi=rolmipvar(nwi,nwi,'Hi','full',4,0); %H from Lemma 2
mu=sdpvar(1,1); %'mu'  is the square of the guaranteed cost 'gamma'
Pi=rolmipvar(n,n,'Pi','sym',4,0); %P solution of LMI Lemma 2

LMIs=[];%initialising

%LMI Lemma 2
Q11=A*G+G'*A'+Bu*Z+Z'*Bu';
Q12=Pi-G'+xii*(A*G+Bu*Z);
Q13=G'*Czi'+Z'*Dzui';
Q14=-Bwi*Hi;
Q22=-xii*(G+G');
Q23=xii*(G'*Czi'+Z'*Dzui');
Q24=zeros(n,nzi); 
Q33=-mu*eye(nwi); 
Q34=-Dzwi*Hi;
Q44=eye(nwi)+Hi+Hi'; 
Q=[[Q11 Q12 Q13 Q14];[Q12' Q22 Q23 Q24];[Q13' Q23' Q33 Q34];[Q14' Q24' Q34' Q44]];

%Bounds of Slack variable 0<=Z_ij<=3 (control variable Xc3)
for i=1:nu
    for j=1:n
        LMIs=[LMIs,Z(i,j)>=Zmin,Z(i,j)<=Zmax];
    end
end

LMIs=[LMIs,Pi>=0,Q<=0,G>=Gmin]; %conditions for LMIs Lemma 2, and bound for slack variable 0=<G

solvesdp(LMIs,mu); %minimisation of variable 'mu'
[primal,~]=checkset(LMIs);
if(min(round(primal*10^8))>=0)
    K=double(Z)*inv(double(G)); %feedback gain is K=Z*G^-1
else
disp('infactivel'); %no convergence of otimisation problem
K=NaN;
end
gamma=sqrt(double(mu)); %gamma is H_infinty guaranteed cost
end