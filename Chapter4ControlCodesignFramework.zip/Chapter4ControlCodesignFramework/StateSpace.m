function [u,t,w,x,z,h1,A,Cz] = ...
    StateSpace(K,Bu,Bwv,Av,road_z,x0,contr)
%STATESPACE Simulate the active suspension system.
%
% Inputs:
%   K      - State-feedback gain
%   Bu     - Control-input matrix
%   Bwv    - Disturbance-input matrix
%   Av     - State matrices at the four polytopic vertices
%   road_z - Road vertical displacement h_r(t) [m]
%   x0     - Initial state
%   contr  - 1: H-infinity controller
%            2: LQR controller
%
% Outputs:
%   u  - Control force [N]
%   t  - Time vector [s]
%   w  - Road displacement h_r(t) [m]
%   x  - State trajectory
%   z  - Vehicle-body vertical acceleration [m/s^2]
%   h1 - Wheel vertical displacement [m]
%   A  - Representative open-loop state matrix
%   Cz - Controlled-output matrix

%% ============================================================
%  MODEL PARAMETERS
% ============================================================

kt = 232.5e3; % Tyre stiffness [N/m]
bt = 0;       % Tyre damping coefficient [N s/m]

dt = 0.01;    % Simulation sampling interval [s]

%% ============================================================
%  REPRESENTATIVE POLYTOPIC REALISATION
% ============================================================

% The representative plant is evaluated using
% alpha_1=alpha_2=alpha_3=alpha_4=1/4.
A = zeros(size(Av{1}));

for vertexIndex = 1:numel(Av)
    A = A+0.25*Av{vertexIndex};
end

Bw = Bwv;

Cz = [
    0 0 1 0;
    0 0 0 1
];

D = zeros(size(Cz,1),size(Bw,2));

%% ============================================================
%  ROAD DISPLACEMENT AND EQUIVALENT FORCE
% ============================================================

% Road vertical displacement h_r(t) [m]
roadDisplacement = road_z(:);

% Simulation time
t = (0:length(roadDisplacement)-1)'*dt;

% Road vertical velocity
roadVelocity = ...
    gradient(roadDisplacement,dt);

% Equivalent force exerted on the unsprung mass:
%
% w_f(t)=kt*h_r(t)+bt*dh_r(t)/dt.
%
% Since bt=0, w_f(t)=kt*h_r(t).
roadForce = ...
    kt*roadDisplacement + ...
    bt*roadVelocity;

%% ============================================================
%  CLOSED-LOOP SYSTEM
% ============================================================

if contr == 1

    % H-infinity convention: u=K*x
    A_cl = A+Bu*K;

elseif contr == 2

    % MATLAB LQR convention: u=-K*x
    A_cl = A-Bu*K;

else

    error( ...
        'contr must be 1 for H-infinity control or 2 for LQR control.');
end

%% Check closed-loop stability

closedLoopPoles = eig(A_cl);

if any(real(closedLoopPoles) >= 0)
    warning( ...
        'The selected closed-loop system is not asymptotically stable.');
end

%% ============================================================
%  SIMULATION
% ============================================================

sys = ss(A_cl,Bw,Cz,D);

% Both controllers receive exactly the same equivalent road force.
[~,t,x] = ...
    lsim( ...
        sys, ...
        roadForce, ...
        t, ...
        x0);

%% ============================================================
%  CONTROL FORCE
% ============================================================

if contr == 1

    u = K*x.';

else

    u = -K*x.';

end

%% ============================================================
%  OUTPUTS
% ============================================================

% State derivative obtained directly from the state equation
stateDerivative = ...
    A_cl*x.' + ...
    Bw*roadForce.';

% Wheel vertical displacement
h1 = x(:,4).';

% Vehicle-body vertical acceleration:
% xi_1=dh2/dt and therefore dxi_1/dt=ddh2/dt2.
z = stateDerivative(1,:);

% Return the road displacement, rather than the equivalent force,
% because the suspension deflection is lambda=h1-h_r.
w = roadDisplacement.';

end