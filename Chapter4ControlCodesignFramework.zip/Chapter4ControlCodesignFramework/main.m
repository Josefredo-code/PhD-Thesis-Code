
%%
clc
close all
clear

%notation note: 
% in the article we called the states \xi and the scalar LMI variable \betha. In the current code we are calling the states x and the scalar LMI variable xii 

%%
%%SIMULATION SETUP
aux=30; % number of iterations (q, p)

%Loading road disturbances input (w(t))
load('w2.mat'); %road_z, rough road

% Simulation and disturbance durations
dt = 0.01;
disturbanceEndTime = 4.5; % Rough-road input applied until 4 s
simulationEndTime  = 6; % Total simulation duration

% Retain only the first 6 s of the original road profile
numberOfSamples = round(simulationEndTime/dt)+1;

if numel(road_z) < numberOfSamples
    error('The road profile is shorter than the required simulation time.');
end

road_z = road_z(1:numberOfSamples);

% Set the road disturbance to zero after 4 s
firstZeroSample = round(disturbanceEndTime/dt)+2;
road_z(firstZeroSample:end) = 0;

%%
%PHYSICAL DESIGN

%Plant design vector: xp=[d D p Na D0 Dp Ds]
    % d= spring wire diameter
    % D= spring helix diameter
    % p= spring pitch
    % Na= spring number of active coils
    % D0= orifice diameter (m)
    % Dp= damper working piston diameter (m)
    % Ds: damper stroke (m)
  
xp=[0.005 0.05 0.02 3 0.003 0.03 0.1; %xp,min
  0.02 0.4 0.5 16 0.012 0.08 0.3]; %xp,max

G=77.2e9; %shear modulus
n=0.9; %used to calculate the value of C2, the damper value coefficient 
Af=0.1; %coefficient used to tune the port shape, used to calculate the value of C2, the damper value coefficient
Cd=0.7; %discharge coefficient
kv=7500; %spool valve spring constant
pho1=850; %damper fluid density
Pallow=4.75e6; %maximum allowed damper pressure

m1=65; %tire mass
m2=325; %one quarter of car total mass
kt=232.5e3; %tire spring constant
bt=0; %tire damper value

% Defining the constraints of values for b and ks
[ks_min,ks_max,b_min,b_max] = physical(xp,G,n,Af,Cd,kv,pho1,Pallow);


% Preserve the global admissible physical-design limits
ks_domain_min = ks_min;
ks_domain_max = ks_max;
b_domain_min  = b_min;
b_domain_max  = b_max;
%% 
%CONTROL DESIGN

%(gamma is control variable Xc2) (output is b* and ks*, plant candidates that minimise the H_infinity guaranteed cost)

range1=15; %size of uncertainty in parameter b
range2=15; %size of uncertainty in parameter ks
xii_initial=1e-1; %initial value for scalar variable in Lemma 2  (this variable was named as betha in the article)
Zmin=0; %Lower bound for matrix slack variable, Z, in Lemma2
Zmax=3; %Upper bound for matrix slack variable, Z, in Lemma2
Gmin=zeros(4,4); %Lower bound for matrix slack variable, G, in Lemma2
x0=[0 0 0.01 0.01]; %Initial conditions for states: [x1 x2 x3 x4]'=[dh2/dt dh1/dt h2 h1]'

% Defining the values for ks and b according to the constraints previously stablished 
b_values  = linspace(b_min,b_domain_max-range1,aux);
ks_values = linspace(ks_min,ks_domain_max-range2,aux);
b_max  = b_values  + range1;
ks_max = ks_values + range2;

% Initializing matrices for gamma and K_norm
gamma = zeros(length(b_values), length(ks_values));
K_storage = cell(length(b_values), length(ks_values));
K_norm = zeros(length(b_values), length(ks_values));

% Loop to vary b and ks and calculate the H_infinity guaranteed cost and
% feedback gain K
for i = 1:length(b_values)
    for j = 1:length(ks_values) 
        %computation of the H_inf guaranteed cost, gamma, and feedback
        %gain, K, for each plant candidate b and ks
        [gamma(i, j), K, ~, ~, ~, ~, ~, ~] = Hinf_Sintese_Suspension(m1, m2, kt, b_values(i), b_max(i), ks_values(j), ks_max(j), xii_initial, Zmin, Zmax, Gmin);
        K_storage{i, j} = K; %Store the vector gain, K, for each value of b and ks
        K_norm(i, j) = norm(K); %Store the 2-norm of the gain vector, K, for each value of b and ks
    end
end

%%
%Finding minimum gamma and respective b* and ks*
[mingamma1, gamma1Index]=min(gamma(:));
[b_index1, Ks_index1] = ind2sub(size(gamma), gamma1Index);
b_star_lower_bound=b_values(b_index1);
b_star_upper_bound=b_max(b_index1);
ks_star_lower_bound = ks_values(Ks_index1);
ks_star_upper_bound = ks_max(Ks_index1);

%%
%(xii is control variable Xc4) (output is xii_opt that minimises the 2-norm of feedback gain K)
xii_values=[1e-9 1e-8 1e-7 1e-6 1e-5 1e-4 1e-3 1e-2 0.1 1 10 100 1000]; %xii values follow a logaritmic progression (this variable was named as betha in the article)

Gmin=eye(4); %changing the bound of Slack variable G

K_storage_xii = cell(1,length(xii_values)); %initializing variable
K_norm_xii = zeros(1,length(xii_values));%initializing variable

for m=1:1:length(xii_values)
    %computation of the feedback gain, K, for each xii value
    [~,K_xii, ~, ~, ~, ~, ~, ~] = Hinf_Sintese_Suspension(m1, m2, kt, b_star_lower_bound, b_star_upper_bound, ks_star_lower_bound, ks_star_upper_bound, xii_values(m),Zmin,Zmax,Gmin);
    K_storage_xii{m} = K_xii; %store the gain vector K, for each xii value
    K_norm_xii(m) = norm(K_xii); %norm of gain vector K, for each xii value
end 

[minK_xii, xiiIndex]=min(K_norm_xii(:)); %Fiding minimum norm of gain K and respective xii index
xii_opt=xii_values(xiiIndex); %xii that guarantees the minimum 2-norm for K gain vector

%%
%Final loop- Optimal plant solution

% Initializing matrices 
gamma_opt = zeros(length(b_values), length(ks_values));
K_opt_storage = cell(length(b_values), length(ks_values));
K_opt_norm = zeros(length(b_values), length(ks_values));
u = cell(length(b_values), length(ks_values));
x = cell(length(b_values), length(ks_values));
z = cell(length(b_values), length(ks_values));
h1 = cell(length(b_values), length(ks_values));
J = zeros(length(b_values), length(ks_values));
A = cell(length(b_values), length(ks_values));

plant_cost      = zeros(length(b_values),length(ks_values));
closed_loop_cost = zeros(length(b_values),length(ks_values));
hinf_cost       = zeros(length(b_values),length(ks_values));

% Loop to vary b and ks and calculate the H_infinity guaranteed cost,
% feedback gain K, and cost funtion J, now considering xii_opt
for i = 1:length(b_values)
    for j = 1:length(ks_values) 
        % Representative physical design of the current uncertain region
        b_candidate = 0.5*(b_values(i)+b_max(i));
        ks_candidate = 0.5*(ks_values(j)+ks_max(j));

        [gamma_opt(i, j), K_opt, Av, Bu, Bw, ~, Dzu, Dzw] = Hinf_Sintese_Suspension(m1, m2, kt, b_values(i), b_max(i), ks_values(j), ks_max(j), xii_opt, Zmin, Zmax, Gmin); 
        K_opt_storage{i, j} = K_opt; %Store the vector gain, K, for each value of b and ks
        K_opt_norm(i, j) = norm(K_opt); %Store the 2-norm of the gain vector, K, for each value of b and ks

        %State space model considering alpha_1=...alpha_i...=alpha_n
        [u{i,j}, t, w, x{i,j}, z{i,j}, h1{i,j}, A{i,j}, Cz] = StateSpace (K_opt,Bu, Bw, Av, road_z, x0,1);
        
        %Cost function J
        [J(i,j),plant_cost(i,j),closed_loop_cost(i,j),hinf_cost(i,j)] = CostFunctionJ( ...
        h1{i,j}, ...
        w, ...
        z{i,j}, ...
        u{i,j}, ...
        gamma_opt(i,j), ...
        t, ...
        ks_candidate, ...
        b_candidate, ...
        ks_domain_min, ...
        ks_domain_max, ...
        b_domain_min, ...
        b_domain_max);
    end
end

%%
%Finding minimum J and respective b_opt and ks_opt
[minJ, JIndex]=min(J(:));
[b_opt_index, ks_opt_index] = ind2sub(size(J), JIndex);
b_opt_lower_bound=b_values(b_opt_index);
b_opt_upper_bound=b_max(b_opt_index);
ks_opt_lower_bound=ks_values(ks_opt_index);
ks_opt_upper_bound=ks_max(ks_opt_index);


%%
gamma_opt_rough=gamma_opt;
K_opt_storage_rough=K_opt_storage;
K_opt_norm_rough=K_opt_norm;
J_rough=J;
u_opt_rough=u{b_opt_index,ks_opt_index};
x_opt_rough=x{b_opt_index,ks_opt_index};
z_opt_rough=z{b_opt_index,ks_opt_index};
h1_opt_rough=h1{b_opt_index,ks_opt_index};
w_rough=w;
t_rough=t;
b_opt_index_rough=b_opt_index;
ks_opt_index_rough=ks_opt_index;
xii_opt_rough=xii_opt;
Cz_rough=Cz;
b_opt_lower_bound_rough=b_opt_lower_bound;
b_opt_upper_bound_rough=b_opt_upper_bound;
ks_opt_lower_bound_rough=ks_opt_lower_bound;
ks_opt_upper_bound_rough=ks_opt_upper_bound;

%%
%Rough road cost function
Jfinal=J_rough;

%Finding minimum Jfinal and respective b_optimal and ks_optimal
[minJfinal, JfinalIndex]=min(Jfinal(:));
[b_optimal_index, ks_optimal_index] = ind2sub(size(Jfinal), JfinalIndex);
b_optimal_lower_bound=b_values(b_optimal_index);
b_optimal_upper_bound=b_max(b_optimal_index);
ks_optimal_lower_bound=ks_values(ks_optimal_index);
ks_optimal_upper_bound=ks_max(ks_optimal_index);

%%
%SYSTEM DYNAMIC RESPONSE - 
%Weighting matrices q and r for Riccati Equation
q=Cz'*Cz;
r=10;
%
[Klqr_rough, ~, ~] = lqr(A{b_opt_index_rough,ks_opt_index_rough}, Bu, q, r); %LQR K gain using ks and b optimals found in the present work 
[u_LQR_rough, t_LQR_rough, ~, x_LQR_rough, z_LQR_rough, h1_LQR_rough, ~, ~] = StateSpace (Klqr_rough,Bu, Bw, Av, road_z, x0,2);

%%
save('Results.mat');
%Ploting
Ploting; %Figures

UNCONTROLLEDPLANTDESIGNOPTIMISATION

K_Hinf_opt =K_opt_storage_rough{b_opt_index_rough,ks_opt_index_rough};
disp(K_Hinf_opt)
disp(Klqr_rough)
