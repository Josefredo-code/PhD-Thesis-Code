function [J,plantCost,closedLoopCost,hinfCost] = ...
    CostFunctionJ(h1,w,h2Acceleration,u,gamma,t, ...
                  ks,b,ksLower,ksUpper,bLower,bUpper)
%COSTFUNCTIONJ Evaluate the combined plant--controller objective.
%
% Inputs:
%   h1             - Wheel vertical displacement [m]
%   w              - Road vertical displacement [m]
%   h2Acceleration - Vehicle-body vertical acceleration [m/s^2]
%   u              - Control force [N]
%   gamma          - Guaranteed H-infinity performance bound
%   t              - Simulation time [s]
%   ks             - Representative suspension stiffness [N/m]
%   b              - Representative damping coefficient [N s/m]
%   ksLower        - Global minimum admissible stiffness [N/m]
%   ksUpper        - Global maximum admissible stiffness [N/m]
%   bLower         - Global minimum admissible damping [N s/m]
%   bUpper         - Global maximum admissible damping [N s/m]

%% Objective-function weights

% Plant-related objective weights
r1 = 1;
r2 = 1;

% Closed-loop performance weights
r3 = 1e3;
r4 = 5;
r5 = 1e6;

% Guaranteed H-infinity performance weight
r6 = 1;

%% Ensure consistent vector dimensions

h1             = h1(:);
w              = w(:);
h2Acceleration = h2Acceleration(:);
u              = u(:);
t              = t(:);

if ~isequal(length(h1),length(w),length(h2Acceleration), ...
            length(u),length(t))
    error('All time-domain signals must have the same number of samples.');
end

%% Plant-related objective

normalisedKs = ...
    (ks-ksLower)/(ksUpper-ksLower);

normalisedB = ...
    (b-bLower)/(bUpper-bLower);

plantCost = ...
    r1*normalisedKs^2 + ...
    r2*normalisedB^2;

%% Closed-loop performance

lambda = h1-w;

integrand = ...
    r3*lambda.^2 + ...
    r4*h2Acceleration.^2 + ...
    r5*u.^2;

closedLoopCost = trapz(t,integrand);

%% Guaranteed H-infinity performance

hinfCost = r6*gamma;

%% Combined plant--controller objective

J = plantCost + closedLoopCost + hinfCost;

end