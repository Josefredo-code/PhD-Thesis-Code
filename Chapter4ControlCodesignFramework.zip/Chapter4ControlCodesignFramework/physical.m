function [ks_min,ks_max,b_min,b_max] = physical(xp,G,n,Af,Cd,kv,pho1,Pallow)

ks=zeros(1,2);
b=zeros(1,2);

for i=1:1:2
d=xp(i,1);
D=xp(i,2);
p=xp(i,3);
Na=xp(i,4);
D0=xp(i,5);
Dp=xp(i,6);
Ds=xp(i,7);

C=D/d;
ks(i)=(d^4*G)/(8*D^3*Na*(1+1/2/C^2));


A0=pi*D0^2/4;
xm=A0*Pallow/kv;
C2=n*Af*sqrt(xm);
b(i)=(Dp^4)/(8*Cd*C2*D0^2)*sqrt((pi*kv*pho1)/2);

end

ks_min=ks(2);
ks_max=ks(1);
b_min=b(2);
b_max=b(1);

end



