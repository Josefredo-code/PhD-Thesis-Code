%% ============================================================
%  H-infinity Norm - SISO Frequency-Domain Interpretation
%
%  The H-infinity norm corresponds to the largest magnitude
%  of the frequency response over all frequencies.
% ============================================================

clear; clc; close all;

%% ============================================================
%  FIGURE STYLE
% ============================================================

set(groot, 'DefaultAxesFontSize', 16);
set(groot, 'DefaultTextInterpreter', 'latex');
set(groot, 'DefaultAxesTickLabelInterpreter', 'latex');
set(groot, 'DefaultLegendInterpreter', 'latex');
set(groot, 'DefaultLegendFontSize', 14);
set(groot, 'DefaultAxesLabelFontSizeMultiplier', 1.2);

%% ============================================================
%  COLOUR PALETTE
% ============================================================

% Green tones
green_colors = [
    0.05 0.30 0.20;
    0.20 0.50 0.35;
    0.55 0.75 0.60
];

% Blue tones
blue_colors = [
    0.10 0.20 0.40;
    0.25 0.45 0.70;
    0.55 0.70 0.85
];

%% ============================================================
%  FREQUENCY GRID
% ============================================================

omega = logspace(-1,1,3000);  % Angular frequency [rad/s]
s     = 1i*omega;

%% ============================================================
%  GENERIC STABLE SISO SYSTEM
%
%           s^2 + 2*zeta_z*omega_z*s + omega_z^2
%  H(s) =  ---------------------------------------
%           s^2 + 2*zeta_p*omega_p*s + omega_p^2
%
%  The lightly damped poles produce a resonant peak.
% ============================================================

omega_p = 1.0;
zeta_p  = 0.30;

omega_z = sqrt(5);
zeta_z  = 0.70;

numerator = ...
    s.^2 ...
    + 2*zeta_z*omega_z*s ...
    + omega_z^2;

denominator = ...
    s.^2 ...
    + 2*zeta_p*omega_p*s ...
    + omega_p^2;

H_wz = numerator ./ denominator;

%% ============================================================
%  FREQUENCY-RESPONSE MAGNITUDE
% ============================================================

magnitude_linear = abs(H_wz);
magnitude_dB     = 20*log10(magnitude_linear);

% Numerical approximation of the H-infinity norm
[Hinf_dB,index_peak] = max(magnitude_dB);

Hinf_linear = magnitude_linear(index_peak);
omega_peak  = omega(index_peak);

%% ============================================================
%  FIGURE
% ============================================================

figure( ...
    'Color','w', ...
    'Name','H-infinity Norm - SISO', ...
    'Position',[100 100 900 460]);

hold on;
grid on;
box on;

% Frequency-response magnitude
semilogx( ...
    omega, ...
    magnitude_dB, ...
    '-', ...
    'Color',green_colors(1,:), ...
    'LineWidth',2.4, ...
    'DisplayName','$|H_{wz}(j\omega)|$');

% H-infinity norm
semilogx( ...
    omega, ...
    Hinf_dB*ones(size(omega)), ...
    '--', ...
    'Color',blue_colors(1,:), ...
    'LineWidth',2.0, ...
    'DisplayName', ...
    '$20\log_{10}\!\left(\|H_{wz}\|_\infty\right)$');

% Peak marker
semilogx( ...
    omega_peak, ...
    Hinf_dB, ...
    'o', ...
    'Color',blue_colors(1,:), ...
    'MarkerFaceColor','w', ...
    'MarkerSize',7, ...
    'LineWidth',1.8, ...
    'HandleVisibility','off');

% Peak-frequency indicator
xline( ...
    omega_peak, ...
    ':', ...
    'Color',blue_colors(2,:), ...
    'LineWidth',1.4, ...
    'HandleVisibility','off');

% Axis labels
xlabel('$\omega$ [rad/s]');
ylabel('$20\log_{10}|H_{wz}(j\omega)|$ [dB]');

% Axis limits
xlim([0.1 10]);
ylim([0 ceil(Hinf_dB)+1]);

% Annotation
text( ...
    1.08*omega_peak, ...
    Hinf_dB-1.4, ...
    sprintf('$\\omega_{\\mathrm{peak}}=%.2f$ rad/s', ...
    omega_peak), ...
    'Color',blue_colors(1,:), ...
    'FontSize',14);

legend( ...
    'Location','northeast', ...
    'Box','on');

%% ============================================================
%  EXPORT
% ============================================================

exportgraphics( ...
    gcf, ...
    'HinfNormConceptSISO.pdf', ...
    'ContentType','vector');

%% ============================================================
%  RESULTS
% ============================================================

disp('Figure saved:');
disp('  HinfNormConceptSISO.pdf');

fprintf('\nH-infinity norm: %.4f\n',Hinf_linear);
fprintf('H-infinity norm: %.4f dB\n',Hinf_dB);
fprintf('Peak frequency: %.4f rad/s\n',omega_peak);