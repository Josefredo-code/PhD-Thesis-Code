%% ============================================================
%  H2 Norm - SISO Frequency-Domain Interpretation
%
%  For a stable and strictly proper SISO system:
%
%              1
%  ||H||_2^2 = --- integral_0^infinity |H(jw)|^2 dw
%              pi
%
%  The shaded region represents the positive-frequency integral.
% ============================================================

clear; clc; close all;

%% ============================================================
%  FIGURE STYLE
% ============================================================

set(groot, 'DefaultAxesFontSize', 16);
set(groot, 'DefaultTextInterpreter', 'latex');
set(groot, 'DefaultAxesTickLabelInterpreter', 'latex');
set(groot, 'DefaultLegendInterpreter', 'latex');
set(groot, 'DefaultLegendFontSize', 14);
set(groot, 'DefaultAxesLabelFontSizeMultiplier', 1.2);

%% ============================================================
%  COLOUR PALETTE
% ============================================================

% Green tones
green_colors = [
    0.05 0.30 0.20;
    0.20 0.50 0.35;
    0.55 0.75 0.60
];

% Blue tones
blue_colors = [
    0.10 0.20 0.40;
    0.25 0.45 0.70;
    0.55 0.70 0.85
];

%% ============================================================
%  FREQUENCY GRID
% ============================================================

% A wide frequency interval is used to approximate the integral
% from zero to infinity.

omega = linspace(0,200,50000);  % Angular frequency [rad/s]
s     = 1i*omega;

%% ============================================================
%  GENERIC STABLE AND STRICTLY PROPER SISO SYSTEM
%
%                    4
%  H_wz(s) = -------------------
%             s^2 + 0.8s + 4
%
%  The system is stable because its poles have negative
%  real parts. It is strictly proper because the denominator
%  degree is greater than the numerator degree.
% ============================================================

H_wz = 4 ./ (s.^2 + 0.8*s + 4);

%% ============================================================
%  FREQUENCY-RESPONSE ENERGY DENSITY
% ============================================================

magnitude_squared = abs(H_wz).^2;

%% ============================================================
%  NUMERICAL H2 NORM
%
%  For a real-coefficient SISO system:
%
%              1
%  ||H||_2^2 = --- integral_0^infinity |H(jw)|^2 dw
%              pi
% ============================================================

positive_frequency_area = trapz(omega,magnitude_squared);

H2_squared = positive_frequency_area/pi;
H2_norm    = sqrt(H2_squared);

%% ============================================================
%  DISPLAY RANGE
% ============================================================

% The integral is evaluated using the complete frequency grid,
% but only the dynamically relevant range is displayed.

omega_display_max = 10;

display_indices = omega <= omega_display_max;

omega_plot = omega(display_indices);
magnitude_squared_plot = ...
    magnitude_squared(display_indices);

%% ============================================================
%  FIGURE
% ============================================================

figure( ...
    'Color','w', ...
    'Name','H2 Norm - SISO', ...
    'Position',[100 100 900 460]);

hold on;
grid on;
box on;

% Shaded area under |H(jw)|^2
area( ...
    omega_plot, ...
    magnitude_squared_plot, ...
    'FaceColor',green_colors(3,:), ...
    'EdgeColor','none', ...
    'DisplayName', ...
    'Area under $|H_{wz}(j\omega)|^2$');

% Squared frequency-response magnitude
plot( ...
    omega_plot, ...
    magnitude_squared_plot, ...
    '-', ...
    'Color',green_colors(1,:), ...
    'LineWidth',2.4, ...
    'DisplayName','$|H_{wz}(j\omega)|^2$');

% Axis labels
xlabel('$\omega$ [rad/s]');
ylabel('$|H_{wz}(j\omega)|^2$');

% Axis limits
xlim([0 omega_display_max]);
ylim([0 1.15*max(magnitude_squared_plot)]);

% Ensure grid lines remain visible above the shaded region
set(gca,'Layer','top');

% H2-norm annotation
text( ...
    5.0, ...
    0.72*max(magnitude_squared_plot), ...
    sprintf( ...
    ['$\\displaystyle \\|H_{wz}\\|_2^2' ...
     '=\\frac{1}{\\pi}' ...
     '\\int_0^{\\infty}|H_{wz}(j\\omega)|^2' ...
     '\\,\\mathrm{d}\\omega=%.3f$'], ...
    H2_squared), ...
    'Color',blue_colors(1,:), ...
    'FontSize',15, ...
    'HorizontalAlignment','center');

text( ...
    5.0, ...
    0.55*max(magnitude_squared_plot), ...
    sprintf( ...
    '$\\displaystyle \\|H_{wz}\\|_2=%.3f$', ...
    H2_norm), ...
    'Color',blue_colors(1,:), ...
    'FontSize',15, ...
    'HorizontalAlignment','center');

legend( ...
    'Location','northeast', ...
    'Box','on');

%% ============================================================
%  EXPORT
% ============================================================

exportgraphics( ...
    gcf, ...
    'H2NormConceptSISO.pdf', ...
    'ContentType','vector');

%% ============================================================
%  RESULTS
% ============================================================

disp('Figure saved:');
disp('  H2NormConceptSISO.pdf');

fprintf('\nPositive-frequency area: %.6f\n', ...
    positive_frequency_area);

fprintf('Squared H2 norm: %.6f\n', ...
    H2_squared);

fprintf('H2 norm: %.6f\n', ...
    H2_norm);