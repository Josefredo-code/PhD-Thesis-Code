function [DeltaC,P,info] = passivation_LMI_D0(A,B,C,varargin)
%======================================================================
% PASSIVATION_LMI_D0
%
% Implements Problem 2 of Faedo et al. (2021) for
%
%   Sigma = (A,B,C,0).
%
% The routine first attempts to use SDPT3 and then SeDuMi. A solver
% solution reported with numerical warnings is accepted only when the
% returned candidate satisfies every LMI within the prescribed numerical
% tolerance.
%
% Default weights:
%
%   wGamma = 0.8;
%   wBeta  = 0.2;
%======================================================================

    %% Optional weights

    if nargin < 4
        wGamma = 0.5;
    else
        wGamma = varargin{1};
    end

    if nargin < 5
        wBeta = 0.5;
    else
        wBeta = varargin{2};
    end

    %% Dimensions

    n = size(A,1);
    p = size(C,1);

    %% Assumption checks

    assert(size(A,2)==n, ...
        'A must be square.');

    assert(size(B,1)==n, ...
        'B must have the same number of rows as A.');

    assert(size(C,2)==n, ...
        'C must have the same number of columns as A.');

    assert(size(B,2)==p, ...
        ['Problem 2 requires a square input-output system: ', ...
         'size(B,2) must equal size(C,1).']);

    assert(wGamma>=0 && wGamma<=1, ...
        'wGamma must belong to [0,1].');

    assert(wBeta>=0 && wBeta<=1, ...
        'wBeta must belong to [0,1].');

    assert(abs(wGamma+wBeta-1)<=1e-12, ...
        'The weights must satisfy wGamma + wBeta = 1.');

    poles = eig(A);

    assert(all(real(poles)<0), ...
        'A must be asymptotically stable.');

    %% Decision variables

    Pvariable = sdpvar(n,n,'symmetric');
    DeltaCvariable = sdpvar(p,n,'full');

    gammaVariable = sdpvar(1,1);
    betaVariable = sdpvar(1,1);

    %% Numerical parameters

    epsilonP = 1e-9;

    % Relative tolerance used only to validate a candidate returned by
    % the numerical solver.
    feasibilityTolerance = 1e-7;

    %% Problem 2 LMIs

    LMI1 = [
        gammaVariable*eye(p), DeltaCvariable
        DeltaCvariable', gammaVariable*eye(n)
    ] >= 0;

    LMI2 = [
        betaVariable*eye(n), ...
        Pvariable*B-(C+DeltaCvariable)'
        B'*Pvariable-(C+DeltaCvariable), ...
        betaVariable*eye(p)
    ] >= 0;

    LMI3 = ...
        Pvariable*A+A'*Pvariable <= 0;

    LMI4 = ...
        Pvariable >= epsilonP*eye(n);

    constraints = [
        LMI1
        LMI2
        LMI3
        LMI4
        gammaVariable >= 0
        betaVariable >= 0
    ];

    objective = ...
        wGamma*gammaVariable + ...
        wBeta*betaVariable;

    %% Solver sequence

    solverNames = {'sdpt3','sedumi'};

    solutionAccepted = false;
    candidateAvailable = false;

    selectedSolver = '';
    selectedDiagnostic = [];

    candidateDeltaC = [];
    candidateP = [];
    candidateGamma = NaN;
    candidateBeta = NaN;

    candidateChecks = struct();

    for solverIndex = 1:numel(solverNames)

        solverName = solverNames{solverIndex};

        fprintf( ...
            '\nAttempting Problem 2 with %s...\n', ...
            upper(solverName));

        solverOptions = sdpsettings( ...
            'solver',solverName, ...
            'verbose',1, ...
            'warning',1, ...
            'savesolverinput',1, ...
            'savesolveroutput',1);

        diagnostic = optimize( ...
            constraints, ...
            objective, ...
            solverOptions);

        DeltaCtrial = value(DeltaCvariable);
        Ptrial = value(Pvariable);

        gammaTrial = value(gammaVariable);
        betaTrial = value(betaVariable);

        finiteCandidate = ...
            ~isempty(DeltaCtrial) && ...
            ~isempty(Ptrial) && ...
            all(isfinite(DeltaCtrial(:))) && ...
            all(isfinite(Ptrial(:))) && ...
            isfinite(gammaTrial) && ...
            isfinite(betaTrial);

        if ~finiteCandidate
            fprintf( ...
                '   %s did not return a finite candidate.\n', ...
                upper(solverName));

            continue;
        end

        candidateAvailable = true;

        checks = check_candidate( ...
            A,B,C, ...
            DeltaCtrial,Ptrial, ...
            gammaTrial,betaTrial, ...
            epsilonP,feasibilityTolerance);

        print_candidate_checks( ...
            solverName,diagnostic,checks);

        if checks.feasible
            solutionAccepted = true;

            selectedSolver = solverName;
            selectedDiagnostic = diagnostic;

            candidateDeltaC = DeltaCtrial;
            candidateP = Ptrial;
            candidateGamma = gammaTrial;
            candidateBeta = betaTrial;
            candidateChecks = checks;

            break;
        end

        % Retain the most recent finite candidate for diagnostics.
        selectedSolver = solverName;
        selectedDiagnostic = diagnostic;

        candidateDeltaC = DeltaCtrial;
        candidateP = Ptrial;
        candidateGamma = gammaTrial;
        candidateBeta = betaTrial;
        candidateChecks = checks;
    end

    %% Validate solver outcome

    if ~candidateAvailable
        error( ...
            ['Neither SDPT3 nor SeDuMi returned a finite ', ...
             'candidate solution.']);
    end

    if ~solutionAccepted
        error( ...
            ['No solver returned a candidate satisfying all LMIs. ', ...
             'Last solver: %s; status: %s.'], ...
            selectedSolver,selectedDiagnostic.info);
    end

    %% Accepted solution

    DeltaC = candidateDeltaC;
    P = candidateP;

    gammaValue = candidateGamma;
    betaValue = candidateBeta;

    Cpass = C+DeltaC;

    equalityResidual = norm( ...
        P*B-Cpass',2);

    relativePerturbation = ...
        norm(DeltaC,2)/max(norm(C,2),eps);

    %% Information structure

    info = selectedDiagnostic;

    info.acceptedAfterNumericalCheck = ...
        selectedDiagnostic.problem ~= 0;

    info.selectedSolver = selectedSolver;
    info.gamma = gammaValue;
    info.beta = betaValue;

    info.equalityResidual = equalityResidual;

    info.minimumEigenvalueP = ...
        candidateChecks.minimumEigenvalueP;

    info.maximumEigenvalueLyapunov = ...
        candidateChecks.maximumEigenvalueLyapunov;

    info.minimumEigenvalueLMI1 = ...
        candidateChecks.minimumEigenvalueLMI1;

    info.minimumEigenvalueLMI2 = ...
        candidateChecks.minimumEigenvalueLMI2;

    info.relativePerturbation = ...
        relativePerturbation;

    info.wGamma = wGamma;
    info.wBeta = wBeta;

    info.problemOriginal = ...
        selectedDiagnostic.problem;

    % A feasible numerical candidate has been independently checked.
    % This allows the calling routine to continue to the separate,
    % exact KYP certification.
    info.problem = 0;

    %% Report

    fprintf('\n=== Accepted Problem 2 solution ===\n');

    fprintf( ...
        'Selected solver: %s\n', ...
        upper(selectedSolver));

    fprintf( ...
        'Original solver status: %s\n', ...
        selectedDiagnostic.info);

    if info.acceptedAfterNumericalCheck
        fprintf([ ...
            'The solver reported a numerical warning, but the\n', ...
            'candidate satisfies all implemented LMIs within tolerance.\n']);
    end

    fprintf( ...
        'wGamma = %.4f | wBeta = %.4f\n', ...
        wGamma,wBeta);

    fprintf('gamma = %.6e\n',gammaValue);
    fprintf('beta  = %.6e\n',betaValue);

    fprintf( ...
        '||DeltaC||_2 / ||C||_2 = %.6e\n', ...
        relativePerturbation);

    fprintf( ...
        '||PB-Cpass''||_2       = %.6e\n', ...
        equalityResidual);

    fprintf( ...
        'lambda_min(P)          = %.6e\n', ...
        candidateChecks.minimumEigenvalueP);

    fprintf( ...
        'lambda_max(PA+A''P)    = %.6e\n', ...
        candidateChecks.maximumEigenvalueLyapunov);

    fprintf( ...
        'lambda_min(LMI1)       = %.6e\n', ...
        candidateChecks.minimumEigenvalueLMI1);

    fprintf( ...
        'lambda_min(LMI2)       = %.6e\n', ...
        candidateChecks.minimumEigenvalueLMI2);
end

%% =====================================================================
% Local functions
% ======================================================================

function checks = check_candidate( ...
    A,B,C,DeltaC,P,gamma,beta,epsilonP,tolerance)

    n = size(A,1);
    p = size(C,1);

    P = (P+P')/2;

    Cpass = C+DeltaC;

    matrixLMI1 = [
        gamma*eye(p), DeltaC
        DeltaC', gamma*eye(n)
    ];

    equalityResidualMatrix = ...
        P*B-Cpass';

    matrixLMI2 = [
        beta*eye(n), equalityResidualMatrix
        equalityResidualMatrix', beta*eye(p)
    ];

    lyapunovMatrix = ...
        P*A+A'*P;

    checks.minimumEigenvalueLMI1 = min( ...
        eig((matrixLMI1+matrixLMI1')/2));

    checks.minimumEigenvalueLMI2 = min( ...
        eig((matrixLMI2+matrixLMI2')/2));

    checks.minimumEigenvalueP = min( ...
        eig(P));

    checks.maximumEigenvalueLyapunov = max( ...
        eig((lyapunovMatrix+lyapunovMatrix')/2));

    checks.gammaNonnegative = ...
        gamma >= -tolerance;

    checks.betaNonnegative = ...
        beta >= -tolerance;

    scaleLMI1 = max(1,norm(matrixLMI1,2));
    scaleLMI2 = max(1,norm(matrixLMI2,2));
    scaleP = max(1,norm(P,2));
    scaleLyapunov = max(1,norm(lyapunovMatrix,2));

    checks.LMI1satisfied = ...
        checks.minimumEigenvalueLMI1 >= ...
        -tolerance*scaleLMI1;

    checks.LMI2satisfied = ...
        checks.minimumEigenvalueLMI2 >= ...
        -tolerance*scaleLMI2;

    checks.Psatisfied = ...
        checks.minimumEigenvalueP >= ...
        epsilonP-tolerance*scaleP;

    checks.lyapunovSatisfied = ...
        checks.maximumEigenvalueLyapunov <= ...
        tolerance*scaleLyapunov;

    checks.feasible = ...
        checks.LMI1satisfied && ...
        checks.LMI2satisfied && ...
        checks.Psatisfied && ...
        checks.lyapunovSatisfied && ...
        checks.gammaNonnegative && ...
        checks.betaNonnegative;
end

function print_candidate_checks( ...
    solverName,diagnostic,checks)

    fprintf( ...
        '   Solver status: %s\n', ...
        diagnostic.info);

    fprintf( ...
        '   lambda_min(LMI1):    %.6e\n', ...
        checks.minimumEigenvalueLMI1);

    fprintf( ...
        '   lambda_min(LMI2):    %.6e\n', ...
        checks.minimumEigenvalueLMI2);

    fprintf( ...
        '   lambda_min(P):       %.6e\n', ...
        checks.minimumEigenvalueP);

    fprintf( ...
        '   lambda_max(PA+A''P): %.6e\n', ...
        checks.maximumEigenvalueLyapunov);

    if checks.feasible
        fprintf( ...
            '   %s candidate accepted by explicit LMI checks.\n', ...
            upper(solverName));
    else
        fprintf( ...
            '   %s candidate rejected by explicit LMI checks.\n', ...
            upper(solverName));
    end
end