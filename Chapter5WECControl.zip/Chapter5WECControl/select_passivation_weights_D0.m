function selection = select_passivation_weights_D0( ...
    A,B,Cvertices,wValidation,varargin)
%======================================================================
% SELECT_PASSIVATION_WEIGHTS_D0
%
% Selects common weights for Problem 2 of Faedo et al. (2021).
%
% For every candidate pair
%
%   wBeta = 1-wGamma,
%
% the routine:
%
%   1. applies passivation_LMI_D0 to every vertex;
%   2. constructs the resulting models;
%   3. performs an independent exact KYP passivity test;
%   4. quantifies the perturbation of C;
%   5. quantifies magnitude and phase changes;
%   6. accepts the weight only if every vertex is certified;
%   7. selects the largest certified wGamma.
%
% Inputs:
%   A            : common state matrix;
%   B            : common input matrix;
%   Cvertices    : one C matrix per row;
%   wValidation  : frequency grid used to quantify model changes;
%
% Optional input:
%   candidateWGammas : vector of candidate wGamma values.
%
% Output:
%   selection.selectedWGamma
%   selection.selectedWBeta
%   selection.Cpass
%   selection.models
%   selection.passivationInfo
%   selection.certificates
%   selection.table
%======================================================================

    %% Candidate weights

    if nargin >= 5 && ~isempty(varargin{1})
        candidateWGammas = varargin{1}(:);
    else
        candidateWGammas = (0:0.05:0.80).';
    end

    candidateWGammas = unique(candidateWGammas);

    assert(all(candidateWGammas>=0), ...
        'All candidate weights must be non-negative.');

    assert(all(candidateWGammas<=1), ...
        'All candidate weights must be no greater than one.');

    %% Dimensions

    nVertices = size(Cvertices,1);
    nStates = size(A,1);

    assert(size(Cvertices,2)==nStates, ...
        'Each row of Cvertices must define one output matrix.');

    assert(size(B,2)==1, ...
        'This implementation assumes a SISO system.');

    assert(all(real(eig(A))<0), ...
        'A must be asymptotically stable.');

    wValidation = wValidation(:);

    nCandidates = numel(candidateWGammas);

    %% Allocate diagnostics

    allCertified = false(nCandidates,1);
    numberCertified = zeros(nCandidates,1);

    maximumRelativePerturbation = ...
        nan(nCandidates,1);

    meanRelativePerturbation = ...
        nan(nCandidates,1);

    maximumBeta = nan(nCandidates,1);
    maximumEqualityResidual = nan(nCandidates,1);

    maximumMagnitudeChangeDB = ...
        nan(nCandidates,1);

    maximumPhaseChangeRad = ...
        nan(nCandidates,1);

    candidateResults = cell(nCandidates,1);

    fprintf('\n=====================================================\n');
    fprintf(' AUTOMATIC PASSIVATION-WEIGHT SELECTION\n');
    fprintf('=====================================================\n');

    %% Evaluate every candidate

    for candidateIndex = 1:nCandidates

        wGamma = candidateWGammas(candidateIndex);
        wBeta = 1-wGamma;

        fprintf( ...
            '\nTesting wGamma = %.4f, wBeta = %.4f\n', ...
            wGamma,wBeta);

        CpassCandidate = nan(size(Cvertices));
        modelsCandidate = cell(nVertices,1);

        infoCandidate = cell(nVertices,1);
        certificatesCandidate = cell(nVertices,1);

        relativePerturbations = nan(nVertices,1);
        betaValues = nan(nVertices,1);
        equalityResiduals = nan(nVertices,1);

        magnitudeChangesDB = nan(nVertices,1);
        phaseChangesRad = nan(nVertices,1);

        vertexCertified = false(nVertices,1);
        candidateFailed = false;

        for vertexIndex = 1:nVertices

            Ccurrent = Cvertices(vertexIndex,:);

            try
                % Suppress the extensive solver output during the sweep.
                solverOutput = evalc( ...
                    ['[DeltaC,~,infoCurrent] = ', ...
                     'passivation_LMI_D0(', ...
                     'A,B,Ccurrent,wGamma,wBeta);']);

            catch exception
                fprintf( ...
                    '   Vertex %d: optimisation failed: %s\n', ...
                    vertexIndex,exception.message);

                candidateFailed = true;
                break;
            end

            
            infoCandidate{vertexIndex} = infoCurrent;

            CpassCurrent = Ccurrent+DeltaC;

            modelRaw = ss(A,B,Ccurrent,0);
            modelPass = ss(A,B,CpassCurrent,0);

            certificateCurrent = ...
                certify_passivity_D0_local( ...
                    A,B,CpassCurrent);

            certificatesCandidate{vertexIndex} = ...
                certificateCurrent;

            vertexCertified(vertexIndex) = ...
                certificateCurrent.certified;

            CpassCandidate(vertexIndex,:) = ...
                CpassCurrent;

            modelsCandidate{vertexIndex} = ...
                modelPass;

            relativePerturbations(vertexIndex) = ...
                norm(DeltaC,2)/max(norm(Ccurrent,2),eps);

            betaValues(vertexIndex) = ...
                infoCurrent.beta;

            equalityResiduals(vertexIndex) = ...
                infoCurrent.equalityResidual;

            Graw = squeeze(freqresp( ...
                modelRaw,wValidation));

            Gpass = squeeze(freqresp( ...
                modelPass,wValidation));

            magnitudeDifferenceDB = ...
                20*log10(max(abs(Gpass),eps)) - ...
                20*log10(max(abs(Graw),eps));

            phaseDifference = angle(exp( ...
                1i*(angle(Gpass)-angle(Graw))));

            magnitudeChangesDB(vertexIndex) = ...
                max(abs(magnitudeDifferenceDB));

            phaseChangesRad(vertexIndex) = ...
                max(abs(phaseDifference));

            fprintf( ...
                ['   Vertex %d: certified=%d, ', ...
                 'relative perturbation=%.4e, beta=%.4e\n'], ...
                vertexIndex, ...
                certificateCurrent.certified, ...
                relativePerturbations(vertexIndex), ...
                betaValues(vertexIndex));
        end

        if candidateFailed
            continue;
        end

        numberCertified(candidateIndex) = ...
            nnz(vertexCertified);

        allCertified(candidateIndex) = ...
            all(vertexCertified);

        maximumRelativePerturbation(candidateIndex) = ...
            max(relativePerturbations);

        meanRelativePerturbation(candidateIndex) = ...
            mean(relativePerturbations);

        maximumBeta(candidateIndex) = ...
            max(betaValues);

        maximumEqualityResidual(candidateIndex) = ...
            max(equalityResiduals);

        maximumMagnitudeChangeDB(candidateIndex) = ...
            max(magnitudeChangesDB);

        maximumPhaseChangeRad(candidateIndex) = ...
            max(phaseChangesRad);

        candidateResults{candidateIndex} = struct( ...
            'wGamma',wGamma, ...
            'wBeta',wBeta, ...
            'Cpass',CpassCandidate, ...
            'models',{modelsCandidate}, ...
            'passivationInfo',{infoCandidate}, ...
            'certificates',{certificatesCandidate}, ...
            'relativePerturbations',relativePerturbations, ...
            'betaValues',betaValues, ...
            'equalityResiduals',equalityResiduals, ...
            'magnitudeChangesDB',magnitudeChangesDB, ...
            'phaseChangesRad',phaseChangesRad, ...
            'vertexCertified',vertexCertified);

        if allCertified(candidateIndex)
            fprintf('   All vertices certified.\n');
        else
            fprintf( ...
                '   Only %d of %d vertices certified.\n', ...
                numberCertified(candidateIndex), ...
                nVertices);
        end
    end

    %% Construct summary table

    candidateWBetas = 1-candidateWGammas;

    summaryTable = table( ...
        candidateWGammas, ...
        candidateWBetas, ...
        numberCertified, ...
        allCertified, ...
        maximumRelativePerturbation, ...
        meanRelativePerturbation, ...
        maximumBeta, ...
        maximumEqualityResidual, ...
        maximumMagnitudeChangeDB, ...
        maximumPhaseChangeRad, ...
        'VariableNames',{ ...
            'wGamma', ...
            'wBeta', ...
            'NumberCertified', ...
            'AllCertified', ...
            'MaximumRelativePerturbation', ...
            'MeanRelativePerturbation', ...
            'MaximumBeta', ...
            'MaximumEqualityResidual', ...
            'MaximumMagnitudeChangeDB', ...
            'MaximumPhaseChangeRad'});

    disp(summaryTable);

    %% Select largest certified wGamma

    certifiedIndices = find(allCertified);

    if isempty(certifiedIndices)
        error([ ...
            'No candidate weight pair produced KYP-certified ', ...
            'passivity for every vertex. Refine the candidate grid ', ...
            'or reconsider the passivation formulation.']);
    end

    [~,localMaximumIndex] = max( ...
        candidateWGammas(certifiedIndices));

    selectedIndex = ...
        certifiedIndices(localMaximumIndex);

    selectedResult = ...
        candidateResults{selectedIndex};

    %% Output

    selection.selectedWGamma = ...
        selectedResult.wGamma;

    selection.selectedWBeta = ...
        selectedResult.wBeta;

    selection.Cpass = ...
        selectedResult.Cpass;

    selection.models = ...
        selectedResult.models;

    selection.passivationInfo = ...
        selectedResult.passivationInfo;

    selection.certificates = ...
        selectedResult.certificates;

    selection.relativePerturbations = ...
        selectedResult.relativePerturbations;

    selection.betaValues = ...
        selectedResult.betaValues;

    selection.equalityResiduals = ...
        selectedResult.equalityResiduals;

    selection.magnitudeChangesDB = ...
        selectedResult.magnitudeChangesDB;

    selection.phaseChangesRad = ...
        selectedResult.phaseChangesRad;

    selection.selectedIndex = selectedIndex;
    selection.table = summaryTable;

    fprintf('\n=====================================================\n');

    fprintf( ...
        ' Selected wGamma = %.4f\n', ...
        selection.selectedWGamma);

    fprintf( ...
        ' Selected wBeta  = %.4f\n', ...
        selection.selectedWBeta);

    fprintf( ...
        ' Maximum relative perturbation = %.6e\n', ...
        max(selection.relativePerturbations));

    fprintf( ...
        ' Maximum magnitude change = %.6f dB\n', ...
        max(selection.magnitudeChangesDB));

    fprintf( ...
        ' Maximum phase change = %.6f rad\n', ...
        max(selection.phaseChangesRad));

    fprintf(' All vertices are KYP-certified as passive.\n');
    fprintf('=====================================================\n');

    %% Diagnostic plots

    % Retained for optional diagnostic use. Disabled in the thesis workflow.
    if false
    figure('Color','w');

    tiledlayout(2,2, ...
        'TileSpacing','compact', ...
        'Padding','compact');

    nexttile;
    hold on;
    box on;
    grid on;

    plot( ...
        candidateWGammas, ...
        numberCertified, ...
        'o-', ...
        'LineWidth',1.8, ...
        'MarkerSize',6);

    yline(nVertices,'k--', ...
        'HandleVisibility','off');

    xline(selection.selectedWGamma,'r--', ...
        'Selected', ...
        'LabelVerticalAlignment','bottom');

    xlabel('$w_\gamma$');
    ylabel('Certified vertices');
    ylim([-0.1,nVertices+0.2]);

    nexttile;
    hold on;
    box on;
    grid on;

    semilogy( ...
        candidateWGammas, ...
        maximumRelativePerturbation, ...
        'o-', ...
        'LineWidth',1.8, ...
        'MarkerSize',6);

    xline(selection.selectedWGamma,'r--', ...
        'HandleVisibility','off');

    xlabel('$w_\gamma$');
    ylabel('Maximum $\|\Delta C_i\|_2/\|C_i\|_2$');

    nexttile;
    hold on;
    box on;
    grid on;

    semilogy( ...
        candidateWGammas, ...
        maximumEqualityResidual, ...
        'o-', ...
        'LineWidth',1.8, ...
        'MarkerSize',6);

    xline(selection.selectedWGamma,'r--', ...
        'HandleVisibility','off');

    xlabel('$w_\gamma$');
    ylabel('Maximum KYP equality residual');

    nexttile;
    hold on;
    box on;
    grid on;

    plot( ...
        candidateWGammas, ...
        maximumPhaseChangeRad, ...
        'o-', ...
        'LineWidth',1.8, ...
        'MarkerSize',6);

    xline(selection.selectedWGamma,'r--', ...
        'HandleVisibility','off');

    xlabel('$w_\gamma$');
    ylabel('Maximum phase change [rad]');

    exportgraphics( ...
        gcf, ...
        'Passivation_weight_selection.pdf', ...
        'ContentType','vector');
    end
end

%% =====================================================================
% Independent exact KYP certification
% ======================================================================

function certificate = certify_passivity_D0_local(A,B,C)

    n = size(A,1);

    P = sdpvar(n,n,'symmetric');

    epsilonP = 1e-9;

    constraints = [
        P >= epsilonP*eye(n)
        P*A+A'*P <= 0
        P*B == C'
    ];

    options = sdpsettings( ...
        'solver','sedumi', ...
        'verbose',0);

    diagnostic = optimize( ...
        constraints,[],options);

    certificate.certified = false;
    certificate.solverStatus = diagnostic.info;
    certificate.P = [];

    certificate.equalityResidual = Inf;
    certificate.minimumEigenvalueP = -Inf;
    certificate.maximumEigenvalueLyapunov = Inf;

    Pvalue = value(P);

    % A numerical warning from the solver does not, by itself, prove that
    % the candidate is infeasible. If a finite matrix was returned, assess
    % the KYP relations explicitly below.
    if isempty(Pvalue) || any(~isfinite(Pvalue(:)))
        return;
    end

    Pvalue = (Pvalue+Pvalue')/2;

    equalityResidual = norm( ...
        Pvalue*B-C',2);

    lyapunovMatrix = ...
        Pvalue*A+A'*Pvalue;

    minimumEigenvalueP = ...
        min(eig(Pvalue));

    maximumEigenvalueLyapunov = max( ...
        eig((lyapunovMatrix+lyapunovMatrix')/2));

    residualTolerance = 1e-7;
    eigenvalueTolerance = 1e-7;

    certificate.certified = ...
        equalityResidual<=residualTolerance && ...
        minimumEigenvalueP>=-eigenvalueTolerance && ...
        maximumEigenvalueLyapunov<=eigenvalueTolerance;

    certificate.P = Pvalue;

    certificate.equalityResidual = ...
        equalityResidual;

    certificate.minimumEigenvalueP = ...
        minimumEigenvalueP;

    certificate.maximumEigenvalueLyapunov = ...
        maximumEigenvalueLyapunov;
end
