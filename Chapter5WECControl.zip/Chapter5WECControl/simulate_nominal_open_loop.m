%% ============================================================
%  NOMINAL OPEN-LOOP SIMULATION: ISS1--ISS3 OR ISS1--ISS6
%
%  This auxiliary routine uses the same Simulink model, nominal WEC model,
%  PTO dynamics and variable kinematic conversion used in the closed-loop
%  simulations. All controller gains are set to zero.
%
%  Required variables from the main routine:
%    IMresults, A_nominal, Be_nominal, Cz_nominal,
%    A_PTO, B_PTO, C_PTO and D_PTO.
%
%  The script does not clear the MATLAB workspace.
% ============================================================

%% ============================================================
%  USER CONFIGURATION
% ============================================================

modelName = 'Wavestar_simulink_controllers';

% Choose 3 for ISS1--ISS3 or 6 for ISS1--ISS6.
lastSeaStateOpenLoop = 3;
 %lastSeaStateOpenLoop = 6;

assert(ismember(lastSeaStateOpenLoop,[3 6]), ...
    'lastSeaStateOpenLoop must be either 3 or 6.');

seaStateIndicesOpenLoop = 1:lastSeaStateOpenLoop;
numberSeaStatesOpenLoop = numel(seaStateIndicesOpenLoop);
seaStateSetLabelOpenLoop = sprintf( ...
    'ISS1_ISS%d',lastSeaStateOpenLoop);

if ~exist('baseDir','var') || isempty(baseDir)
    baseDir = pwd;
end

openLoopResultsFile = fullfile( ...
    baseDir, ...
    ['open_loop_nominal_' seaStateSetLabelOpenLoop '.mat']);

%% ============================================================
%  CHECK REQUIRED VARIABLES
% ============================================================

requiredVariablesOpenLoop = { ...
    'IMresults', ...
    'A_nominal','Be_nominal','Cz_nominal', ...
    'A_PTO','B_PTO','C_PTO','D_PTO'};

for variableIndex = 1:numel(requiredVariablesOpenLoop)
    assert(exist(requiredVariablesOpenLoop{variableIndex},'var')==1, ...
        'Required variable %s is not available.', ...
        requiredVariablesOpenLoop{variableIndex});
end

assert(numel(IMresults)>=lastSeaStateOpenLoop, ...
    'IMresults must contain ISS1--ISS%d.', ...
    lastSeaStateOpenLoop);

%% ============================================================
%  NOMINAL MODEL AND ZERO CONTROLLER GAINS
% ============================================================

A_mid = A_nominal;
B_mid = Be_nominal;
Be_mid = Be_nominal;
Cz_mid = Cz_nominal;

Dzu_mid = zeros( ...
    size(Cz_nominal,1),size(Be_nominal,2));
Dze_mid = zeros( ...
    size(Cz_nominal,1),size(Be_nominal,2));

x0_WEC = zeros(size(A_nominal,1),1);
x0_PTO = zeros(size(A_PTO,1),1);

K_p_open = 0;
K_r_open = 0;
K_i_open = 0;
KH2_open = zeros(1,size(A_nominal,1));
KHinf_open = zeros(1,size(A_nominal,1));

% Force saturation remains consistent with the closed-loop model. Since
% all controller gains are zero, no control-force saturation is expected.
forceLimitOpenLoop_N = inf;
PTO_force_min = -forceLimitOpenLoop_N;
PTO_force_max = forceLimitOpenLoop_N;

%% ============================================================
%  OUTPUT STRUCTURE
% ============================================================

openLoopResults = struct();
openLoopResults.description = ...
    ['Nominal open-loop WEC simulations using the complete Simulink ' ...
    'model, PTO dynamics and variable kinematic conversion.'];
openLoopResults.creationDate = ...
    char(datetime('now','Format','yyyy-MM-dd HH:mm:ss'));
openLoopResults.modelName = modelName;
openLoopResults.configuration.model = 'Nominal WEC model';
openLoopResults.configuration.controllerGains = 'All gains set to zero';
openLoopResults.configuration.seaStateIndices = ...
    seaStateIndicesOpenLoop;
openLoopResults.configuration.forceLimit_N = ...
    forceLimitOpenLoop_N;
openLoopResults.seaStates = struct([]);

%% ============================================================
%  RUN OPEN-LOOP SIMULATIONS
% ============================================================

load_system(modelName);
Simulink.sdi.setRecordData(true);

fprintf('\n============================================================\n');
fprintf('NOMINAL OPEN-LOOP SIMULATION: ISS1--ISS%d\n', ...
    lastSeaStateOpenLoop);
fprintf('All controller gains are zero\n');
fprintf('============================================================\n');

for simulationIndex = 1:numberSeaStatesOpenLoop

    seaStateIndex = seaStateIndicesOpenLoop(simulationIndex);
    selectedISS = IMresults(seaStateIndex);

    input_torque = selectedISS.f_e_timeseries;
    t_end = selectedISS.t(end);
    dt = selectedISS.dt;

    assert(isa(input_torque,'timeseries'), ...
        'Excitation input is not a timeseries for %s.', ...
        selectedISS.label);

    fprintf('\nSimulation %d/%d: %s\n', ...
        simulationIndex,numberSeaStatesOpenLoop, ...
        selectedISS.label);

    simulationInput = Simulink.SimulationInput(modelName);

    simulationInput = simulationInput.setVariable( ...
        'A_mid',A_nominal);
    simulationInput = simulationInput.setVariable( ...
        'B_mid',Be_nominal);
    simulationInput = simulationInput.setVariable( ...
        'Be_mid',Be_nominal);
    simulationInput = simulationInput.setVariable( ...
        'B_min',Be_nominal);
    simulationInput = simulationInput.setVariable( ...
        'Be_min',Be_nominal);
    simulationInput = simulationInput.setVariable( ...
        'Cz_mid',Cz_nominal);
    simulationInput = simulationInput.setVariable( ...
        'Dzu_mid',Dzu_mid);
    simulationInput = simulationInput.setVariable( ...
        'Dze_mid',Dze_mid);

    simulationInput = simulationInput.setVariable('A_PTO',A_PTO);
    simulationInput = simulationInput.setVariable('B_PTO',B_PTO);
    simulationInput = simulationInput.setVariable('C_PTO',C_PTO);
    simulationInput = simulationInput.setVariable('D_PTO',D_PTO);

    simulationInput = simulationInput.setVariable('x0_WEC',x0_WEC);
    simulationInput = simulationInput.setVariable('x0_PTO',x0_PTO);
    simulationInput = simulationInput.setVariable( ...
        'input_torque',input_torque);
    simulationInput = simulationInput.setVariable('dt',dt);

    simulationInput = simulationInput.setVariable('K_p',K_p_open);
    simulationInput = simulationInput.setVariable('K_r',K_r_open);
    simulationInput = simulationInput.setVariable('K_i',K_i_open);
    simulationInput = simulationInput.setVariable('KH2_best',KH2_open);
    simulationInput = simulationInput.setVariable( ...
        'KHinfty_best',KHinf_open);

    simulationInput = simulationInput.setVariable( ...
        'PTO_force_min',PTO_force_min);
    simulationInput = simulationInput.setVariable( ...
        'PTO_force_max',PTO_force_max);

    simulationInput = simulationInput.setModelParameter( ...
        'StartTime','0', ...
        'StopTime',num2str(t_end,'%.15g'), ...
        'ReturnWorkspaceOutputs','on');

    simulationOutputOpenLoop = sim(simulationInput);
    availableOutputs = simulationOutputOpenLoop.who;

    % Any branch can be used because every controller gain is zero. The
    % passive branch is selected as the common open-loop output.
    signalDefinitions = {
        'angularVelocity',   'angularVelocity_p'
        'angularPosition',   'angularPosition_p'
        'PTOvelocity',       'vPTO_p'
        'PTOdisplacement',   'zPTO_p'
        'kinematicJacobian', 'KinematicJacobian_p'
        'PTOforce',          'fu_PTO_sat_p'
        'PTOpower',          'PTOpower_p'
    };

    time = simulationOutputOpenLoop.tout(:);
    seaStateResult = struct();
    seaStateResult.label = selectedISS.label;
    seaStateResult.source = selectedISS.source;
    seaStateResult.time_s = time;
    seaStateResult.duration_s = time(end)-time(1);
    seaStateResult.dt_s = dt;
    seaStateResult.Tp_s = selectedISS.Tp;
    seaStateResult.excitationTorque_Nm = interp1( ...
        input_torque.Time(:),input_torque.Data(:),time, ...
        'linear','extrap');

    for signalIndex = 1:size(signalDefinitions,1)
        storedName = signalDefinitions{signalIndex,1};
        outputName = signalDefinitions{signalIndex,2};

        assert(any(strcmp(availableOutputs,outputName)), ...
            'Required output %s was not returned.',outputName);

        seaStateResult.(storedName) = ...
            localOpenLoopSignalColumn( ...
            simulationOutputOpenLoop.(outputName));

        assert(numel(seaStateResult.(storedName))==numel(time), ...
            'Unexpected length for %s in %s.', ...
            storedName,selectedISS.label);
        assert(all(isfinite(seaStateResult.(storedName))), ...
            'NaN or Inf in %s for %s.', ...
            storedName,selectedISS.label);
    end

    seaStateResult.relativePTOdisplacement = ...
        seaStateResult.PTOdisplacement ...
        -seaStateResult.PTOdisplacement(1);

    seaStateResult.metrics.peakPTOvelocity_mps = ...
        max(abs(seaStateResult.PTOvelocity));
    seaStateResult.metrics.peakRelativeStroke_m = ...
        max(abs(seaStateResult.relativePTOdisplacement));
    seaStateResult.metrics.peakAngularVelocity_radps = ...
        max(abs(seaStateResult.angularVelocity));
    seaStateResult.metrics.peakAngularPosition_rad = ...
        max(abs(seaStateResult.angularPosition));

    if simulationIndex==1
        openLoopResults.seaStates = seaStateResult;
    else
        openLoopResults.seaStates(simulationIndex,1) = ...
            seaStateResult;
    end

    openLoopResults.completedSeaStates = ...
        seaStateIndicesOpenLoop(1:simulationIndex);

    save(openLoopResultsFile,'openLoopResults','-v7.3');

    fprintf(['Completed %s: peak PTO velocity = %.4f m/s, ' ...
        'peak stroke = %.4f m\n'], ...
        selectedISS.label, ...
        seaStateResult.metrics.peakPTOvelocity_mps, ...
        seaStateResult.metrics.peakRelativeStroke_m);

    Simulink.sdi.clear;
end

openLoopResults.completed = true;
openLoopResults.completionDate = ...
    char(datetime('now','Format','yyyy-MM-dd HH:mm:ss'));

save(openLoopResultsFile,'openLoopResults','-v7.3');

fprintf('\n============================================================\n');
fprintf('OPEN-LOOP SIMULATIONS COMPLETED\n');
fprintf('============================================================\n');
fprintf('Results saved to:\n%s\n',openLoopResultsFile);

%% ============================================================
%  LOCAL FUNCTION
% ============================================================

function signalColumn = localOpenLoopSignalColumn(signalValue)

if isa(signalValue,'timeseries')
    signalColumn = signalValue.Data(:);
elseif isa(signalValue,'timetable')
    signalColumn = signalValue.Variables(:);
elseif isnumeric(signalValue) || islogical(signalValue)
    signalColumn = signalValue(:);
else
    error('Unsupported Simulink output class: %s.', ...
        class(signalValue));
end

end

