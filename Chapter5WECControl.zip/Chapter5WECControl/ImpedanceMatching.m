function [f_e_timeseries,K_p,K_r,K_i,K_reactive] = ...
    ImpedanceMatching(f_e,t,omega,T_p,G)
%==========================================================================
% IMPEDANCEMATCHING
%
% Calculation of passive and reactive controller gains using an
% approximation of the impedance-matching principle.
%
% Passive controller:
%
%   f_u(t) = K_p*z(t)
%
% Reactive controller:
%
%   K_reactive(s) = K_r + K_i/s
%
% INPUTS
%   f_e       Wave-excitation force
%   t         Time vector
%   omega     Angular-frequency vector
%   T_p       Sea-state peak period
%   G         WEC force-to-velocity model
%
% OUTPUTS
%   f_e_timeseries   Wave-excitation-force time series
%   K_p              Passive-controller gain
%   K_r              Reactive proportional gain
%   K_i              Reactive integral gain
%   K_reactive       Reactive PI controller
%==========================================================================

%% Wave-excitation-force time series

f_e_timeseries = timeseries(f_e,t);

%% Frequency-response model

G_frd = frd( ...
    freqresp(G,omega), ...
    omega);

%% Optimal impedance-matching condition

K_opt = 1/G_frd';
%T_opt = G_frd / ( 1 + G_frd * K_opt );
%bode(T_opt)

%% Sea-state peak angular frequency

omega_p = 2*pi/T_p;

if omega_p<min(omega) || omega_p>max(omega)

    warning( ...
        ['The peak angular frequency %.4f rad/s lies outside ', ...
         'the frequency interval [%.4f, %.4f] rad/s.'], ...
        omega_p,min(omega),max(omega));
end

%% Optimal controller response at the peak frequency

K_opt_p = squeeze( ...
    freqresp(K_opt,omega_p));

%% Passive-controller gain

K_p = abs(K_opt_p);

%% Reactive-controller gains

K_r = real(K_opt_p);

K_i = -omega_p*imag(K_opt_p);

s = tf('s');

K_reactive = K_r+K_i/s;

end