function figures = plot_identification_results_v3(results,outputDir)
%PLOT_IDENTIFICATION_RESULTS_V3 Create the thesis figures for identified models.
%
% The routine generates five vector PDF figures:
%   1. Passivised WNSS1--WNSS3 responses and their pointwise range.
%   2. Passivised minimum, nominal, maximum and BEM models.
%   3. Nyquist diagram of the minimum, nominal, maximum and BEM models.
%   4. Passivity indicators of WNSS1--WNSS3, before and after passivation.
%   5. WNSS1--WNSS3 frequency responses before and after passivation.
%
% For a SISO system, the passivity indicator is
%   P(w) = lambda_min{G(jw)+G(jw)^H} = 2*real{G(jw)}.

% Usage:
%   figures = plot_identification_results_v3(results);
%   figures = plot_identification_results_v3(results,baseDir);


    if nargin < 2 || isempty(outputDir)
        outputDir = pwd;
    end

    if ~isfolder(outputDir)
        error('The output directory does not exist: %s',outputDir);
    end

    validate_results_structure(results);

    %% Unified thesis style

    axesFontSize   = 16;
    legendFontSize = 14;
    lineWidth      = 2.4;
    figureWidth    = 20;
    figureHeight   = 14;

    greenColours = [
        0.05 0.30 0.20
        0.20 0.50 0.35
        0.55 0.75 0.60
    ];

    uncertaintyColour = [0.78 0.90 0.82];
    nominalColour     = [0 0 0];
    bemColour         = [0.25 0.45 0.70];
    minColour         = greenColours(1,:);
    maxColour         = greenColours(3,:);
    beforeColour      = greenColours(2,:);
    afterColour       = greenColours(1,:);
    zeroColour        = [0.45 0.45 0.45];
    nonPassiveColour  = [0.86 0.92 0.87];
    vertexLineStyles  = {'-','--',':'};

    set(groot,'DefaultAxesFontSize',axesFontSize);
    set(groot,'DefaultTextInterpreter','latex');
    set(groot,'DefaultAxesTickLabelInterpreter','latex');
    set(groot,'DefaultLegendInterpreter','latex');
    set(groot,'DefaultLegendFontSize',legendFontSize);
    set(groot,'DefaultAxesLabelFontSizeMultiplier',1.2);

    %% Responses and pointwise WNSS range

    nVertices   = numel(results.vertices);
    vertexLabels = {results.vertices.label}.';
    w            = results.responses.frequency(:);
    Gvertices    = results.responses.vertices;

    if nVertices ~= 3
        error('Exactly three WNSS vertices are required; %d were supplied.',nVertices);
    end

    if size(Gvertices,1) ~= numel(w) || size(Gvertices,2) ~= nVertices
        error('results.responses.vertices has dimensions inconsistent with the frequency grid.');
    end

    vertexMagnitudeDB = 20*log10(abs(Gvertices));
    vertexPhase       = unwrap(angle(Gvertices),[],1);

    vertexMagnitudeLower = min(vertexMagnitudeDB,[],2);
    vertexMagnitudeUpper = max(vertexMagnitudeDB,[],2);
    vertexPhaseLower     = min(vertexPhase,[],2);
    vertexPhaseUpper     = max(vertexPhase,[],2);

    Gmin = column_response(results.min.sys_pass,w);
    Gnom = column_response(results.nominal.sys_pass,w);
    Gmax = column_response(results.max.sys_pass,w);
    GBEM = column_response(results.sys_BEM,w);

    bemMagnitudeDB = 20*log10(abs(GBEM));
    bemPhase       = unwrap(angle(GBEM));

    boundaryMagnitudeDB = [
        20*log10(abs(Gmin)), ...
        20*log10(abs(Gnom)), ...
        20*log10(abs(Gmax))];

    boundaryPhase = align_phase_columns([ ...
        unwrap(angle(Gmin)), ...
        unwrap(angle(Gnom)), ...
        unwrap(angle(Gmax))]);

    boundaryMagnitudeLower = min(boundaryMagnitudeDB(:,[1 3]),[],2);
    boundaryMagnitudeUpper = max(boundaryMagnitudeDB(:,[1 3]),[],2);
    boundaryPhaseLower     = min(boundaryPhase(:,[1 3]),[],2);
    boundaryPhaseUpper     = max(boundaryPhase(:,[1 3]),[],2);

    % %% Figure 1: WNSS1--WNSS3 and uncertainty region
    % 
    % figures.vertices = figure( ...
    %     'Color','w', ...
    %     'Name','Passivised WNSS responses', ...
    %     'Units','centimeters', ...
    %     'Position',[2 2 figureWidth figureHeight]);
    % 
    % layout1 = tiledlayout(2,1,'TileSpacing','compact','Padding','compact');
    % 
    % ax = nexttile;
    % hold(ax,'on'); box(ax,'on'); grid(ax,'on');
    % fill_range(w,vertexMagnitudeLower,vertexMagnitudeUpper, ...
    %     uncertaintyColour,'Uncertainty region',true);
    % 
    % for i = 1:nVertices
    %     plot(w,vertexMagnitudeDB(:,i), ...
    %         'Color',greenColours(i,:), ...
    %         'LineStyle',vertexLineStyles{i}, ...
    %         'LineWidth',lineWidth, ...
    %         'DisplayName',escape_label(vertexLabels{i}));
    % end
    % 
    % ylabel('$|G(j\omega)|$ [dB]');
    % xlim([0 10]);
    % set(gca,'XTickLabel',[]);
    % % title('Magnitude response');
    % 
    % ax = nexttile;
    % hold(ax,'on'); box(ax,'on'); grid(ax,'on');
    % fill_range(w,vertexPhaseLower,vertexPhaseUpper, ...
    %     uncertaintyColour,'Uncertainty region',true);
    % 
    % for i = 1:nVertices
    %     plot(w,vertexPhase(:,i), ...
    %         'Color',greenColours(i,:), ...
    %         'LineStyle',vertexLineStyles{i}, ...
    %         'LineWidth',lineWidth, ...
    %         'DisplayName',escape_label(vertexLabels{i}));
    % end
    % 
    % xlabel('$\omega$ [rad/s]');
    % ylabel('$\angle G(j\omega)$ [rad]');
    % xlim([0 10]);
    % legend('Location','southeast');
    % % title('Phase response');
    % % title(layout1,'Passivised WNSS responses');
    % 
    % figures.vertices_file = fullfile(outputDir, ...
    %     'WNSS_vertices_with_uncertainty.pdf');
    % exportgraphics(figures.vertices,figures.vertices_file,'ContentType','vector');

    %% Figure 2: minimum, nominal, maximum and BEM models

    figures.boundaries = figure( ...
        'Color','w', ...
        'Name','Minimum, nominal and maximum responses', ...
        'Units','centimeters', ...
        'Position',[2 2 figureWidth figureHeight]);

    layout2 = tiledlayout(2,1,'TileSpacing','compact','Padding','compact');

    ax = nexttile;
    hold(ax,'on'); box(ax,'on'); grid(ax,'on');
    fill_range(w,boundaryMagnitudeLower,boundaryMagnitudeUpper, ...
        uncertaintyColour,'Uncertainty region',true);

    plot(w,boundaryMagnitudeDB(:,1),'--','Color',minColour, ...
        'LineWidth',lineWidth,'DisplayName','Minimum');
    plot(w,boundaryMagnitudeDB(:,2),'-','Color',nominalColour, ...
        'LineWidth',lineWidth,'DisplayName','Nominal');
    plot(w,boundaryMagnitudeDB(:,3),':','Color',maxColour, ...
        'LineWidth',lineWidth,'DisplayName','Maximum');
    plot(w,bemMagnitudeDB,'-.','Color',bemColour, ...
        'LineWidth',lineWidth,'DisplayName','BEM-based model');

    ylabel('$|G(j\omega)|$ [dB]');
    xlim([0 10]);
    set(gca,'XTickLabel',[]);
    % title('Magnitude response');
    legend('Location','southwest');

    ax = nexttile;
    hold(ax,'on'); box(ax,'on'); grid(ax,'on');
    fill_range(w,boundaryPhaseLower,boundaryPhaseUpper, ...
        uncertaintyColour,'Uncertainty region',true);

    plot(w,boundaryPhase(:,1),'--','Color',minColour, ...
        'LineWidth',lineWidth,'DisplayName','Minimum');
    plot(w,boundaryPhase(:,2),'-','Color',nominalColour, ...
        'LineWidth',lineWidth,'DisplayName','Nominal');
    plot(w,boundaryPhase(:,3),':','Color',maxColour, ...
        'LineWidth',lineWidth,'DisplayName','Maximum');
    plot(w,bemPhase,'-.','Color',bemColour, ...
        'LineWidth',lineWidth,'DisplayName','BEM-based model');

    xlabel('$\omega$ [rad/s]');
    ylabel('$\angle G(j\omega)$ [rad]');
    xlim([0 10]);
    
    % title('Phase response');
    % title(layout2,'Minimum, nominal, maximum and BEM responses');

    figures.boundaries_file = fullfile(outputDir, ...
        'Min_nominal_max_BEM_with_uncertainty.pdf');
    exportgraphics(figures.boundaries,figures.boundaries_file,'ContentType','vector');

    %% Figure 3: Nyquist diagram

    figures.nyquist = figure( ...
        'Color','w', ...
        'Name','Nyquist diagram', ...
        'Units','centimeters', ...
        'Position',[2 2 figureWidth figureHeight]);

    hold on; box on; grid on;

    fill([real(Gmin);flipud(real(Gmax))], ...
         [imag(Gmin);flipud(imag(Gmax))], ...
         uncertaintyColour, ...
         'FaceAlpha',0.55, ...
         'EdgeColor','none', ...
         'DisplayName','Uncertainty region');

    plot(real(Gmin),imag(Gmin),'--','Color',minColour, ...
        'LineWidth',lineWidth,'DisplayName','Minimum');
    plot(real(Gnom),imag(Gnom),'-','Color',nominalColour, ...
        'LineWidth',lineWidth,'DisplayName','Nominal');
    plot(real(Gmax),imag(Gmax),':','Color',maxColour, ...
        'LineWidth',lineWidth,'DisplayName','Maximum');
    plot(real(GBEM),imag(GBEM),'-.','Color',bemColour, ...
        'LineWidth',lineWidth,'DisplayName','BEM-based model');

    xline(0,'-','Color',[0.65 0.65 0.65], ...
        'LineWidth',1.0,'HandleVisibility','off');
    yline(0,'-','Color',[0.65 0.65 0.65], ...
        'LineWidth',1.0,'HandleVisibility','off');

    xlabel('$\Re\{G(j\omega)\}$');
    ylabel('$\Im\{G(j\omega)\}$');
    axis equal;
    %legend('Location','best');
    % title('Nyquist diagram');

    figures.nyquist_file = fullfile(outputDir, ...
        'Nyquist_min_nominal_max_BEM_with_uncertainty.pdf');
    exportgraphics(figures.nyquist,figures.nyquist_file,'ContentType','vector');

    %% Figure 4: WNSS passivity indicators

    % wPassivity = results.diagnostics.wide_frequency_grid(:);
    % passivityRaw  = results.diagnostics.passivity_raw;
    % passivityPass = results.diagnostics.passivity_pass;
    % verificationLabels = results.diagnostics.verification_labels(:);
    % 
    % vertexColumns = zeros(nVertices,1);
    % for i = 1:nVertices
    %     labelMatch = strcmp(verificationLabels,vertexLabels{i});
    %     if nnz(labelMatch) ~= 1
    %         error('Could not locate passivity data for %s.',vertexLabels{i});
    %     end
    %     vertexColumns(i) = find(labelMatch,1);
    % end
    % 
    % figures.wnss_passivity = figure( ...
    %     'Color','w', ...
    %     'Name','WNSS passivity indicators', ...
    %     'Units','centimeters', ...
    %     'Position',[2 2 figureWidth 20]);
    % 
    % layout4 = tiledlayout(3,1,'TileSpacing','compact','Padding','compact');
    % 
    % for i = 1:nVertices
    %     column = vertexColumns(i);
    %     ax = nexttile;
    %     hold(ax,'on'); box(ax,'on'); grid(ax,'on');
    % 
    %     plot_passivity_pair(wPassivity, ...
    %         passivityRaw(:,column),passivityPass(:,column), ...
    %         beforeColour,afterColour,zeroColour,nonPassiveColour,lineWidth);
    % 
    %     ylabel('$\Pi_i(\omega)$');
    %     xlim([0 10]);
    %     % title(escape_label(vertexLabels{i}));
    % 
    %     if i == 1
    %         legend('Location','southeast');
    %     end
    % 
    %     if i < nVertices
    %         set(gca,'XTickLabel',[]);
    %     else
    %         xlabel('$\omega$ [rad/s]');
    %     end
    % end
    % 
    % % title(layout4,'WNSS passivity indicators');
    % 
    % figures.wnss_passivity_file = fullfile(outputDir, ...
    %     'Passivity_indicators_WNSS_vertices.pdf');
    % exportgraphics(figures.wnss_passivity, ...
    %     figures.wnss_passivity_file,'ContentType','vector');

     %% Figure 5: WNSS responses before and after passivation
    % 
    % GverticesRaw  = zeros(numel(w),nVertices);
    % GverticesPass = zeros(numel(w),nVertices);
    % 
    % for i = 1:nVertices
    %     if ~isfield(results.vertices(i),'sys_raw') || ...
    %             isempty(results.vertices(i).sys_raw)
    %         error('Missing results.vertices(%d).sys_raw.',i);
    %     end
    % 
    %     GverticesRaw(:,i) = column_response( ...
    %         results.vertices(i).sys_raw,w);
    %     GverticesPass(:,i) = column_response( ...
    %         results.vertices(i).sys_pass,w);
    % end
    % 
    % rawMagnitudeDB  = 20*log10(abs(GverticesRaw));
    % passMagnitudeDB = 20*log10(abs(GverticesPass));
    % rawPhase         = unwrap(angle(GverticesRaw),[],1);
    % passPhase        = unwrap(angle(GverticesPass),[],1);
    % 
    % % Place each passivised phase on the same 2*pi branch as its raw model.
    % for i = 1:nVertices
    %     phaseOffset = round(median( ...
    %         (passPhase(:,i)-rawPhase(:,i))/(2*pi)));
    %     passPhase(:,i) = passPhase(:,i)-2*pi*phaseOffset;
    % end
    % 
    % figures.passivation_effect = figure( ...
    %     'Color','w', ...
    %     'Name','Effect of passivation on WNSS responses', ...
    %     'Units','centimeters', ...
    %     'Position',[2 2 figureWidth figureHeight]);
    % 
    % layout5 = tiledlayout(2,1,'TileSpacing','compact','Padding','compact');
    % 
    % ax = nexttile;
    % hold(ax,'on'); box(ax,'on'); grid(ax,'on');
    % 
    % for i = 1:nVertices
    %     plot(w,rawMagnitudeDB(:,i),'--', ...
    %         'Color',greenColours(i,:), ...
    %         'LineWidth',lineWidth, ...
    %         'HandleVisibility','off');
    % 
    %     plot(w,passMagnitudeDB(:,i),'-', ...
    %         'Color',greenColours(i,:), ...
    %         'LineWidth',lineWidth, ...
    %         'HandleVisibility','off');
    % end
    % 
    % ylabel('$|G(j\omega)|$ [dB]');
    % xlim([0 10]);
    % set(gca,'XTickLabel',[]);
    % % title('Magnitude response');
    % 
    % ax = nexttile;
    % hold(ax,'on'); box(ax,'on'); grid(ax,'on');
    % 
    % legendHandles = gobjects(2*nVertices,1);
    % legendLabels  = cell(2*nVertices,1);
    % 
    % for i = 1:nVertices
    %     legendHandles(2*i-1) = plot(w,rawPhase(:,i),'--', ...
    %         'Color',greenColours(i,:), ...
    %         'LineWidth',lineWidth);
    % 
    %     legendHandles(2*i) = plot(w,passPhase(:,i),'-', ...
    %         'Color',greenColours(i,:), ...
    %         'LineWidth',lineWidth);
    % 
    %     cleanLabel = escape_label(vertexLabels{i});
    %     legendLabels{2*i-1} = [cleanLabel,': before passivation'];
    %     legendLabels{2*i}   = [cleanLabel,': after passivation'];
    % end
    % 
    % xlabel('$\omega$ [rad/s]');
    % ylabel('$\angle G(j\omega)$ [rad]');
    % xlim([0 10]);
    % legend(legendHandles,legendLabels,'Location','southeast');
    % % title('Phase response');
    % % title(layout5,'Effect of passivation on WNSS responses');
    % 
    % figures.passivation_effect_file = fullfile(outputDir, ...
    %     'WNSS_before_and_after_passivation.pdf');
    % exportgraphics(figures.passivation_effect, ...
    %     figures.passivation_effect_file,'ContentType','vector');


%% Figure 6: time-domain comparison with experimental data

% The measured wave-excitation torque from each WNSS realisation is
% applied to the corresponding passivised data-driven model and to the
% BEM-based model. Their angular-velocity responses are compared with the
% experimental angular velocity measured in the SWELL dataset.

if ~isfield(results,'out') || ...
        ~isfield(results.out,'runs') || ...
        ~isfield(results.out,'opts')

    error( ...
        ['Time-domain data are unavailable. Expected ', ...
         'results.out.runs and results.out.opts.']);
end

if ~isfield(results,'sys_BEM') || ...
        isempty(results.sys_BEM)

    error( ...
        'The BEM-based model is unavailable in results.sys_BEM.');
end

%% Variable names used in the SWELL files

inputVariable = ...
    results.out.opts.InputVar;

outputVariable = ...
    results.out.opts.OutputVar;

timeVariable = ...
    results.out.opts.TimeVar;

%% Plot colours

experimentalColour = greenColours(2,:);
dataDrivenColour    = [0.55 0.75 0.60];
bemValidationColour = [0.25 0.45 0.70];

%% Initialise fit metrics

dataDrivenNRMSE = zeros(nVertices,1);
bemNRMSE        = zeros(nVertices,1);

%% Create figure

figures.time_validation = figure( ...
    'Color','w', ...
    'Name','Time-domain comparison with experimental data', ...
    'Units','centimeters', ...
    'Position',[2 2 figureWidth 20]);

layout6 = tiledlayout( ...
    3,1, ...
    'TileSpacing','compact', ...
    'Padding','compact');

%% Process each WNSS realisation

for i = 1:nVertices

    %% Locate the corresponding experimental run

    runIndex = strcmp( ...
        {results.out.runs.label}, ...
        vertexLabels{i});

    if nnz(runIndex) ~= 1
        error( ...
            'Could not uniquely locate the run %s.', ...
            vertexLabels{i});
    end

    runData = ...
        results.out.runs(runIndex);

    %% Check experimental file paths

    if ~isfile(runData.fileT2)
        error( ...
            'Test 2 file not found: %s', ...
            runData.fileT2);
    end

    if ~isfile(runData.fileT3)
        error( ...
            'Test 3 file not found: %s', ...
            runData.fileT3);
    end

    %% Load measured excitation torque from Test 2

    inputData = load( ...
        runData.fileT2, ...
        inputVariable, ...
        timeVariable);

    if ~isfield(inputData,inputVariable)
        error( ...
            'Variable %s is missing from %s.', ...
            inputVariable, ...
            runData.fileT2);
    end

    if ~isfield(inputData,timeVariable)
        error( ...
            'Variable %s is missing from %s.', ...
            timeVariable, ...
            runData.fileT2);
    end

    inputTorque = ...
        double(inputData.(inputVariable));

    inputTorque = ...
        inputTorque(:);

    inputTime = ...
        double(inputData.(timeVariable));

    inputTime = ...
        inputTime(:);

    %% Load measured angular velocity from Test 3

    outputData = load( ...
        runData.fileT3, ...
        outputVariable, ...
        timeVariable);

    if ~isfield(outputData,outputVariable)
        error( ...
            'Variable %s is missing from %s.', ...
            outputVariable, ...
            runData.fileT3);
    end

    if ~isfield(outputData,timeVariable)
        error( ...
            'Variable %s is missing from %s.', ...
            timeVariable, ...
            runData.fileT3);
    end

    experimentalVelocity = ...
        double(outputData.(outputVariable));

    experimentalVelocity = ...
        experimentalVelocity(:);

    outputTime = ...
        double(outputData.(timeVariable));

    outputTime = ...
        outputTime(:);

    %% Retain finite samples

    validInput = ...
        isfinite(inputTime) & ...
        isfinite(inputTorque);

    validOutput = ...
        isfinite(outputTime) & ...
        isfinite(experimentalVelocity);

    inputTime = ...
        inputTime(validInput);

    inputTorque = ...
        inputTorque(validInput);

    outputTime = ...
        outputTime(validOutput);

    experimentalVelocity = ...
        experimentalVelocity(validOutput);

    if numel(inputTime) < 2 || ...
            numel(outputTime) < 2

        error( ...
            'Insufficient valid time-domain data for %s.', ...
            vertexLabels{i});
    end

    %% Remove repeated time samples, if present

    [inputTime,uniqueInputIndices] = ...
        unique(inputTime,'stable');

    inputTorque = ...
        inputTorque(uniqueInputIndices);

    [outputTime,uniqueOutputIndices] = ...
        unique(outputTime,'stable');

    experimentalVelocity = ...
        experimentalVelocity(uniqueOutputIndices);

    %% Determine the common time interval

    initialTime = max( ...
        inputTime(1), ...
        outputTime(1));

    finalTime = min( ...
        inputTime(end), ...
        outputTime(end));

    if finalTime <= initialTime
        error( ...
            ['The Test 2 and Test 3 records for %s do not ', ...
             'have a common time interval.'], ...
            vertexLabels{i});
    end

    commonOutputMask = ...
        outputTime >= initialTime & ...
        outputTime <= finalTime;

    simulationTime = ...
        outputTime(commonOutputMask);

    experimentalVelocity = ...
        experimentalVelocity(commonOutputMask);

    %% Interpolate the experimental torque onto the output time grid

    inputTorque = interp1( ...
        inputTime, ...
        inputTorque, ...
        simulationTime, ...
        'linear');

    finiteCommonSamples = ...
        isfinite(simulationTime) & ...
        isfinite(inputTorque) & ...
        isfinite(experimentalVelocity);

    simulationTime = ...
        simulationTime(finiteCommonSamples);

    inputTorque = ...
        inputTorque(finiteCommonSamples);

    experimentalVelocity = ...
        experimentalVelocity(finiteCommonSamples);

    %% Apply the same preprocessing used for identification

    inputTorque = ...
        detrend(inputTorque);

    experimentalVelocity = ...
        detrend(experimentalVelocity);

    % Express time relative to the beginning of the common record.
    simulationTime = ...
        simulationTime - simulationTime(1);

    %% Check the simulation time vector

    if any(diff(simulationTime) <= 0)
        error( ...
            'The simulation time vector for %s is not strictly increasing.', ...
            vertexLabels{i});
    end

    %% Simulate the corresponding passivised data-driven model

    passiveDataDrivenModel = ...
        results.vertices(i).sys_pass;

    dataDrivenVelocity = lsim( ...
        passiveDataDrivenModel, ...
        inputTorque, ...
        simulationTime);

    dataDrivenVelocity = ...
        dataDrivenVelocity(:);

    %% Simulate the BEM-based model

    bemVelocity = lsim( ...
        results.sys_BEM, ...
        inputTorque, ...
        simulationTime);

    bemVelocity = ...
        bemVelocity(:);

    %% Compute time-domain NRMSE values

    referenceNorm = norm( ...
        experimentalVelocity - ...
        mean(experimentalVelocity));

    if referenceNorm > eps

        dataDrivenNRMSE(i) = 1 - ...
            norm( ...
                experimentalVelocity - ...
                dataDrivenVelocity) / ...
            referenceNorm;

        bemNRMSE(i) = 1 - ...
            norm( ...
                experimentalVelocity - ...
                bemVelocity) / ...
            referenceNorm;

    else
        dataDrivenNRMSE(i) = NaN;
        bemNRMSE(i) = NaN;
    end

    fprintf( ...
        ['%s time-domain comparison:\n', ...
         '   Data-driven NRMSE = %.6f\n', ...
         '   BEM NRMSE         = %.6f\n'], ...
        vertexLabels{i}, ...
        dataDrivenNRMSE(i), ...
        bemNRMSE(i));

    %% Plot the experimental and simulated responses

    ax = nexttile;
    hold(ax,'on');
    box(ax,'on');
    grid(ax,'on');

    plot( ...
        simulationTime, ...
        experimentalVelocity, ...
        '-', ...
        'Color',experimentalColour, ...
        'LineWidth',1.6, ...
        'DisplayName','Experimental (SWELL)');

    plot( ...
        simulationTime, ...
        dataDrivenVelocity, ...
        '--', ...
        'Color',dataDrivenColour, ...
        'LineWidth',1.6, ...
        'DisplayName','Data-driven model');

    plot( ...
        simulationTime, ...
        bemVelocity, ...
        '-.', ...
        'Color',bemValidationColour, ...
        'LineWidth',1.8, ...
        'DisplayName','BEM-based model');

    ylabel('$\dot{\theta}_A(t)$ [rad/s]');

    % Display the first 100 seconds, consistent with the original figure.
    displayedFinalTime = min( ...
        70, ...
        simulationTime(end));

    xlim([60 displayedFinalTime]);

    % title( ...
    %     sprintf( ...
    %         ['%s: $\\mathrm{NRMSE}_{\\mathrm{DD}}=%.3f$, ', ...
    %          '$\\mathrm{NRMSE}_{\\mathrm{BEM}}=%.3f$'], ...
    %         escape_label(vertexLabels{i}), ...
    %         dataDrivenNRMSE(i), ...
    %         bemNRMSE(i)));

    if i == 1
        legend('Location','best');
    end

    if i < nVertices
        set(gca,'XTickLabel',[]);
    else
        xlabel('$t$ [s]');
    end
end

% Optional overall title:
%
% title( ...
%     layout6, ...
%     'Time-domain comparison with experimental measurements');

%% Store time-domain fit metrics

figures.time_validation_nrmse.data_driven = ...
    dataDrivenNRMSE;

figures.time_validation_nrmse.bem = ...
    bemNRMSE;

figures.time_validation_nrmse.labels = ...
    vertexLabels;

%% Export figure

figures.time_validation_file = fullfile( ...
    outputDir, ...
    'Time_domain_comparison_SWELL_data_driven_BEM.pdf');

exportgraphics( ...
    figures.time_validation, ...
    figures.time_validation_file, ...
    'ContentType','vector');

    fprintf('\nFigures saved:\n');
    % fprintf('  %s\n',figures.vertices_file);
    fprintf('  %s\n',figures.boundaries_file);
    fprintf('  %s\n',figures.nyquist_file);
    % fprintf('  %s\n',figures.wnss_passivity_file);
    % fprintf('  %s\n',figures.passivation_effect_file);
    fprintf('  %s\n',figures.time_validation_file);
 end

%% Local functions

function fill_range(w,lowerBound,upperBound,colour,label,showLegend)
    if showLegend
        visibility = 'on';
    else
        visibility = 'off';
    end

    fill([w;flipud(w)],[lowerBound;flipud(upperBound)],colour, ...
        'FaceAlpha',0.55, ...
        'EdgeColor','none', ...
        'DisplayName',label, ...
        'HandleVisibility',visibility);
end

function plot_passivity_pair(w,rawIndicator,passIndicator, ...
        beforeColour,afterColour,zeroColour,regionColour,lineWidth)

    negativeRaw = min(rawIndicator(:),0);

    area(w,negativeRaw, ...
        'FaceColor',regionColour, ...
        'FaceAlpha',0.75, ...
        'EdgeColor','none', ...
        'DisplayName','Non-passive region');

    plot(w,rawIndicator,'--', ...
        'Color',beforeColour, ...
        'LineWidth',lineWidth, ...
        'DisplayName','Before passivation');

    plot(w,passIndicator,'-', ...
        'Color',afterColour, ...
        'LineWidth',lineWidth, ...
        'DisplayName','After passivation');

    yline(0,'-', ...
        'Color',zeroColour, ...
        'LineWidth',1.2, ...
        'HandleVisibility','off');
end

function indicator = passivity_indicator(sys,w)
    response = column_response(sys,w);
    indicator = 2*real(response);
end

function response = column_response(sys,w)
    response = squeeze(freqresp(sys,w));
    response = response(:);
end

function phaseMatrix = align_phase_columns(phaseMatrix)
% Remove arbitrary multiples of 2*pi between phase branches.
    reference = phaseMatrix(:,2);
    for i = [1 3]
        offset = round(median((phaseMatrix(:,i)-reference)/(2*pi)));
        phaseMatrix(:,i) = phaseMatrix(:,i)-2*pi*offset;
    end
end

function label = escape_label(label)
    label = strrep(label,'_','\_');
end

function validate_results_structure(results)
    if ~isstruct(results)
        error('results must be a structure.');
    end

    requiredTopFields = {'vertices','responses','diagnostics','nominal','min','max'};
    for i = 1:numel(requiredTopFields)
        if ~isfield(results,requiredTopFields{i})
            error('Missing results.%s.',requiredTopFields{i});
        end
    end

    if ~isfield(results,'sys_BEM') || isempty(results.sys_BEM)
        error('Missing results.sys_BEM.');
    end

    if ~isfield(results.vertices,'label')
        error('The vertex labels are missing.');
    end

    if ~isfield(results.responses,'frequency') || ...
            ~isfield(results.responses,'vertices')
        error('Missing the frequency grid or vertex responses in results.responses.');
    end

    requiredModels = {
        results.min,     'results.min'
        results.nominal, 'results.nominal'
        results.max,     'results.max'
    };

    for i = 1:size(requiredModels,1)
        parent = requiredModels{i,1};
        name   = requiredModels{i,2};
        if ~isfield(parent,'sys_pass') || isempty(parent.sys_pass)
            error('Missing %s.sys_pass.',name);
        end
    end

    requiredDiagnosticFields = { ...
        'wide_frequency_grid', ...
        'passivity_raw', ...
        'passivity_pass', ...
        'verification_labels'};

    for i = 1:numel(requiredDiagnosticFields)
        if ~isfield(results.diagnostics,requiredDiagnosticFields{i})
            error('Missing results.diagnostics.%s.',requiredDiagnosticFields{i});
        end
    end
end
