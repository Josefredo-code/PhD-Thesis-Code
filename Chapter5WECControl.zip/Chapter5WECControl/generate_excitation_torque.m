function [f_e,eta,t,h_exc] = generate_excitation_torque( ...
    H_s,T_p,gamma,omega,F_exc,tvec,varargin)
%==========================================================================
% GENERATE_EXCITATION_TORQUE
%
% Generates a random free-surface-elevation realisation and the
% corresponding wave-excitation torque using a JONSWAP spectrum and the
% first-order excitation-moment transfer function obtained from NEMOH.
%
% The free-surface elevation is generated as
%
%   eta(t) = sum_q sqrt(2*S(omega_q)*DeltaOmega) ...
%                  *cos(omega_q*t+phi_q).
%
% The excitation torque is obtained directly in the frequency domain:
%
%   f_e(t) = sum_q sqrt(2*S(omega_q)*DeltaOmega) ...
%                  *abs(F_exc(omega_q)) ...
%                  *cos(omega_q*t+phi_q+angle(F_exc(omega_q))).
%
% This calculation is equivalent to filtering eta(t) through the
% excitation-moment transfer function, but avoids numerical inconsistencies
% associated with IFFT scaling and discrete convolution.
%
% INPUTS
%   H_s       Significant wave height
%   T_p       Peak period
%   gamma     JONSWAP peak-enhancement factor
%   omega     Angular-frequency vector [rad/s]
%   F_exc     Excitation-moment transfer function evaluated at omega
%   tvec      Time vector [s]
%
% OPTIONAL INPUT
%   'Seed'    Seed used for random-phase generation
%
% OUTPUTS
%   f_e       Wave-excitation torque time series
%   eta       Free-surface-elevation time series
%   t         Time vector
%   h_exc     Excitation impulse-response function evaluated on t-t(1)
%==========================================================================

%% Optional arguments

parser = inputParser;

parser.addParameter( ...
    'Seed',[], ...
    @(x) isempty(x) || ...
    (isnumeric(x) && isscalar(x) && isfinite(x) && x>=0));

parser.parse(varargin{:});

randomSeed = parser.Results.Seed;

%% Arrange input vectors as columns

t = double(tvec(:));
omega = double(omega(:));
F_exc = double(F_exc(:));

%% Input checks

if numel(t)<2
    error('The time vector must contain at least two samples.');
end

if numel(omega)<2
    error('The frequency vector must contain at least two samples.');
end

if numel(omega)~=numel(F_exc)
    error( ...
        ['The angular-frequency vector and the excitation-moment ', ...
         'transfer function must have the same number of samples.']);
end

if any(~isfinite(t))
    error('The time vector contains non-finite values.');
end

if any(~isfinite(omega))
    error('The angular-frequency vector contains non-finite values.');
end

if any(~isfinite(real(F_exc))) || any(~isfinite(imag(F_exc)))
    error( ...
        ['The excitation-moment transfer function contains ', ...
         'non-finite values.']);
end

if any(diff(t)<=0)
    error('The time vector must be strictly increasing.');
end

if any(diff(omega)<=0)
    error('The angular-frequency vector must be strictly increasing.');
end

if any(omega<0)
    error('The angular-frequency vector must be non-negative.');
end

%% Check the temporal discretisation

timeSteps = diff(t);
dt = median(timeSteps);

maximumTimeDeviation = max(abs(timeSteps-dt));

if maximumTimeDeviation>1e-6*max(dt,eps)
    warning( ...
        ['The time vector is not uniformly sampled. The maximum ', ...
         'deviation from the median time step is %.6e s.'], ...
        maximumTimeDeviation);
end

%% Frequency-bin widths

numberOfFrequencies = numel(omega);

frequencyEdges = zeros(numberOfFrequencies+1,1);

% Interior bin boundaries
frequencyEdges(2:numberOfFrequencies) = ...
    0.5*( ...
        omega(1:end-1)+ ...
        omega(2:end));

% Lower boundary
firstHalfWidth = ...
    frequencyEdges(2)-omega(1);

frequencyEdges(1) = ...
    max(0,omega(1)-firstHalfWidth);

% Upper boundary
lastHalfWidth = ...
    omega(end)-frequencyEdges(end-1);

frequencyEdges(end) = ...
    omega(end)+lastHalfWidth;

% Individual frequency-bin widths
DeltaOmega = diff(frequencyEdges);

if any(DeltaOmega<=0)
    error('The calculated frequency-bin widths must be positive.');
end
%% JONSWAP spectral density

[S,~,~,~] = JONSWAP( ...
    omega,T_p,H_s,gamma);

S = real(S(:));

if numel(S)~=numel(omega)
    error( ...
        ['The JONSWAP function returned a spectral-density vector ', ...
         'with an unexpected number of samples.']);
end

if any(~isfinite(S))
    error( ...
        'The JONSWAP spectrum contains non-finite values.');
end

% Remove negligible negative values caused by numerical round-off
spectralTolerance = ...
    1e-12*max(1,max(abs(S)));

if any(S < -spectralTolerance)
    error('The JONSWAP spectrum contains negative values.');
end

S = max(S,0);

%% Random phases

numberOfFrequencies = numel(omega);

if isempty(randomSeed)

    phi = 2*pi*rand(numberOfFrequencies,1);

else

    randomStream = RandStream( ...
        'mt19937ar', ...
        'Seed',randomSeed);

    phi = 2*pi*rand( ...
        randomStream, ...
        numberOfFrequencies,1);
end

%% Spectral amplitudes

spectralAmplitude = ...
    sqrt(2*S.*DeltaOmega);

%% Generate eta(t) and f_e(t)

numberOfTimeSamples = numel(t);

eta = zeros(numberOfTimeSamples,1);
f_e = zeros(numberOfTimeSamples,1);

for q = 1:numberOfFrequencies

    phaseElevation = ...
        omega(q)*t+phi(q);

    eta = eta+ ...
        spectralAmplitude(q)* ...
        cos(phaseElevation);

    phaseExcitation = ...
        phaseElevation+angle(F_exc(q));

    f_e = f_e+ ...
        spectralAmplitude(q)* ...
        abs(F_exc(q))* ...
        cos(phaseExcitation);
end

%% Excitation impulse-response function

% The IRF is evaluated on the same temporal discretisation as the generated
% signals. It is provided for analysis and visualisation; f_e is generated
% directly in the frequency domain above.

tau = t-t(1);

integrationWeights = DeltaOmega;

h_exc = zeros(numberOfTimeSamples,1);

for q = 1:numberOfFrequencies

    h_exc = h_exc+ ...
        integrationWeights(q)/pi* ...
        real( ...
            F_exc(q)* ...
            exp(1i*omega(q)*tau));
end

%% Final checks

if any(~isfinite(eta))
    error( ...
        'The generated free-surface elevation contains non-finite values.');
end

if any(~isfinite(f_e))
    error( ...
        'The generated excitation torque contains non-finite values.');
end

if any(~isfinite(h_exc))
    error( ...
        ['The calculated excitation impulse-response function ', ...
         'contains non-finite values.']);
end

end