%% ============================================================
%  CLOSED-LOOP RESULTS: PLOTTING ROUTINE
%
%  This script loads the closed-loop results and establishes the common
%  configuration used by all subsequent figures.
%
%  Active chapter configuration:
%    - ISS1--ISS3;
%    - Passive, H2 and H-infinity controllers.
%
%  The commented alternatives retain ISS4--ISS6 and the reactive
%  controller so that they can be re-enabled without changing the plots.
% ============================================================

clc;
close all;

%% ============================================================
%  USER CONFIGURATION
% ============================================================

% Choose 3 for ISS1--ISS3 or 6 for ISS1--ISS6.
lastSeaStateToPlot = 3;
% lastSeaStateToPlot = 6;

assert(ismember(lastSeaStateToPlot,[3 6]), ...
    'lastSeaStateToPlot must be either 3 or 6.');

seaStateIndices = 1:lastSeaStateToPlot;
seaStateLabels = arrayfun( ...
    @(index)sprintf('ISS%d',index), ...
    seaStateIndices, ...
    'UniformOutput',false);

% Controllers included in the chapter figures.
controllerNames = {'Passive','H2','Hinf'};

% Uncomment the following line to include the reactive controller.
% controllerNames = {'Passive','Reactive','H2','Hinf'};

% Optional file used only when closedLoopResults is not already available
% in the workspace.
resultsFile = fullfile( ...
    pwd, ...
    'closed_loop_optimal_nominal_saturated_ISS1_ISS6.mat');

% Alternative file when only ISS1--ISS3 have been simulated.
% resultsFile = fullfile( ...
%     pwd, ...
%     'closed_loop_optimal_nominal_saturated_ISS1_ISS3.mat');

exportFigures = true;
figureDirectory = fullfile(pwd,'closed_loop_figures');

if exportFigures && ~exist(figureDirectory,'dir')
    mkdir(figureDirectory);
end

%% Figure output folder

figuresFolder = fullfile( ...
    pwd, ...
    'closed_loop_figures');

if ~exist(figuresFolder,'dir')
    mkdir(figuresFolder);
end

%% ============================================================
%  UNIFIED FIGURE STYLE
% ============================================================

axesFontSize = 16;
legendFontSize = 13;
lineWidth = 2.2;
limitLineWidth = 1.2;

set(groot,'DefaultAxesFontSize',axesFontSize);
set(groot,'DefaultTextInterpreter','latex');
set(groot,'DefaultAxesTickLabelInterpreter','latex');
set(groot,'DefaultLegendInterpreter','latex');
set(groot,'DefaultLegendFontSize',legendFontSize);
set(groot,'DefaultAxesLabelFontSizeMultiplier',1.2);
set(groot,'DefaultAxesTitleFontSizeMultiplier',1.0);
set(groot,'DefaultFigureColor','w');
set(groot,'DefaultAxesBox','on');
set(groot,'DefaultAxesXGrid','on');
set(groot,'DefaultAxesYGrid','on');
set(groot,'DefaultAxesGridAlpha',0.18);

%% ============================================================
%  COMMON COLOUR PALETTE
% ============================================================

% SWELL conditions: green tones
greenColors = [
    0.05 0.30 0.20
    0.20 0.50 0.35
    0.55 0.75 0.60
];

% External conditions: blue tones
blueColors = [
    0.10 0.20 0.40
    0.25 0.45 0.70
    0.55 0.70 0.85
];

%% ============================================================
%  CONTROLLER APPEARANCE
% ============================================================

controllerStyle.Passive.colour = blueColors(2,:);
controllerStyle.Passive.lineStyle = '-';
controllerStyle.Passive.displayName = 'Passive';

controllerStyle.Reactive.colour = blueColors(3,:);
controllerStyle.Reactive.lineStyle = '--';
controllerStyle.Reactive.displayName = 'Reactive';

controllerStyle.H2.colour = greenColors(1,:);
controllerStyle.H2.lineStyle = '-.';
controllerStyle.H2.displayName = '$H_2$';

controllerStyle.Hinf.colour = greenColors(3,:);
controllerStyle.Hinf.lineStyle = ':';
controllerStyle.Hinf.displayName = '$H_\infty$';

%% ============================================================
%  SEA-STATE APPEARANCE
% ============================================================

seaStateStyle.ISS1.colour = greenColors(1,:);
seaStateStyle.ISS1.lineStyle = '-';

seaStateStyle.ISS2.colour = greenColors(2,:);
seaStateStyle.ISS2.lineStyle = '--';

seaStateStyle.ISS3.colour = greenColors(3,:);
seaStateStyle.ISS3.lineStyle = ':';

% External validation conditions, retained for optional use.
seaStateStyle.ISS4.colour = blueColors(1,:);
seaStateStyle.ISS4.lineStyle = '-';

seaStateStyle.ISS5.colour = blueColors(2,:);
seaStateStyle.ISS5.lineStyle = '--';

seaStateStyle.ISS6.colour = blueColors(3,:);
seaStateStyle.ISS6.lineStyle = ':';

%% ============================================================
%  LOAD CLOSED-LOOP RESULTS
% ============================================================

if exist('closedLoopResults','var')~=1
    assert(isfile(resultsFile), ...
        ['closedLoopResults is not available in the workspace and the ' ...
        'results file was not found:\n%s'],resultsFile);

    loadedResults = load(resultsFile,'closedLoopResults');

    assert(isfield(loadedResults,'closedLoopResults'), ...
        'The MAT file does not contain closedLoopResults.');

    closedLoopResults = loadedResults.closedLoopResults;
    resultsSource = resultsFile;
else
    resultsSource = 'Current MATLAB workspace';
end

assert(isfield(closedLoopResults,'seaStates'), ...
    'closedLoopResults does not contain seaStates.');

allSeaStates = closedLoopResults.seaStates;
availableSeaStateLabels = {allSeaStates.label};

selectedPositions = zeros(size(seaStateLabels));

for seaStateIndex = 1:numel(seaStateLabels)
    selectedPosition = find(strcmp( ...
        availableSeaStateLabels, ...
        seaStateLabels{seaStateIndex}),1);

    assert(~isempty(selectedPosition), ...
        '%s is not available in the results file.', ...
        seaStateLabels{seaStateIndex});

    selectedPositions(seaStateIndex) = selectedPosition;
end

selectedSeaStates = allSeaStates(selectedPositions);

for controllerIndex = 1:numel(controllerNames)
    controllerName = controllerNames{controllerIndex};

    assert(isfield(selectedSeaStates(1).controllers,controllerName), ...
        'Controller %s is not available in the results file.', ...
        controllerName);
end

%% ============================================================
%  PHYSICAL LIMITS
% ============================================================

forceLimit_N = ...
    closedLoopResults.configuration.forceLimit_N;
velocityLimit_mps = ...
    closedLoopResults.configuration.velocityLimit_mps;
strokeLimit_m = ...
    closedLoopResults.configuration.strokeLimit_m;

%% ============================================================
%  FILTER SUMMARY TABLES
% ============================================================

energySummary = closedLoopResults.energySummary;
physicalSummary = closedLoopResults.physicalSummary;

energySelection = ...
    ismember(string(energySummary.SeaState),string(seaStateLabels)) & ...
    ismember(string(energySummary.Controller),string(controllerNames));

physicalSelection = ...
    ismember(string(physicalSummary.SeaState),string(seaStateLabels)) & ...
    ismember(string(physicalSummary.Controller),string(controllerNames));

selectedEnergySummary = energySummary(energySelection,:);
selectedPhysicalSummary = physicalSummary(physicalSelection,:);

%% ============================================================
%  CONFIGURATION SUMMARY
% ============================================================

fprintf('\n============================================================\n');
fprintf('CLOSED-LOOP PLOTTING CONFIGURATION\n');
fprintf('============================================================\n');
fprintf('Sea states:  %s\n',strjoin(seaStateLabels,', '));
fprintf('Controllers: %s\n',strjoin(controllerNames,', '));
fprintf('Results source:\n%s\n',resultsSource);
fprintf('Figure directory:\n%s\n',figureDirectory);

disp(selectedEnergySummary);
disp(selectedPhysicalSummary);

% %% ============================================================
% %  FIGURE 1: ISS2 ANGULAR RESPONSE
% %
% %  Open-loop and closed-loop angular velocity and position.
% %  One tile is used for each selected controller.
% % ============================================================
% 
% comparisonSeaStateLabel = 'ISS2';
% 
% % Use the open-loop results already available in the workspace. If they
% % are unavailable, load the corresponding auxiliary simulation file.
% if exist('openLoopResults','var')~=1
%     openLoopResultsFile = fullfile( ...
%         pwd, ...
%         sprintf('open_loop_nominal_ISS1_ISS%d.mat', ...
%         lastSeaStateToPlot));
% 
%     assert(isfile(openLoopResultsFile), ...
%         ['openLoopResults is not available in the workspace and the ' ...
%         'open-loop results file was not found:\n%s'], ...
%         openLoopResultsFile);
% 
%     loadedOpenLoop = load(openLoopResultsFile,'openLoopResults');
%     openLoopResults = loadedOpenLoop.openLoopResults;
% end
% 
% closedLoopPosition = find(strcmp( ...
%     {allSeaStates.label},comparisonSeaStateLabel),1);
% openLoopPosition = find(strcmp( ...
%     {openLoopResults.seaStates.label},comparisonSeaStateLabel),1);
% 
% assert(~isempty(closedLoopPosition), ...
%     '%s is unavailable in closedLoopResults.', ...
%     comparisonSeaStateLabel);
% assert(~isempty(openLoopPosition), ...
%     '%s is unavailable in openLoopResults.', ...
%     comparisonSeaStateLabel);
% 
% closedISS2 = allSeaStates(closedLoopPosition);
% openISS2 = openLoopResults.seaStates(openLoopPosition);
% 
% % Determine common symmetric limits for direct comparison among tiles.
% maximumAngularVelocity = max(abs(openISS2.angularVelocity));
% maximumAngularPosition = max(abs(openISS2.angularPosition));
% 
% for controllerIndex = 1:numel(controllerNames)
%     controllerName = controllerNames{controllerIndex};
%     controllerData = closedISS2.controllers.(controllerName);
% 
%     maximumAngularVelocity = max( ...
%         maximumAngularVelocity, ...
%         max(abs(controllerData.angularVelocity)));
%     maximumAngularPosition = max( ...
%         maximumAngularPosition, ...
%         max(abs(controllerData.angularPosition)));
% end
% 
% velocityLimitPlot = 1.05*maximumAngularVelocity;
% positionLimitPlot = 1.05*maximumAngularPosition;
% 
% if velocityLimitPlot==0
%     velocityLimitPlot = 1;
% end
% 
% if positionLimitPlot==0
%     positionLimitPlot = 1;
% end
% 
% numberControllers = numel(controllerNames);
% figureHeight = 5.2*numberControllers + 2.0;
% 
% figAngularISS2 = figure( ...
%     'Color','w', ...
%     'Name','ISS2 angular open- and closed-loop responses', ...
%     'Units','centimeters', ...
%     'Position',[2 2 19 figureHeight]);
% 
% angularLayout = tiledlayout( ...
%     numberControllers,1, ...
%     'TileSpacing','compact', ...
%     'Padding','compact');
% 
% openLoopColour = [0.45 0.45 0.45];
% angularAxes = gobjects(numberControllers,1);
% 
% for controllerIndex = 1:numberControllers
% 
%     controllerName = controllerNames{controllerIndex};
%     controllerData = closedISS2.controllers.(controllerName);
%     style = controllerStyle.(controllerName);
% 
%     angularAxes(controllerIndex) = nexttile(angularLayout);
%     hold(angularAxes(controllerIndex),'on');
%     grid(angularAxes(controllerIndex),'on');
%     box(angularAxes(controllerIndex),'on');
% 
%     yyaxis(angularAxes(controllerIndex),'left');
% 
%     velocityOpenLine = plot( ...
%         openISS2.time_s, ...
%         openISS2.angularVelocity, ...
%         '-', ...
%         'Color',openLoopColour, ...
%         'LineWidth',1.2, ...
%         'DisplayName','Open loop: $\dot{\theta}_A$');
% 
%     velocityClosedLine = plot( ...
%         closedISS2.time_s, ...
%         controllerData.angularVelocity, ...
%         '-', ...
%         'Color',style.colour, ...
%         'LineWidth',lineWidth, ...
%         'DisplayName',[style.displayName ': $\dot{\theta}_A$']);
% 
%     ylabel('$\dot{\theta}_A$ [rad/s]');
%     ylim([-velocityLimitPlot velocityLimitPlot]);
%     angularAxes(controllerIndex).YColor = [0.15 0.15 0.15];
% 
%     yyaxis(angularAxes(controllerIndex),'right');
% 
%     positionOpenLine = plot( ...
%         openISS2.time_s, ...
%         openISS2.angularPosition, ...
%         '--', ...
%         'Color',openLoopColour, ...
%         'LineWidth',1.2, ...
%         'DisplayName','Open loop: $\theta_A$');
% 
%     positionClosedLine = plot( ...
%         closedISS2.time_s, ...
%         controllerData.angularPosition, ...
%         '--', ...
%         'Color',style.colour, ...
%         'LineWidth',lineWidth, ...
%         'DisplayName',[style.displayName ': $\theta_A$']);
% 
%     ylabel('$\theta_A$ [rad]');
%     ylim([-positionLimitPlot positionLimitPlot]);
%     angularAxes(controllerIndex).YColor = [0.15 0.15 0.15];
% 
%     %title(style.displayName);
%     %xlim([closedISS2.time_s(1) closedISS2.time_s(end)]);
%     xlim([40 70]);
% 
%     if controllerIndex<numberControllers
%         angularAxes(controllerIndex).XTickLabel = [];
%     else
%         xlabel('$t$ [s]');
%     end
% 
% legend( ...
%     [velocityOpenLine velocityClosedLine ...
%     positionOpenLine positionClosedLine], ...
%     'Location','northeast', ...
%     'NumColumns',2);
% end
% 
% linkaxes(angularAxes,'x');
% 
% if exportFigures
%     angularFigureFile = fullfile( ...
%         figureDirectory, ...
%         'ISS2_angular_response_open_closed_loop.pdf');
% 
%     exportgraphics( ...
%         figAngularISS2, ...
%         angularFigureFile, ...
%         'ContentType','vector');
% 
%     fprintf('Figure saved:\n%s\n',angularFigureFile);
% end

% %% ============================================================
% %  FIGURE 2: ANGULAR VELOCITY AND REFERENCE CONTROL TORQUE
% %
% %  One figure is generated for each selected sea state.
% %  Upper subplot: angular velocity.
% %  Lower subplot: reference control torque.
% % ============================================================
% 
% for seaStatePlotIndex = 1:numel(selectedSeaStates)
% 
%     currentSeaState = selectedSeaStates(seaStatePlotIndex);
%     currentSeaStateLabel = currentSeaState.label;
% 
%     figVelocityTorque = figure( ...
%         'Color','w', ...
%         'Name',[currentSeaStateLabel ...
%         ' angular velocity and reference control torque'], ...
%         'Units','centimeters', ...
%         'Position',[2 2 19 14]);
% 
%     velocityTorqueLayout = tiledlayout( ...
%         2,1, ...
%         'TileSpacing','compact', ...
%         'Padding','compact');
% 
%     %% Angular velocity
% 
%     velocityAxes = nexttile(velocityTorqueLayout,1);
% 
%     hold(velocityAxes,'on');
%     grid(velocityAxes,'on');
%     box(velocityAxes,'on');
% 
%     velocityLines = gobjects(numel(controllerNames),1);
% 
%     for controllerIndex = 1:numel(controllerNames)
% 
%         controllerName = controllerNames{controllerIndex};
%         controllerData = ...
%             currentSeaState.controllers.(controllerName);
%         style = controllerStyle.(controllerName);
% 
%         velocityLines(controllerIndex) = plot( ...
%             currentSeaState.time_s, ...
%             controllerData.angularVelocity, ...
%             'Color',style.colour, ...
%             'LineStyle',style.lineStyle, ...
%             'LineWidth',lineWidth, ...
%             'DisplayName',style.displayName);
% 
%     end
% 
%     ylabel('$\dot{\theta}_A$ [rad/s]');
%     % xlim([currentSeaState.time_s(1) ...
%     %     currentSeaState.time_s(end)]);
%     xlim([40 70]);
% 
%     %title([currentSeaStateLabel ...
%         %': angular velocity']);
% 
%     legend( ...
%         velocityLines, ...
%         'Location','northeast', ...
%         'NumColumns',numel(controllerNames));
% 
%     velocityAxes.XTickLabel = [];
% 
%     %% Reference control torque
% 
%     torqueAxes = nexttile(velocityTorqueLayout,2);
% 
%     hold(torqueAxes,'on');
%     grid(torqueAxes,'on');
%     box(torqueAxes,'on');
% 
%     for controllerIndex = 1:numel(controllerNames)
% 
%         controllerName = controllerNames{controllerIndex};
%         controllerData = ...
%             currentSeaState.controllers.(controllerName);
%         style = controllerStyle.(controllerName);
% 
%         plot( ...
%             currentSeaState.time_s, ...
%             controllerData.referenceTorque, ...
%             'Color',style.colour, ...
%             'LineStyle',style.lineStyle, ...
%             'LineWidth',lineWidth, ...
%             'HandleVisibility','off');
% 
%     end
% 
%     xlabel('$t$ [s]');
%     ylabel('$\tau_u$ [N\,m]');
%     % xlim([currentSeaState.time_s(1) ...
%     %     currentSeaState.time_s(end)]);
%     xlim([40 70]);
% 
%     %title('Reference control torque');
% 
%     linkaxes([velocityAxes torqueAxes],'x');
% 
%     %% Export figure
% 
%     if exportFigures
% 
%         velocityTorqueFile = fullfile( ...
%             figureDirectory, ...
%             sprintf( ...
%             '%s_angular_velocity_reference_torque.pdf', ...
%             currentSeaStateLabel));
% 
%         exportgraphics( ...
%             figVelocityTorque, ...
%             velocityTorqueFile, ...
%             'ContentType','vector');
% 
%         fprintf('Figure saved:\n%s\n', ...
%             velocityTorqueFile);
% 
%     end
% 
% end

%% ============================================================
%  FIGURE 3: EXCITATION TORQUE, PTO VELOCITY AND APPLIED FORCE
%
%  One figure is generated for each selected sea state.
%
%  Upper subplot:  experimental wave-excitation torque.
%  Middle subplot: translational PTO velocity.
%  Lower subplot:  applied PTO force after saturation.
%
%  The original exported filenames are retained.
% ============================================================

PTOplotTimeWindow = [40 70];

excitationTorqueColour = [0.30 0.30 0.30];

%% ============================================================
%  COMMON EXCITATION-TORQUE LIMIT
%
%  A common vertical scale allows a direct comparison of the
%  excitation level across the selected sea states.
% ============================================================

maximumExcitationTorque = 0;

for seaStatePlotIndex = 1:numel(selectedSeaStates)

    currentSeaStateLabel = ...
        selectedSeaStates(seaStatePlotIndex).label;

    IMresultIndex = find(strcmp( ...
        string({IMresults.label}), ...
        string(currentSeaStateLabel)),1);

    assert(~isempty(IMresultIndex), ...
        '%s was not found in IMresults.', ...
        currentSeaStateLabel);

    excitationTime_s = ...
        IMresults(IMresultIndex).t(:);

    excitationTorque_Nm = ...
        IMresults(IMresultIndex).f_e(:);

    timeWindowLogical = ...
        excitationTime_s >= PTOplotTimeWindow(1) ...
        & excitationTime_s <= PTOplotTimeWindow(2);

    maximumExcitationTorque = max( ...
        maximumExcitationTorque, ...
        max(abs(excitationTorque_Nm(timeWindowLogical))));

end

commonExcitationTorqueLimits = ...
    1.05*maximumExcitationTorque*[-1 1];

%% ============================================================
%  GENERATE ONE FIGURE FOR EACH SEA STATE
% ============================================================

for seaStatePlotIndex = 1:numel(selectedSeaStates)

    currentSeaState = ...
        selectedSeaStates(seaStatePlotIndex);

    currentSeaStateLabel = ...
        currentSeaState.label;

    %% Retrieve the excitation torque used in the simulation

    IMresultIndex = find(strcmp( ...
        string({IMresults.label}), ...
        string(currentSeaStateLabel)),1);

    assert(~isempty(IMresultIndex), ...
        '%s was not found in IMresults.', ...
        currentSeaStateLabel);

    excitationTime_s = ...
        IMresults(IMresultIndex).t(:);

    excitationTorque_Nm = ...
        IMresults(IMresultIndex).f_e(:);

    %% Create figure

    figPTOVelocityForce = figure( ...
        'Color','w', ...
        'Name',[currentSeaStateLabel, ...
        ' excitation torque, PTO velocity and applied force'], ...
        'Units','centimeters', ...
        'Position',[2 2 19 18]);

    PTOlayout = tiledlayout( ...
        3,1, ...
        'TileSpacing','compact', ...
        'Padding','compact');

    %% ========================================================
    %  SUBPLOT 1: WAVE-EXCITATION TORQUE
    % =========================================================

    excitationTorqueAxes = ...
        nexttile(PTOlayout,1);

    hold(excitationTorqueAxes,'on');
    grid(excitationTorqueAxes,'on');
    box(excitationTorqueAxes,'on');

    excitationTorqueLine = plot( ...
        excitationTime_s, ...
        excitationTorque_Nm, ...
        'Color',excitationTorqueColour, ...
        'LineStyle','-', ...
        'LineWidth',lineWidth, ...
        'DisplayName','Wave-excitation torque');

    ylabel('$\tau_e$ [N\,m]');

    xlim(PTOplotTimeWindow);
    ylim(commonExcitationTorqueLimits);

    %title([currentSeaStateLabel, ...
        %': wave-excitation torque']);

    legend( ...
        excitationTorqueAxes, ...
        excitationTorqueLine, ...
        'Location','northeast');

    excitationTorqueAxes.XTickLabel = [];

    %% ========================================================
    %  SUBPLOT 2: PTO TRANSLATIONAL VELOCITY
    % =========================================================

    PTOvelocityAxes = ...
        nexttile(PTOlayout,2);

    hold(PTOvelocityAxes,'on');
    grid(PTOvelocityAxes,'on');
    box(PTOvelocityAxes,'on');

    controllerLegendLines = ...
        gobjects(numel(controllerNames),1);

    for controllerIndex = 1:numel(controllerNames)

        controllerName = ...
            controllerNames{controllerIndex};

        controllerData = ...
            currentSeaState.controllers.(controllerName);

        style = ...
            controllerStyle.(controllerName);

        controllerLegendLines(controllerIndex) = plot( ...
            currentSeaState.time_s, ...
            controllerData.PTOvelocity, ...
            'Color',style.colour, ...
            'LineStyle',style.lineStyle, ...
            'LineWidth',lineWidth, ...
            'DisplayName',style.displayName);

    end

    ylabel('$v_{\mathrm{PTO}}$ [m/s]');
    xlim(PTOplotTimeWindow);

    %title('PTO translational velocity');

    legend( ...
        PTOvelocityAxes, ...
        controllerLegendLines, ...
        'Location','northeast', ...
        'NumColumns',numel(controllerNames));

    PTOvelocityAxes.XTickLabel = [];

    %% ========================================================
    %  SUBPLOT 3: APPLIED PTO FORCE
    % =========================================================

    PTOforceAxes = ...
        nexttile(PTOlayout,3);

    hold(PTOforceAxes,'on');
    grid(PTOforceAxes,'on');
    box(PTOforceAxes,'on');

    for controllerIndex = 1:numel(controllerNames)

        controllerName = ...
            controllerNames{controllerIndex};

        controllerData = ...
            currentSeaState.controllers.(controllerName);

        style = ...
            controllerStyle.(controllerName);

        plot( ...
            currentSeaState.time_s, ...
            controllerData.appliedPTOForce, ...
            'Color',style.colour, ...
            'LineStyle',style.lineStyle, ...
            'LineWidth',lineWidth, ...
            'HandleVisibility','off');

    end

    xlabel('$t$ [s]');
    ylabel('$f_{u,\mathrm{PTO}}$ [N]');

    xlim(PTOplotTimeWindow);

    %title('Applied PTO force');

    %% Link time axes

    linkaxes( ...
        [excitationTorqueAxes ...
         PTOvelocityAxes ...
         PTOforceAxes], ...
        'x');

    %% ========================================================
    %  EXPORT FIGURE
    %
    %  The original filename is retained so that the corresponding
    %  LaTeX figure environment does not need to be modified.
    % =========================================================

    if exportFigures

        PTOfigureFile = fullfile( ...
            figureDirectory, ...
            sprintf( ...
            '%s_PTO_velocity_applied_force.pdf', ...
            currentSeaStateLabel));

        exportgraphics( ...
            figPTOVelocityForce, ...
            PTOfigureFile, ...
            'ContentType','vector');

        fprintf('Figure saved:\n%s\n', ...
            PTOfigureFile);

    end

end
% %% ============================================================
% %  FIGURE: ISS2 OPEN- AND CLOSED-LOOP PTO VELOCITY
% %
% %  Each subplot compares the open-loop response with one
% %  closed-loop controller.
% % ============================================================
% 
% comparisonSeaStateLabel = 'ISS2';
% comparisonTimeWindow_s = [40 70];
% 
% % Locate ISS2 in the closed- and open-loop result structures.
% closedLoopPosition = find(strcmp( ...
%     {closedLoopResults.seaStates.label}, ...
%     comparisonSeaStateLabel),1);
% 
% openLoopPosition = find(strcmp( ...
%     {openLoopResults.seaStates.label}, ...
%     comparisonSeaStateLabel),1);
% 
% assert(~isempty(closedLoopPosition), ...
%     '%s is unavailable in closedLoopResults.', ...
%     comparisonSeaStateLabel);
% 
% assert(~isempty(openLoopPosition), ...
%     '%s is unavailable in openLoopResults.', ...
%     comparisonSeaStateLabel);
% 
% closedISS2 = closedLoopResults.seaStates(closedLoopPosition);
% openISS2 = openLoopResults.seaStates(openLoopPosition);
% 
% %% Common vertical-axis limit
% 
% maximumPTOvelocity = max(abs(openISS2.PTOvelocity));
% 
% for controllerIndex = 1:numel(controllerNames)
% 
%     controllerName = controllerNames{controllerIndex};
% 
%     controllerData = ...
%         closedISS2.controllers.(controllerName);
% 
%     maximumPTOvelocity = max( ...
%         maximumPTOvelocity, ...
%         max(abs(controllerData.PTOvelocity)));
% 
% end
% 
% velocityAxisLimit = 1.05*maximumPTOvelocity;
% 
% if velocityAxisLimit == 0
%     velocityAxisLimit = 1;
% end
% 
% %% Create figure
% 
% numberControllers = numel(controllerNames);
% figureHeight = 4.8*numberControllers + 1.5;
% 
% figISS2PTOvelocity = figure( ...
%     'Color','w', ...
%     'Name','ISS2 open- and closed-loop PTO velocity', ...
%     'Units','centimeters', ...
%     'Position',[2 2 18 figureHeight]);
% 
% velocityLayout = tiledlayout( ...
%     numberControllers,1, ...
%     'TileSpacing','compact', ...
%     'Padding','compact');
% 
% openLoopColour = [0.35 0.35 0.35];
% velocityAxes = gobjects(numberControllers,1);
% 
% for controllerIndex = 1:numberControllers
% 
%     controllerName = controllerNames{controllerIndex};
%     controllerData = ...
%         closedISS2.controllers.(controllerName);
% 
%     style = controllerStyle.(controllerName);
% 
%     velocityAxes(controllerIndex) = nexttile(velocityLayout);
% 
%     hold(velocityAxes(controllerIndex),'on');
%     grid(velocityAxes(controllerIndex),'on');
%     box(velocityAxes(controllerIndex),'on');
% 
%     plot( ...
%         openISS2.time_s, ...
%         openISS2.PTOvelocity, ...
%         '-', ...
%         'Color',openLoopColour, ...
%         'LineWidth',1.3, ...
%         'DisplayName','Open loop');
% 
%     plot( ...
%         closedISS2.time_s, ...
%         controllerData.PTOvelocity, ...
%         style.lineStyle, ...
%         'Color',style.colour, ...
%         'LineWidth',lineWidth, ...
%         'DisplayName',style.displayName);
% 
%     ylabel('$v_{\mathrm{PTO}}$ [m/s]');
%     %title(style.displayName);
% 
%     xlim(comparisonTimeWindow_s);
%     ylim([-velocityAxisLimit velocityAxisLimit]);
% 
%     legend( ...
%         'Location','northeast', ...
%         'NumColumns',2);
% 
%     if controllerIndex < numberControllers
%         velocityAxes(controllerIndex).XTickLabel = [];
%     else
%         xlabel('$t$ [s]');
%     end
% 
% end
% 
% linkaxes(velocityAxes,'x');
% 
% %% Export figure
% 
% if exportFigures
% 
%     velocityFigureFile = fullfile( ...
%         figureDirectory, ...
%         'ISS2_PTO_velocity_open_closed_loop.pdf');
% 
%     exportgraphics( ...
%         figISS2PTOvelocity, ...
%         velocityFigureFile, ...
%         'ContentType','vector');
% 
%     fprintf('Figure saved:\n%s\n',velocityFigureFile);
% 
% end

% %% ============================================================
% %  FIGURES: PTO RELATIVE DISPLACEMENT AND STROKE LIMITS
% %
% %  One figure is generated for each selected sea state.
% %  All selected controllers are shown in each figure.
% % ============================================================
% 
% PTOstrokeTotal_m = 0.280;
% PTOstrokePositiveLimit_m =  PTOstrokeTotal_m/2;
% PTOstrokeNegativeLimit_m = -PTOstrokeTotal_m/2;
% 
% for seaStateIndex = 1:numel(selectedSeaStates)
% 
%     seaStateData = selectedSeaStates(seaStateIndex);
%     seaStateLabel = seaStateData.label;
% 
%     figPTOdisplacement = figure( ...
%         'Color','w', ...
%         'Name',[seaStateLabel ' PTO displacement'], ...
%         'Units','centimeters', ...
%         'Position',[2 2 18 10]);
% 
%     displacementAxes = axes(figPTOdisplacement);
% 
%     hold(displacementAxes,'on');
%     grid(displacementAxes,'on');
%     box(displacementAxes,'on');
% 
%     %% Controller responses
% 
%     controllerLines = gobjects(numel(controllerNames),1);
% 
%     for controllerIndex = 1:numel(controllerNames)
% 
%         controllerName = controllerNames{controllerIndex};
% 
%         controllerData = ...
%             seaStateData.controllers.(controllerName);
% 
%         style = controllerStyle.(controllerName);
% 
%         controllerLines(controllerIndex) = plot( ...
%             seaStateData.time_s, ...
%             controllerData.relativePTOdisplacement, ...
%             'LineStyle',style.lineStyle, ...
%             'Color',style.colour, ...
%             'LineWidth',lineWidth, ...
%             'DisplayName',style.displayName);
% 
%     end
% 
%     %% Physical stroke limits
% 
%     upperStrokeLine = yline( ...
%         displacementAxes, ...
%         PTOstrokePositiveLimit_m, ...
%         '--', ...
%         'Color',blueColors(1,:), ...
%         'LineWidth',1.6, ...
%         'DisplayName','$z_{\mathrm{PTO,max}}$');
% 
%     lowerStrokeLine = yline( ...
%         displacementAxes, ...
%         PTOstrokeNegativeLimit_m, ...
%         '--', ...
%         'Color',blueColors(1,:), ...
%         'LineWidth',1.6, ...
%         'HandleVisibility','off');
% 
%     %% Axes and legend
% 
%     xlabel('$t$ [s]');
%     ylabel('$z_{\mathrm{PTO}}$ [m]');
% 
%     %xlim([ ...
%         % seaStateData.time_s(1), ...
%         % seaStateData.time_s(end)]);
%        xlim([40 70]);
% 
%     displacementMargin_m = 0.015;
% 
%     ylim([ ...
%         PTOstrokeNegativeLimit_m-displacementMargin_m, ...
%         PTOstrokePositiveLimit_m+displacementMargin_m]);
% 
%     legend( ...
%         [controllerLines; upperStrokeLine], ...
%         'Location','best', ...
%         'NumColumns',2);
% 
%     %% Export figure
% 
%     if exportFigures
% 
%         displacementFigureFile = fullfile( ...
%             figureDirectory, ...
%             [seaStateLabel '_PTO_displacement.pdf']);
% 
%         exportgraphics( ...
%             figPTOdisplacement, ...
%             displacementFigureFile, ...
%             'ContentType','vector');
% 
%         fprintf('Figure saved:\n%s\n', ...
%             displacementFigureFile);
% 
%     end
% 
% end

%% ============================================================
%  FIGURES: WEC ANGULAR POSITION AND EQUIVALENT PTO-STROKE LIMITS
%
%  The PTO stroke limits are converted into angular limits using
%  the kinematic Jacobian evaluated at the nominal equilibrium.
% ============================================================

PTOstrokeTotal_m = 0.280;
PTOstrokeLimit_m = PTOstrokeTotal_m/2;

% Equilibrium Jacobian obtained from the nominal WEC geometry.
J0_mPerRad = -1.320909e-01;

% Linearised angular limits corresponding to +/-0.14 m.
thetaLimitMagnitude_rad = PTOstrokeLimit_m/abs(J0_mPerRad);

thetaPositiveLimit_rad =  thetaLimitMagnitude_rad;
thetaNegativeLimit_rad = -thetaLimitMagnitude_rad;

fprintf('\nEquivalent linearised angular limits:\n');
fprintf('Lower limit: % .6f rad\n',thetaNegativeLimit_rad);
fprintf('Upper limit: % .6f rad\n',thetaPositiveLimit_rad);

selectedSeaStates = ...
    closedLoopResults.seaStates(1:lastSeaStateToPlot);

for seaStateIndex = 1:numel(selectedSeaStates)

    seaStateData = selectedSeaStates(seaStateIndex);
    seaStateLabel = seaStateData.label;

    figAngularPosition = figure( ...
        'Color','w', ...
        'Name',[seaStateLabel ' WEC angular position'], ...
        'Units','centimeters', ...
        'Position',[2 2 18 10]);

    angularPositionAxes = axes(figAngularPosition);

    hold(angularPositionAxes,'on');
    grid(angularPositionAxes,'on');
    box(angularPositionAxes,'on');

    %% Controller responses

    controllerLines = gobjects(numel(controllerNames),1);

    for controllerIndex = 1:numel(controllerNames)

        controllerName = controllerNames{controllerIndex};

        controllerData = ...
            seaStateData.controllers.(controllerName);

        style = controllerStyle.(controllerName);

        controllerLines(controllerIndex) = plot( ...
            seaStateData.time_s, ...
            controllerData.angularPosition, ...
            'LineStyle',style.lineStyle, ...
            'Color',style.colour, ...
            'LineWidth',lineWidth, ...
            'DisplayName',style.displayName);

    end

    %% Equivalent angular limits imposed by the PTO stroke

    upperAngularLimitLine = yline( ...
        angularPositionAxes, ...
        thetaPositiveLimit_rad, ...
        '--', ...
        'Color',blueColors(1,:), ...
        'LineWidth',1.6, ...
        'DisplayName','$\Delta\theta_{A,\mathrm{lim}}$');

    yline( ...
        angularPositionAxes, ...
        thetaNegativeLimit_rad, ...
        '--', ...
        'Color',blueColors(1,:), ...
        'LineWidth',1.6, ...
        'HandleVisibility','off');

    %% Axes and legend

    xlabel('$t$ [s]');
    ylabel('$\Delta\theta_A$ [rad]');

    % xlim([ ...
    %     seaStateData.time_s(1), ...
    %     seaStateData.time_s(end)]);
    xlim([40 70]);

    angularMargin_rad = 0.05*thetaLimitMagnitude_rad;

    ylim([ ...
        thetaNegativeLimit_rad-angularMargin_rad, ...
        thetaPositiveLimit_rad+angularMargin_rad]);

    legend( ...
        [controllerLines; upperAngularLimitLine], ...
        'Location','best', ...
        'NumColumns',2);

    %% Export figure

    if exportFigures

        angularPositionFigureFile = fullfile( ...
            figureDirectory, ...
            [seaStateLabel ...
            '_WEC_angular_position_PTO_limits.pdf']);

        exportgraphics( ...
            figAngularPosition, ...
            angularPositionFigureFile, ...
            'ContentType','vector');

        fprintf('Figure saved:\n%s\n', ...
            angularPositionFigureFile);

    end

end

% %% ================================================================================
% %  FIGURE: FLOATER POSITION RELATIVE TO INCIDENT WAVE IN CASE USE WAVE PROBE15
% % =================================================================================
% 
% plotTimeWindow_s = [40 70];
% 
% for seaStateIndex = 1:numel(waveSeaStateLabels)
% 
%     seaStateLabel = waveSeaStateLabels{seaStateIndex};
% 
%     resultPosition = find(strcmp( ...
%         {closedLoopResults.seaStates.label}, ...
%         seaStateLabel),1);
% 
%     seaStateData = ...
%         closedLoopResults.seaStates(resultPosition);
% 
%     numberControllers = numel(controllerNames);
% 
%     figImmersion = figure( ...
%         'Color','w', ...
%         'Name',[seaStateLabel ' floater immersion'], ...
%         'Units','centimeters', ...
%         'Position',[2 2 18 4.8*numberControllers+1.5]);
% 
%     immersionLayout = tiledlayout( ...
%         numberControllers,1, ...
%         'TileSpacing','compact', ...
%         'Padding','compact');
% 
%     immersionAxes = gobjects(numberControllers,1);
% 
%     for controllerIndex = 1:numberControllers
% 
%         controllerName = controllerNames{controllerIndex};
% 
%         controllerData = ...
%             seaStateData.controllers.(controllerName);
% 
%         style = controllerStyle.(controllerName);
% 
%         immersionAxes(controllerIndex) = ...
%             nexttile(immersionLayout);
% 
%         hold(immersionAxes(controllerIndex),'on');
%         grid(immersionAxes(controllerIndex),'on');
%         box(immersionAxes(controllerIndex),'on');
% 
%         plot( ...
%             seaStateData.time_s, ...
%             controllerData.floaterTopPosition, ...
%             '-', ...
%             'Color',style.colour, ...
%             'LineWidth',lineWidth, ...
%             'DisplayName','Floater top');
% 
%         plot( ...
%             seaStateData.time_s, ...
%             controllerData.incidentWaveElevation, ...
%             '-', ...
%             'Color',[0.10 0.35 0.75], ...
%             'LineWidth',1.3, ...
%             'DisplayName','Incident wave');
% 
%         plot( ...
%             seaStateData.time_s, ...
%             controllerData.floaterBottomPosition, ...
%             '--', ...
%             'Color',style.colour, ...
%             'LineWidth',lineWidth, ...
%             'DisplayName','Floater bottom');
% 
%         xlim(plotTimeWindow_s);
% 
%         ylabel('$z$ [m]');
%         %title(style.displayName);
% 
%         legend( ...
%             'Location','best', ...
%             'NumColumns',3);
% 
%         if controllerIndex < numberControllers
%             immersionAxes(controllerIndex).XTickLabel = [];
%         else
%             xlabel('$t$ [s]');
%         end
% 
%     end
% 
%     linkaxes(immersionAxes,'x');
% 
%     if exportFigures
% 
%         immersionFigureFile = fullfile( ...
%             figureDirectory, ...
%             [seaStateLabel ...
%             '_floater_incident_wave_clearance.pdf']);
% 
%         exportgraphics( ...
%             figImmersion, ...
%             immersionFigureFile, ...
%             'ContentType','vector');
% 
%     end
% end

%% ============================================================
%  PLOT FLOATER POSITIONS AND LOCAL FREE-SURFACE ELEVATIONS
%
%  One figure is generated for each sea state.
%  Each subplot corresponds to one controller.
%  WP4 and WP5 are plotted separately.
% ============================================================

%% Plot selection

seaStateIndicesToPlot = 1:3;

controllersToPlot = {
    'Passive'
    % 'Reactive'
    'H2'
    'Hinf'
};

% Representative time interval used in the thesis.
plotTimeLimits_s = [40 70];

%% Wave-probe colours

WP4Colour = [0.25 0.25 0.25];  % Dark grey
WP5Colour = [0.65 0.65 0.65];  % Light grey

%% Controller colours, if not previously defined

if ~exist('controllerStyle','var')

    controllerStyle.Passive.colour = blueColors(2,:);
    controllerStyle.Passive.displayName = 'Passive';

    controllerStyle.Reactive.colour = blueColors(3,:);
    controllerStyle.Reactive.displayName = 'Reactive';

    controllerStyle.H2.colour = greenColors(2,:);
    controllerStyle.H2.displayName = '$H_2$';

    controllerStyle.Hinf.colour = greenColors(3,:);
    controllerStyle.Hinf.displayName = '$H_\infty$';

end

%% Generate one figure per sea state

for selectedSeaStateIndex = seaStateIndicesToPlot

    seaStateData = ...
        closedLoopResults.seaStates(selectedSeaStateIndex);

    seaStateLabel = ...
        seaStateData.label;

    simulationTime_s = ...
        seaStateData.time_s(:);

    nControllersToPlot = ...
        numel(controllersToPlot);

    fig = figure( ...
        'Color','w', ...
        'Name',[seaStateLabel, ...
        ' floater immersion and emergence'], ...
        'Units','centimeters', ...
        'Position',[2 2 19 6*nControllersToPlot]);

    tiledLayoutHandle = tiledlayout( ...
        nControllersToPlot, ...
        1, ...
        'TileSpacing','compact', ...
        'Padding','compact');

    for controllerIndex = 1:nControllersToPlot

        controllerName = ...
            controllersToPlot{controllerIndex};

        controllerData = ...
            seaStateData.controllers.(controllerName);

        controllerColour = ...
            controllerStyle.(controllerName).colour;

        controllerDisplayName = ...
            controllerStyle.(controllerName).displayName;

        floaterTopPosition_m = ...
            controllerData.floaterTopPosition(:);

        floaterBottomPosition_m = ...
            controllerData.floaterBottomPosition(:);

        etaWP4_m = ...
            controllerData.localWaveElevationWP4(:);

        etaWP5_m = ...
            controllerData.localWaveElevationWP5(:);

        nexttile;
        hold on;
        grid on;
        box on;

        %% Local free-surface elevations

        plot( ...
            simulationTime_s, ...
            etaWP4_m, ...
            '-', ...
            'Color',WP4Colour, ...
            'LineWidth',1.5, ...
            'DisplayName','Wave elevation: WP4');

        plot( ...
            simulationTime_s, ...
            etaWP5_m, ...
            '--', ...
            'Color',WP5Colour, ...
            'LineWidth',1.5, ...
            'DisplayName','Wave elevation: WP5');

        %% Floater upper and lower positions

        plot( ...
            simulationTime_s, ...
            floaterTopPosition_m, ...
            '-', ...
            'Color',controllerColour, ...
            'LineWidth',2.0, ...
            'DisplayName',[controllerDisplayName, ...
            ': floater top']);

        plot( ...
            simulationTime_s, ...
            floaterBottomPosition_m, ...
            '-.', ...
            'Color',controllerColour, ...
            'LineWidth',2.0, ...
            'DisplayName',[controllerDisplayName, ...
            ': floater bottom']);

        %% Still-water level

        yline( ...
            0, ...
            ':', ...
            'Color',[0.10 0.10 0.10], ...
            'LineWidth',1.0, ...
            'DisplayName','Still-water level');

        %% Axis configuration

        xlim(plotTimeLimits_s);

        signalMinimum = min([ ...
            etaWP4_m
            etaWP5_m
            floaterTopPosition_m
            floaterBottomPosition_m]);

        signalMaximum = max([ ...
            etaWP4_m
            etaWP5_m
            floaterTopPosition_m
            floaterBottomPosition_m]);

        verticalRange = ...
            signalMaximum-signalMinimum;

        if verticalRange <= 0
            verticalRange = 1;
        end

        ylim([ ...
            signalMinimum-0.08*verticalRange, ...
            signalMaximum+0.08*verticalRange]);

        ylabel('$z$ [m]');

        % title( ...
        %     sprintf( ...
        %     '%s -- %s', ...
        %     seaStateLabel, ...
        %     controllerDisplayName), ...
        %     'Interpreter','latex');

        legend( ...
            'Location','eastoutside', ...
            'NumColumns',1);

        if controllerIndex == nControllersToPlot
            xlabel('$t$ [s]');
        end

    end

    %% Export figure

    figureFile = fullfile( ...
        figuresFolder, ...
        [seaStateLabel, ...
        '_floater_positions_WP4_WP5.pdf']);

    exportgraphics( ...
        fig, ...
        figureFile, ...
        'ContentType','vector');

    fprintf('Figure saved: %s\n',figureFile);

end


%% ============================================================
%  INSTANTANEOUS PTO POWER
%
%  One figure is generated for each sea state.
%  All selected controllers are shown in the same axes.
%
%  Positive power: energy absorbed by the PTO.
%  Negative power: energy returned to the WEC.
% ============================================================

%% Plot selection

seaStateIndicesToPlot = 1:3;
% seaStateIndicesToPlot = 1:6;

controllersToPlot = {
    'Passive'
    % 'Reactive'
    'H2'
    'Hinf'
};

plotTimeLimits_s = [40 70];

%% Output folder

figuresFolder = fullfile( ...
    pwd, ...
    'closed_loop_figures');

if ~exist(figuresFolder,'dir')
    mkdir(figuresFolder);
end

%% Generate one figure per sea state

for selectedSeaStateIndex = seaStateIndicesToPlot

    seaStateData = ...
        closedLoopResults.seaStates(selectedSeaStateIndex);

    seaStateLabel = ...
        seaStateData.label;

    simulationTime_s = ...
        seaStateData.time_s(:);

    fig = figure( ...
        'Color','w', ...
        'Name',[seaStateLabel, ...
        ' instantaneous PTO power'], ...
        'Units','centimeters', ...
        'Position',[2 2 18 10]);

    hold on;
    grid on;
    box on;

    for controllerIndex = 1:numel(controllersToPlot)

        controllerName = ...
            controllersToPlot{controllerIndex};

        controllerData = ...
            seaStateData.controllers.(controllerName);

        controllerColour = ...
            controllerStyle.(controllerName).colour;

        controllerLineStyle = ...
            controllerStyle.(controllerName).lineStyle;

        controllerDisplayName = ...
            controllerStyle.(controllerName).displayName;

        %% Retrieve instantaneous PTO power

        if isfield(controllerData,'PTOpower')

            instantaneousPower_W = ...
                controllerData.PTOpower(:);

        elseif isfield(controllerData,'power')

            instantaneousPower_W = ...
                controllerData.power(:);

        elseif isfield(controllerData,'instantaneousPower')

            instantaneousPower_W = ...
                controllerData.instantaneousPower(:);

        else

            error( ...
                ['No instantaneous PTO-power signal was found ', ...
                'for %s in %s.'], ...
                controllerName, ...
                seaStateLabel);

        end

        %% Plot controller response

        plot( ...
            simulationTime_s, ...
            instantaneousPower_W, ...
            'Color',controllerColour, ...
            'LineStyle',controllerLineStyle, ...
            'LineWidth',1.8, ...
            'DisplayName',controllerDisplayName);

    end

    %% Zero-power reference

    yline( ...
        0, ...
        '--', ...
        'Color',[0.30 0.30 0.30], ...
        'LineWidth',1.0, ...
        'HandleVisibility','off');

    %% Axis configuration

    xlim(plotTimeLimits_s);

    xlabel('$t$ [s]');
    ylabel('$P_{\mathrm{PTO}}$ [W]');

    % title( ...
    %     sprintf( ...
    %     '%s -- instantaneous PTO power', ...
    %     seaStateLabel), ...
    %     'Interpreter','latex');

    legend( ...
        'Location','best', ...
        'NumColumns',1);

    %% Export figure

    figureFile = fullfile( ...
        figuresFolder, ...
        [seaStateLabel, ...
        '_instantaneous_PTO_power.pdf']);

    exportgraphics( ...
        fig, ...
        figureFile, ...
        'ContentType','vector');

    fprintf('Figure saved: %s\n',figureFile);

end

%% ============================================================
%  PASSIVE-CONTROLLER PTO-DYNAMICS DIAGNOSTIC
%
%  ISS2 is used because it presents the largest excitation among
%  ISS1--ISS3.
%
%  Upper subplot:
%    saturated force command versus applied PTO force.
%
%  Lower subplot:
%    ideal passive power versus power calculated using the force
%    effectively applied by the dynamic PTO model.
% ============================================================

passiveDiagnosticSeaStateLabel = 'ISS2';

% Short interval selected to make the actuator phase lag visible.
passiveDiagnosticTimeWindow_s = [45 52];

%% Locate ISS2 in the closed-loop results

seaStateResultIndex = find(strcmp( ...
    string({closedLoopResults.seaStates.label}), ...
    string(passiveDiagnosticSeaStateLabel)),1);

assert(~isempty(seaStateResultIndex), ...
    '%s was not found in closedLoopResults.', ...
    passiveDiagnosticSeaStateLabel);

seaStateData = ...
    closedLoopResults.seaStates(seaStateResultIndex);

passiveData = ...
    seaStateData.controllers.Passive;

simulationTime_s = ...
    seaStateData.time_s(:);

%% Locate the corresponding passive gain

IMresultIndex = find(strcmp( ...
    string({IMresults.label}), ...
    string(passiveDiagnosticSeaStateLabel)),1);

assert(~isempty(IMresultIndex), ...
    '%s was not found in IMresults.', ...
    passiveDiagnosticSeaStateLabel);

Kp_passive = ...
    IMresults(IMresultIndex).K_p;

%% ============================================================
%  RETRIEVE PASSIVE-CONTROLLER SIGNALS
% ============================================================

%% Force command after command saturation

if isfield(passiveData,'saturatedCommandForce')

    referencePTOForce_N = ...
        passiveData.saturatedCommandForce(:);

elseif isfield(passiveData,'referencePTOForce')

    referencePTOForce_N = ...
        passiveData.referencePTOForce(:);

elseif isfield(passiveData,'rawPTOForce')

    referencePTOForce_N = ...
        passiveData.rawPTOForce(:);

else

    error([ ...
        'No reference or saturated PTO-force command was found ', ...
        'for the passive controller.']);

end

%% Force effectively applied by the PTO

if isfield(passiveData,'appliedPTOForce')

    appliedPTOForce_N = ...
        passiveData.appliedPTOForce(:);

elseif isfield(passiveData,'PTOforce')

    appliedPTOForce_N = ...
        passiveData.PTOforce(:);

else

    error([ ...
        'No applied PTO-force signal was found for the ', ...
        'passive controller.']);

end

%% WEC angular velocity

angularVelocity_radps = ...
    passiveData.angularVelocity(:);

%% Applied PTO power

if isfield(passiveData,'PTOpower')

    appliedPTOPower_W = ...
        passiveData.PTOpower(:);

elseif isfield(passiveData,'power')

    appliedPTOPower_W = ...
        passiveData.power(:);

elseif isfield(passiveData,'instantaneousPower')

    appliedPTOPower_W = ...
        passiveData.instantaneousPower(:);

else

    error([ ...
        'No applied PTO-power signal was found for the ', ...
        'passive controller.']);

end

%% Ideal passive power
%
% For the ideal damping law, the absorbed power is non-negative.

idealPassivePower_W = ...
    Kp_passive.*angularVelocity_radps.^2;

%% Check signal lengths

assert( ...
    numel(referencePTOForce_N) == numel(simulationTime_s) ...
    && numel(appliedPTOForce_N) == numel(simulationTime_s) ...
    && numel(idealPassivePower_W) == numel(simulationTime_s) ...
    && numel(appliedPTOPower_W) == numel(simulationTime_s), ...
    'The passive-controller signals have inconsistent lengths.');

%% ============================================================
%  FIGURE STYLE
% ============================================================

referenceColour = blueColors(3,:);

if exist('controllerStyle','var') ...
        && isfield(controllerStyle,'Passive')

    appliedColour = ...
        controllerStyle.Passive.colour;

else

    appliedColour = [0.25 0.45 0.70];

end

if ~exist('lineWidth','var')
    lineWidth = 1.8;
end

%% ============================================================
%  CREATE FIGURE
% ============================================================

figPassivePTODynamics = figure( ...
    'Color','w', ...
    'Name','ISS2 passive-controller PTO dynamics', ...
    'Units','centimeters', ...
    'Position',[2 2 18 12]);

passivePTOLayout = tiledlayout( ...
    2,1, ...
    'TileSpacing','compact', ...
    'Padding','compact');

%% ============================================================
%  SUBPLOT 1: REFERENCE AND APPLIED PTO FORCES
% ============================================================

forceAxes = ...
    nexttile(passivePTOLayout,1);

hold(forceAxes,'on');
grid(forceAxes,'on');
box(forceAxes,'on');

plot( ...
    simulationTime_s, ...
    referencePTOForce_N, ...
    '--', ...
    'Color',referenceColour, ...
    'LineWidth',lineWidth, ...
    'DisplayName','$f_{u,\mathrm{ref}}$');

plot( ...
    simulationTime_s, ...
    appliedPTOForce_N, ...
    '-', ...
    'Color',appliedColour, ...
    'LineWidth',lineWidth, ...
    'DisplayName','$f_{u,\mathrm{PTO}}$');

yline( ...
    0, ...
    ':', ...
    'Color',[0.50 0.50 0.50], ...
    'LineWidth',0.9, ...
    'HandleVisibility','off');

ylabel('Force [N]');

xlim(passiveDiagnosticTimeWindow_s);

%title('Passive-controller force command and applied PTO force');

legend( ...
    forceAxes, ...
    'Location','northeast', ...
    'NumColumns',2);

forceAxes.XTickLabel = [];

%% ============================================================
%  SUBPLOT 2: IDEAL AND APPLIED PTO POWERS
% ============================================================

powerAxes = ...
    nexttile(passivePTOLayout,2);

hold(powerAxes,'on');
grid(powerAxes,'on');
box(powerAxes,'on');

plot( ...
    simulationTime_s, ...
    idealPassivePower_W, ...
    '--', ...
    'Color',referenceColour, ...
    'LineWidth',lineWidth, ...
    'DisplayName','$P_{\mathrm{p,ideal}}$');

plot( ...
    simulationTime_s, ...
    appliedPTOPower_W, ...
    '-', ...
    'Color',appliedColour, ...
    'LineWidth',lineWidth, ...
    'DisplayName','$P_{\mathrm{PTO}}$');

yline( ...
    0, ...
    ':', ...
    'Color',[0.20 0.20 0.20], ...
    'LineWidth',1.0, ...
    'HandleVisibility','off');

xlabel('$t$ [s]');
ylabel('Power [W]');

xlim(passiveDiagnosticTimeWindow_s);

%title('Ideal passive power and applied PTO power');

legend( ...
    powerAxes, ...
    'Location','northeast', ...
    'NumColumns',2);

%% Link the time axes

linkaxes( ...
    [forceAxes powerAxes], ...
    'x');

%% ============================================================
%  PRINT DIAGNOSTIC RESULTS FOR THE SELECTED INTERVAL
% ============================================================

timeWindowLogical = ...
    simulationTime_s >= passiveDiagnosticTimeWindow_s(1) ...
    & simulationTime_s <= passiveDiagnosticTimeWindow_s(2);

timeWindow_s = ...
    simulationTime_s(timeWindowLogical);

idealPowerWindow_W = ...
    idealPassivePower_W(timeWindowLogical);

appliedPowerWindow_W = ...
    appliedPTOPower_W(timeWindowLogical);

positiveAppliedEnergy_J = trapz( ...
    timeWindow_s, ...
    max(appliedPowerWindow_W,0));

returnedAppliedEnergy_J = -trapz( ...
    timeWindow_s, ...
    min(appliedPowerWindow_W,0));

netAppliedEnergy_J = ...
    trapz(timeWindow_s,appliedPowerWindow_W);

fprintf('\n');
fprintf('============================================================\n');
fprintf('PASSIVE PTO-DYNAMICS DIAGNOSTIC: ISS2\n');
fprintf('Time interval: %.3f--%.3f s\n', ...
    passiveDiagnosticTimeWindow_s(1), ...
    passiveDiagnosticTimeWindow_s(2));
fprintf('============================================================\n');

fprintf('Minimum ideal passive power:  % .6e W\n', ...
    min(idealPowerWindow_W));

fprintf('Minimum applied PTO power:    % .6e W\n', ...
    min(appliedPowerWindow_W));

fprintf('Positive applied energy:      % .6e J\n', ...
    positiveAppliedEnergy_J);

fprintf('Returned applied energy:      % .6e J\n', ...
    returnedAppliedEnergy_J);

fprintf('Net applied energy:           % .6e J\n', ...
    netAppliedEnergy_J);

%% ============================================================
%  EXPORT FIGURE
% ============================================================

if ~exist('figureDirectory','var')

    figureDirectory = fullfile( ...
        pwd, ...
        'closed_loop_figures');

end

if ~exist(figureDirectory,'dir')
    mkdir(figureDirectory);
end

if ~exist('exportFigures','var')
    exportFigures = true;
end

if exportFigures

    passivePTODynamicsFile = fullfile( ...
        figureDirectory, ...
        'ISS2_passive_PTO_dynamics.pdf');

    exportgraphics( ...
        figPassivePTODynamics, ...
        passivePTODynamicsFile, ...
        'ContentType','vector');

    fprintf('Figure saved:\n%s\n', ...
        passivePTODynamicsFile);

end

%% ============================================================
%  ROBUST-CONTROLLER PTO FORCE-DYNAMICS COMPARISON
%
%  Single figure with two vertical axes.
%
%  Left axis:  H2 reference and applied PTO forces.
%  Right axis: H-infinity reference and applied PTO forces.
%
%  Dashed line: force reference after command saturation.
%  Solid line:  force effectively applied by the PTO.
% ============================================================

robustDiagnosticSeaStateLabel = 'ISS2';

% Use the same interval adopted for the passive-controller figure.
if exist('passiveDiagnosticTimeWindow_s','var')

    robustDiagnosticTimeWindow_s = ...
        passiveDiagnosticTimeWindow_s;

else

    robustDiagnosticTimeWindow_s = [45 52];

end

%% Locate ISS2

seaStateResultIndex = find(strcmp( ...
    string({closedLoopResults.seaStates.label}), ...
    string(robustDiagnosticSeaStateLabel)),1);

assert(~isempty(seaStateResultIndex), ...
    '%s was not found in closedLoopResults.', ...
    robustDiagnosticSeaStateLabel);

seaStateData = ...
    closedLoopResults.seaStates(seaStateResultIndex);

simulationTime_s = ...
    seaStateData.time_s(:);

%% Retrieve H2 data

H2Data = ...
    seaStateData.controllers.H2;

if isfield(H2Data,'saturatedCommandForce')

    H2ReferenceForce_N = ...
        H2Data.saturatedCommandForce(:);

elseif isfield(H2Data,'referencePTOForce')

    H2ReferenceForce_N = ...
        H2Data.referencePTOForce(:);

elseif isfield(H2Data,'rawPTOForce')

    H2ReferenceForce_N = ...
        H2Data.rawPTOForce(:);

else

    error('No H2 reference PTO-force signal was found.');

end

if isfield(H2Data,'appliedPTOForce')

    H2AppliedForce_N = ...
        H2Data.appliedPTOForce(:);

elseif isfield(H2Data,'PTOforce')

    H2AppliedForce_N = ...
        H2Data.PTOforce(:);

else

    error('No H2 applied PTO-force signal was found.');

end

%% Retrieve H-infinity data

HinfData = ...
    seaStateData.controllers.Hinf;

if isfield(HinfData,'saturatedCommandForce')

    HinfReferenceForce_N = ...
        HinfData.saturatedCommandForce(:);

elseif isfield(HinfData,'referencePTOForce')

    HinfReferenceForce_N = ...
        HinfData.referencePTOForce(:);

elseif isfield(HinfData,'rawPTOForce')

    HinfReferenceForce_N = ...
        HinfData.rawPTOForce(:);

else

    error('No H-infinity reference PTO-force signal was found.');

end

if isfield(HinfData,'appliedPTOForce')

    HinfAppliedForce_N = ...
        HinfData.appliedPTOForce(:);

elseif isfield(HinfData,'PTOforce')

    HinfAppliedForce_N = ...
        HinfData.PTOforce(:);

else

    error('No H-infinity applied PTO-force signal was found.');

end

%% Check signal lengths

assert( ...
    numel(H2ReferenceForce_N) == numel(simulationTime_s) ...
    && numel(H2AppliedForce_N) == numel(simulationTime_s) ...
    && numel(HinfReferenceForce_N) == numel(simulationTime_s) ...
    && numel(HinfAppliedForce_N) == numel(simulationTime_s), ...
    'The robust-controller force signals have inconsistent lengths.');

%% Controller colours

H2Colour = ...
    controllerStyle.H2.colour;

HinfColour = ...
    controllerStyle.Hinf.colour;

if ~exist('lineWidth','var')
    lineWidth = 1.8;
end

%% Create figure

figRobustPTODynamics = figure( ...
    'Color','w', ...
    'Name','ISS2 robust-controller PTO force dynamics', ...
    'Units','centimeters', ...
    'Position',[2 2 18 9]);

robustForceAxes = axes(figRobustPTODynamics);

hold(robustForceAxes,'on');
grid(robustForceAxes,'on');
box(robustForceAxes,'on');

%% ============================================================
%  LEFT AXIS: H2 FORCES
% ============================================================

yyaxis(robustForceAxes,'left');

H2ReferenceLine = plot( ...
    simulationTime_s, ...
    H2ReferenceForce_N, ...
    '--', ...
    'Color',H2Colour, ...
    'LineWidth',lineWidth, ...
    'DisplayName','$H_2$: $f_{u,\mathrm{ref}}$');

H2AppliedLine = plot( ...
    simulationTime_s, ...
    H2AppliedForce_N, ...
    '-', ...
    'Color',H2Colour, ...
    'LineWidth',lineWidth, ...
    'DisplayName','$H_2$: $f_{u,\mathrm{PTO}}$');

ylabel('$H_2$ force [N]');

robustForceAxes.YAxis(1).Color = H2Colour;

%% ============================================================
%  RIGHT AXIS: H-INFINITY FORCES
% ============================================================

yyaxis(robustForceAxes,'right');

HinfReferenceLine = plot( ...
    simulationTime_s, ...
    HinfReferenceForce_N, ...
    '--', ...
    'Color',HinfColour, ...
    'LineWidth',lineWidth, ...
    'DisplayName','$H_\infty$: $f_{u,\mathrm{ref}}$');

HinfAppliedLine = plot( ...
    simulationTime_s, ...
    HinfAppliedForce_N, ...
    '-', ...
    'Color',HinfColour, ...
    'LineWidth',lineWidth, ...
    'DisplayName','$H_\infty$: $f_{u,\mathrm{PTO}}$');

ylabel('$H_\infty$ force [N]');

robustForceAxes.YAxis(2).Color = HinfColour;

%% Axis configuration

xlim(robustDiagnosticTimeWindow_s);

xlabel('$t$ [s]');

% title([ ...
%     robustDiagnosticSeaStateLabel, ...
%     ': robust-controller reference and applied PTO forces']);

legend( ...
    [H2ReferenceLine ...
     H2AppliedLine ...
     HinfReferenceLine ...
     HinfAppliedLine], ...
    'Location','northeast', ...
    'NumColumns',2);

%% Export figure

if ~exist('figureDirectory','var')

    figureDirectory = fullfile( ...
        pwd, ...
        'closed_loop_figures');

end

if ~exist(figureDirectory,'dir')
    mkdir(figureDirectory);
end

if ~exist('exportFigures','var')
    exportFigures = true;
end

if exportFigures

    robustPTODynamicsFile = fullfile( ...
        figureDirectory, ...
        'ISS2_robust_PTO_force_dynamics.pdf');

    exportgraphics( ...
        figRobustPTODynamics, ...
        robustPTODynamicsFile, ...
        'ContentType','vector');

    fprintf('Figure saved:\n%s\n', ...
        robustPTODynamicsFile);

end


%% ============================================================
%  ISS2: FORCE COMMAND BEFORE AND AFTER SATURATION
%  Uses the controllerNames selected at the top of this script.
% ============================================================

forcePlotSeaState = 'ISS2';

availableSeaStates = string({closedLoopResults.seaStates.label});
selectedSeaStateIndex = find( ...
    availableSeaStates == string(forcePlotSeaState));

assert(numel(selectedSeaStateIndex)==1, ...
    'Expected one result for %s.',forcePlotSeaState);

forcePlotResult = ...
    closedLoopResults.seaStates(selectedSeaStateIndex);

forcePlotTime = forcePlotResult.time_s(:);
forcePlotLimit = closedLoopResults.configuration.forceLimit_N;

numberOfSelectedControllers = numel(controllerNames);

figForceSaturation = figure( ...
    'Color','w', ...
    'Units','centimeters', ...
    'Position',[2 2 26 7*numberOfSelectedControllers]);

forceLayout = tiledlayout( ...
    figForceSaturation,numberOfSelectedControllers,1, ...
    'TileSpacing','compact', ...
    'Padding','compact');

forceAxes = gobjects(numberOfSelectedControllers,1);

for controllerIndex = 1:numberOfSelectedControllers

    controllerName = controllerNames{controllerIndex};
    style = controllerStyle.(controllerName);

    assert(isfield(forcePlotResult.controllers,controllerName), ...
        'Results are missing for %s.',controllerName);

    controllerData = ...
        forcePlotResult.controllers.(controllerName);

    rawCommand = controllerData.rawForce(:);
    saturatedCommand = controllerData.saturatedCommandForce(:);

    assert(numel(rawCommand)==numel(forcePlotTime) && ...
        numel(saturatedCommand)==numel(forcePlotTime), ...
        'Time and force lengths differ for %s.',controllerName);

    ax = nexttile(forceLayout);
    forceAxes(controllerIndex) = ax;
    hold(ax,'on');

    % Solid and thicker: command after saturation.
    hSaturated = plot(ax,forcePlotTime,saturatedCommand, ...
        'Color',style.colour, ...
        'LineStyle','-', ...
        'LineWidth',lineWidth);

    % Dashed: command before saturation.
    hRaw = plot(ax,forcePlotTime,rawCommand, ...
        'Color',style.colour, ...
        'LineStyle','--', ...
        'LineWidth',0.75*lineWidth);

    % Individual scales keep small controller forces visible.
    maximumForce = max(abs([rawCommand; saturatedCommand]));
    axisExtent = max(1e-3,1.15*maximumForce);

    % Show force limits when they lie within the displayed range.
    if axisExtent>=forcePlotLimit
        yline(ax, forcePlotLimit,':', ...
            'Color',[0.45 0.45 0.45], ...
            'LineWidth',limitLineWidth, ...
            'HandleVisibility','off');

        yline(ax,-forcePlotLimit,':', ...
            'Color',[0.45 0.45 0.45], ...
            'LineWidth',limitLineWidth, ...
            'HandleVisibility','off');
    end

    ylim(ax,[-axisExtent axisExtent]);
    xlim(ax,[forcePlotTime(1) forcePlotTime(end)]);

    ylabel(ax,'Force command [N]');
    title(ax,style.displayName,'Interpreter','latex');

    set(ax,'FontSize',axesFontSize);
    grid(ax,'on');
    box(ax,'on');

    if controllerIndex==1
        legend(ax,[hRaw hSaturated], ...
            {'Before saturation','After saturation'}, ...
            'Location','northoutside', ...
            'Orientation','horizontal', ...
            'FontSize',legendFontSize, ...
            'Interpreter','latex');
    end

    if controllerIndex<numberOfSelectedControllers
        ax.XTickLabel = [];
    else
        xlabel(ax,'Time [s]');
    end
end

linkaxes(forceAxes,'x');

%% ============================================================
%  PTO REPORT: ISS1--ISS3, SELECTED CONTROLLERS ONLY
% ============================================================

reportSeaStates = {'ISS1','ISS2','ISS3'};
physicalTable = closedLoopResults.physicalSummary;

selectedReportRows = ...
    ismember(string(physicalTable.SeaState), ...
        string(reportSeaStates)) & ...
    ismember(string(physicalTable.Controller), ...
        string(controllerNames));

PTOreport = physicalTable(selectedReportRows,{ ...
    'SeaState','Controller', ...
    'PeakRawForce_N', ...
    'PeakSaturatedCommandForce_N', ...
    'PeakAppliedPTOForce_N', ...
    'CommandSaturationTime_percent', ...
    'PhysicalSaturationTime_percent', ...
    'PeakVelocity_mps','PeakStroke_m', ...
    'ForceLimitOK','VelocityLimitOK', ...
    'StrokeLimitOK','AllPhysicalLimitsOK'});

% Arrange rows by sea state and the selected controller order.
reportRowOrder = [];

for ssIndex = 1:numel(reportSeaStates)
    for controllerIndex = 1:numel(controllerNames)

        rowIndex = find( ...
            string(PTOreport.SeaState) == ...
                string(reportSeaStates{ssIndex}) & ...
            string(PTOreport.Controller) == ...
                string(controllerNames{controllerIndex}));

        assert(numel(rowIndex)==1, ...
            'Expected one report row for %s / %s.', ...
            reportSeaStates{ssIndex}, ...
            controllerNames{controllerIndex});

        reportRowOrder(end+1) = rowIndex;
    end
end

PTOreport = PTOreport(reportRowOrder,:);

fprintf('\nPTO force saturation and physical limits: ISS1--ISS3\n');
disp(PTOreport);

%% Export figure and report

if ~exist('figureDirectory','var')
    figureDirectory = fullfile(pwd,'closed_loop_figures');
end

if ~exist(figureDirectory,'dir')
    mkdir(figureDirectory);
end

% Controller names in the filename prevent different selections
% from overwriting one another.
controllerSelectionTag = strjoin(string(controllerNames),'_');

forceFigureBase = fullfile(figureDirectory, ...
    ['ISS2_force_command_saturation_' ...
     char(controllerSelectionTag)]);

exportgraphics(figForceSaturation, ...
    [forceFigureBase '.pdf'], ...
    'ContentType','vector');

exportgraphics(figForceSaturation, ...
    [forceFigureBase '.png'], ...
    'Resolution',300);

writetable(PTOreport,fullfile(figureDirectory, ...
    ['ISS1_ISS3_PTO_report_' ...
     char(controllerSelectionTag) '.csv']));