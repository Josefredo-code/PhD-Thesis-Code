clear;
close all;
clc;

baseDir = pwd;
addpath(baseDir,'-begin');
clear functions;
rehash path;

%% ===============================================================
%  WEC identification, passivation and boundary-model fitting
% ================================================================

runs(1).label = 'WNSS1';
runs(1).file = '17_WNSS1_1.mat';
runs(1).inputVar = 'excitationTorque_WE';
runs(1).outputVar = 'angularVel_UM';
runs(1).timeVar = 'time';

runs(2).label = 'WNSS2';
runs(2).file = '18_WNSS2_1.mat';
runs(2).inputVar = 'excitationTorque_WE';
runs(2).outputVar = 'angularVel_UM';
runs(2).timeVar = 'time';

runs(3).label = 'WNSS3';
runs(3).file = '19_WNSS3_1.mat';
runs(3).inputVar = 'excitationTorque_WE';
runs(3).outputVar = 'angularVel_UM';
runs(3).timeVar = 'time';

resultsWEC = run_identification( ...
    runs, ...
    'BaseDir',baseDir, ...
    'ModelOrder',4, ...
    'Band',[0.5 10], ...
    'Passivate',true, ...
    'BEMFile','Wavestar_BEM_model.mat');

figures = plot_identification_results_v3( ...
    resultsWEC,baseDir);

%% ============================================================
%  PTO dynamics identification
% ============================================================

clear runsPTO;
runsPTO = struct([]);

runsPTO(1).label = 'PTO chirp 1';
runsPTO(1).file = 'IO_tests.mat';
runsPTO(1).inputVar = 'referenceForce_chirp_1';
runsPTO(1).outputVar = 'measuredForce_chirp_1';
runsPTO(1).timeVar = 'time';

runsPTO(2).label = 'PTO chirp 2';
runsPTO(2).file = 'IO_tests.mat';
runsPTO(2).inputVar = 'referenceForce_chirp_2';
runsPTO(2).outputVar = 'measuredForce_chirp_2';
runsPTO(2).timeVar = 'time';

resultsPTO = run_identification( ...
    runsPTO, ...
    'BaseDir',baseDir, ...
    'ModelOrder',4, ...
    'Band',[0.1 15], ...
    'CoherenceThreshold',0.6, ...
    'Overlap',0.5, ...
    'Passivate',false, ...
    'FitBoundaryModels',true);

figuresPTO = plot_identification_results_PTO( ...
    resultsPTO,baseDir);

% Nominal PTO model

sys_PTO_nominal = ss(resultsPTO.nominal.sys_active);

[A_PTO,B_PTO,C_PTO,D_PTO] = ssdata(sys_PTO_nominal);

% %  Save Models
% %save('identification_results.mat');

%load('identification_results.mat'); %Alternativelly, the results of this
%previous section can be upload by uncommenting this line

%% ============================================================
%  Polytopic vertices obtained directly from resultsWEC
% ============================================================

% Minimum identified model
sys_min = ss(resultsWEC.min.sys_pass);

[A_min,Be_min,Cz_min,Dze_min] = ssdata(sys_min);

% Maximum identified model
sys_max = ss(resultsWEC.max.sys_pass);

[A_max,Be_max,Cz_max,Dze_max] = ssdata(sys_max);

B_min = Be_min;
B_max = Be_max;

nz = size(Cz_min,1);
nu = size(B_min,2);

Dzu_min = zeros(nz,nu);
Dzu_max = zeros(nz,nu);

%% ============================================================
%  H2 synthesis: parameter and polynomial-degree search
% ============================================================

% Search ranges
beta2_values  = 1e-1;
H2max_values = 1e8;

degreeP_values = 0;
degreeH_values = 0;

% Fixed polynomial degrees
degrees.X = 0;
degrees.G = 0;
degrees.Z = 0;

% Total number of combinations
numberOfCases = ...
    numel(beta2_values)* ...
    numel(H2max_values)* ...
    numel(degreeP_values)* ...
    numel(degreeH_values);

fprintf('Total number of cases: %d\n',numberOfCases);

% Preallocate result structure
emptyResult = struct( ...
    'beta2',NaN, ...
    'H2max',NaN, ...
    'degreeP',NaN, ...
    'degreeH',NaN, ...
    'H2bound',NaN, ...
    'K',NaN, ...
    'normK',NaN, ...
    'successful',false, ...
    'errorMessage','');

H2results = repmat(emptyResult,numberOfCases,1);

caseIndex = 0;

% Parameter search

for betaIndex = 1:numel(beta2_values)

    beta2 = beta2_values(betaIndex);

    for boundIndex = 1:numel(H2max_values)

        H2_max = H2max_values(boundIndex);

        for degreePIndex = 1:numel(degreeP_values)

            degrees.P = degreeP_values(degreePIndex);

            for degreeHIndex = 1:numel(degreeH_values)

                degrees.H = degreeH_values(degreeHIndex);

                caseIndex = caseIndex+1;

                % Store current parameters
                H2results(caseIndex).beta2 = beta2;
                H2results(caseIndex).H2max = H2_max;
                H2results(caseIndex).degreeP = degrees.P;
                H2results(caseIndex).degreeH = degrees.H;

                fprintf( ...
                    ['Case %d/%d: beta2=%.1e, H2max=%.1e, ', ...
                     'degreeP=%d, degreeH=%d\n'], ...
                    caseIndex,numberOfCases, ...
                    beta2,H2_max,degrees.P,degrees.H);

                try

                    [currentH2bound,currentK] = ...
                        H2_Sintese_WavestarMeu( ...
                            A_min,A_max, ...
                            B_min,B_max, ...
                            Be_min,Be_max, ...
                            Cz_min,Cz_max, ...
                            Dzu_min,Dzu_max, ...
                            beta2,H2_max,degrees);

                    H2results(caseIndex).H2bound = currentH2bound;
                    H2results(caseIndex).K = currentK;

                    % Accept only finite results
                    if isfinite(currentH2bound) && ...
                            ~isempty(currentK) && ...
                            all(isfinite(currentK(:)))

                        H2results(caseIndex).normK = norm(currentK,2);
                        H2results(caseIndex).successful = true;

                    else

                        H2results(caseIndex).normK = NaN;
                        H2results(caseIndex).successful = false;
                        H2results(caseIndex).errorMessage = ...
                            'The synthesis returned NaN or a non-finite gain.';
                    end

                catch synthesisError

                    H2results(caseIndex).H2bound = NaN;
                    H2results(caseIndex).K = NaN;
                    H2results(caseIndex).normK = NaN;
                    H2results(caseIndex).successful = false;
                    H2results(caseIndex).errorMessage = ...
                        synthesisError.message;
                end
            end
        end
    end
end

% Remove failed and NaN results

validMask = ...
    [H2results.successful] & ...
    isfinite([H2results.H2bound]) & ...
    isfinite([H2results.normK]);

validH2results = H2results(validMask);

fprintf('\nValid cases: %d/%d\n', ...
    numel(validH2results),numberOfCases);

if isempty(validH2results)

    error( ...
        ['No feasible synthesis result was obtained over the ', ...
         'specified parameter ranges.']);
end

% Find the largest H2 bound

allValidBounds = [validH2results.H2bound];

[maximumH2bound,bestValidIndex] = max(allValidBounds);

bestH2result = validH2results(bestValidIndex);

% Extract the best result

beta2_best  = bestH2result.beta2;
H2max_best = bestH2result.H2max;

degreeP_best = bestH2result.degreeP;
degreeH_best = bestH2result.degreeH;

H2bound_best = bestH2result.H2bound;
KH2_best = bestH2result.K;
normKH2_best = bestH2result.normK;

% Display the best result

fprintf('\n============================================\n');
fprintf('Best H2 synthesis result\n');
fprintf('============================================\n');
fprintf('beta2:       %.6e\n',beta2_best);
fprintf('H2max:       %.6e\n',H2max_best);
fprintf('degree P:    %d\n',degreeP_best);
fprintf('degree H:    %d\n',degreeH_best);
fprintf('H2 bound:    %.6e\n',H2bound_best);
fprintf('||K_H2||_2:  %.6e\n',normKH2_best);
fprintf('K_H2:\n');
disp(KH2_best);

% Save all results
%save('Identification_and_H2_synthesis_results.mat');

%% ============================================================
%  H-infinity synthesis: parameter and polynomial-degree search
% ============================================================

% Direct feedthrough from the excitation input to the output

ne = size(Be_min,2);
n  = size(A_min,1);
nz = size(Cz_min,1);

Dze_min = zeros(nz,ne);
Dze_max = zeros(nz,ne);

% Search ranges

betaInf_values= 1e-5;
muMax_values=1e10;
degreeP_values = 3;
degreeH_values = 3;

% Fixed polynomial degrees

degrees.G = 0;
degrees.Z = 0;

% Bounds on the slack variables

Zmin = 0;
Zmax = 10000000;
Gmin = eye(n);

% Number of cases

numberOfCasesInf = ...
    numel(betaInf_values)* ...
    numel(muMax_values)* ...
    numel(degreeP_values)* ...
    numel(degreeH_values);

fprintf('\nTotal number of H-infinity cases: %d\n', ...
    numberOfCasesInf);

% Preallocate result structure

emptyResultInf = struct( ...
    'betaInf',NaN, ...
    'muMax',NaN, ...
    'degreeP',NaN, ...
    'degreeH',NaN, ...
    'gammaBound',NaN, ...
    'K',NaN, ...
    'normK',NaN, ...
    'successful',false, ...
    'errorMessage','');

HinfResults = repmat( ...
    emptyResultInf,numberOfCasesInf,1);

caseIndexInf = 0;

% Parameter search

for betaIndex = 1:numel(betaInf_values)

    betaInf = betaInf_values(betaIndex);

    for muIndex = 1:numel(muMax_values)

        mu_max = muMax_values(muIndex);

        for degreePIndex = 1:numel(degreeP_values)

            degrees.P = degreeP_values(degreePIndex);

            for degreeHIndex = 1:numel(degreeH_values)

                degrees.H = degreeH_values(degreeHIndex);

                caseIndexInf = caseIndexInf+1;

                % Store current parameters

                HinfResults(caseIndexInf).betaInf = betaInf;
                HinfResults(caseIndexInf).muMax = mu_max;
                HinfResults(caseIndexInf).degreeP = degrees.P;
                HinfResults(caseIndexInf).degreeH = degrees.H;

                fprintf( ...
                    ['Hinf case %d/%d: betaInf=%.1e, ', ...
                     'muMax=%.1e, degreeP=%d, degreeH=%d\n'], ...
                    caseIndexInf,numberOfCasesInf, ...
                    betaInf,mu_max,degrees.P,degrees.H);

                try

                    % H-infinity synthesis

                    [currentGamma,currentK] = ...
                        Hinf_Sintese_WavestarMeu( ...
                            A_min,A_max, ...
                            B_min,B_max, ...
                            Be_min,Be_max, ...
                            Cz_min,Cz_max, ...
                            Dzu_min,Dzu_max, ...
                            Dze_min,Dze_max, ...
                            betaInf,mu_max, ...
                            Zmin,Zmax,Gmin,degrees);

                    HinfResults(caseIndexInf).gammaBound = ...
                        currentGamma;

                    HinfResults(caseIndexInf).K = ...
                        currentK;

                    %% Check result

                    if isfinite(currentGamma) && ...
                            ~isempty(currentK) && ...
                            all(isfinite(currentK(:)))

                        HinfResults(caseIndexInf).normK = ...
                            norm(currentK,2);

                        HinfResults(caseIndexInf).successful = ...
                            true;

                    else

                        HinfResults(caseIndexInf).normK = NaN;

                        HinfResults(caseIndexInf).successful = ...
                            false;

                        HinfResults(caseIndexInf).errorMessage = ...
                            ['The synthesis returned NaN or a ', ...
                             'non-finite gain.'];
                    end

                catch synthesisError

                    HinfResults(caseIndexInf).gammaBound = NaN;
                    HinfResults(caseIndexInf).K = NaN;
                    HinfResults(caseIndexInf).normK = NaN;
                    HinfResults(caseIndexInf).successful = false;

                    HinfResults(caseIndexInf).errorMessage = ...
                        synthesisError.message;
                end
            end
        end
    end
end

% Remove failed and NaN results

validMaskInf = ...
    [HinfResults.successful] & ...
    isfinite([HinfResults.gammaBound]) & ...
    isfinite([HinfResults.normK]);

validHinfResults = HinfResults(validMaskInf);

fprintf('\nValid H-infinity cases: %d/%d\n', ...
    numel(validHinfResults),numberOfCasesInf);

if isempty(validHinfResults)

    error( ...
        ['No feasible H-infinity synthesis result was obtained ', ...
         'over the specified parameter ranges.']);
end

% Find the largest gamma bound

allValidGammaBounds = ...
    [validHinfResults.gammaBound];

[maximumGammaBound,bestValidIndexInf] = ...
    max(allValidGammaBounds);

bestHinfResult = ...
    validHinfResults(bestValidIndexInf);

% Extract the best result

betaInf_best = bestHinfResult.betaInf;
muMax_best = bestHinfResult.muMax;

degreePInf_best = bestHinfResult.degreeP;
degreeHInf_best = bestHinfResult.degreeH;

gammaBound_best = bestHinfResult.gammaBound;
KHinfty_best = bestHinfResult.K;
normKHinfty_best = bestHinfResult.normK;

% Display the best result

fprintf('\n============================================\n');
fprintf('Best H-infinity synthesis result\n');
fprintf('============================================\n');
fprintf('betaInf:          %.6e\n',betaInf_best);
fprintf('muMax:            %.6e\n',muMax_best);
fprintf('degree P:         %d\n',degreePInf_best);
fprintf('degree H:         %d\n',degreeHInf_best);
fprintf('gamma bound:      %.6e\n',gammaBound_best);
fprintf('||K_Hinf||_2:     %.6e\n',normKHinfty_best);
fprintf('K_Hinf:\n');

disp(KHinfty_best);

% Save all results
%save('Identification_Hinf_and_H2_synthesis_results.mat');

% %% ============================================================
% %  Midpoint system: alpha1 = alpha2 = 0.5
% % ============================================================
% 
% alpha1 = 0.5;
% alpha2 = 0.5;
% 
% A_mid = alpha1*A_min + alpha2*A_max;
% B_mid = alpha1*B_min + alpha2*B_max;
% Be_mid = alpha1*Be_min + alpha2*Be_max;
% Cz_mid = alpha1*Cz_min + alpha2*Cz_max;
% Dzu_mid = alpha1*Dzu_min + alpha2*Dzu_max;
% Dze_mid = alpha1*Dze_min + alpha2*Dze_max;

%% ============================================================
%  Nominal WEC model and irregular sea states
%
%  The nominal model is in the same state basis as the polytope.
%  The aliases A_mid, Be_mid and Cz_mid are retained because the existing
%  Simulink blocks use these variable names. They now contain the nominal
%  model, not the midpoint model.
% ============================================================

sys_nominal = ss(resultsWEC.nominal.sys_pass);
[A_nominal,Be_nominal,Cz_nominal,Dze_nominal] = ...
    ssdata(sys_nominal);

B_nominal = Be_nominal;
Dzu_nominal = zeros(size(Cz_nominal,1),size(B_nominal,2));
Dze_nominal = zeros(size(Cz_nominal,1),size(Be_nominal,2));

% Compatibility aliases required by Wavestar_simulink_controllers.
A_mid   = A_nominal;
B_mid   = B_nominal;
Be_mid  = Be_nominal;
Cz_mid  = Cz_nominal;
Dzu_mid = Dzu_nominal;
Dze_mid = Dze_nominal;

% State-space system with inputs [fe, fu]
sys_mid = ss( ...
    A_mid, ...
    [Be_mid B_mid], ...
    Cz_mid, ...
    [Dze_mid Dzu_mid]);

sys_mid.InputName = {'fe','fu'};
sys_mid.OutputName = {'z'};

% Excitation-to-output model
G_mid = ss( ...
    A_mid, ...
    Be_mid, ...
    Cz_mid, ...
    Dze_mid);


%% ============================================================
%  IM-based passive and reactive controllers for ISS1--ISS6
% ============================================================
IM_controller_gains

% % Save all results
% save('Identification_Hinf_H2_and_IMcontrollers_resultsUPDATED.mat');


%% ============================================================
%  Closed-loop simulation: all sea states and all controllers
% ============================================================
closedloopSimulationUpdated
simulate_nominal_open_loop

WEC_imersion_emergence_check_WAVE_PROBE_4AND5

plot_closed_loop_results 

EnergySummary

reactiveH2Comparison = plot_reactive_H2_comparison; %Apendix reactive case

Plots_Reactive %Comparison between simulation for H2 e experiments for Reactive

%% ============================================================
%  Closed-loop simulation: all sea states and all controllers USING BEM
%  MODEL
% ============================================================

closedloopSimulationKnownPlants
plot_BEM_known_plant_PTO_responses


