function [H2bound,K] = H2_Sintese_WavestarMeu( ...
    A_min,A_max, ...
    B_min,B_max, ...
    Be_min,Be_max, ...
    Cz_min,Cz_max, ...
    Dzu_min,Dzu_max, ...
    beta2,H2_max,degrees)
%==========================================================================
% H2_SINTESE_WAVESTAR
%
% Robust H2 state-feedback synthesis for a two-vertex polytopic system:
%
%   xdot = A(alpha)x + B(alpha)u + Be(alpha)fe
%      z = Cz(alpha)x + Dzu(alpha)u
%
% with
%
%   u = K(alpha)x.
%
% The polynomial degrees of P, X, G, Z and H are supplied through:
%
%   degrees.P
%   degrees.X
%   degrees.G
%   degrees.Z
%   degrees.H
%
% A degree equal to zero defines a constant matrix.
%
% INPUTS
%   A_min, A_max       State-matrix vertices
%   B_min, B_max       Control-input-matrix vertices
%   Be_min, Be_max     Excitation-input-matrix vertices
%   Cz_min, Cz_max     Performance-output-matrix vertices
%   Dzu_min, Dzu_max   Control feedthrough vertices
%   beta2              Prescribed LMI scalar
%   H2_max             Upper bound imposed on trace(X(alpha))
%   degrees            Structure containing the polynomial degrees
%
% OUTPUTS
%   H2bound            sqrt(rho), where rho is the maximised guaranteed
%                      lower value of trace(X(alpha))
%   K                  Constant feedback gain when degrees.G=degrees.Z=0.
%                      Empty when G or Z depends on alpha.
%
% IMPORTANT
% If G(alpha) or Z(alpha) is parameter dependent, the resulting controller
% is scheduled:
%
%   K(alpha) = Z(alpha)/G(alpha).
%==========================================================================

%% Polytopic vertices

numberOfVertices = 2;

Av = {
    A_min
    A_max
};

Bv = {
    B_min
    B_max
};

Bev = {
    Be_min
    Be_max
};

Czv = {
    Cz_min
    Cz_max
};

Dzuv = {
    Dzu_min
    Dzu_max
};

%% Dimensions

n  = size(A_min,1);
nu = size(B_min,2);
ne = size(Be_min,2);
nz = size(Cz_min,1);

%% Polynomial system matrices

A = rolmipvar( ...
    Av,'A',numberOfVertices,1);

B = rolmipvar( ...
    Bv,'B',numberOfVertices,1);

Be = rolmipvar( ...
    Bev,'Be',numberOfVertices,1);

Cz = rolmipvar( ...
    Czv,'Cz',numberOfVertices,1);

Dzu = rolmipvar( ...
    Dzuv,'Dzu',numberOfVertices,1);

%% Decision variables

P = rolmipvar( ...
    n,n,'P','sym',numberOfVertices,degrees.P);

H = rolmipvar( ...
    ne,ne,'H','full',numberOfVertices,degrees.H);

Xsdp = sdpvar(nz, nz, 'sym'); 
X = rolmipvar( ...
    Xsdp,'X',0,degrees.X);

G = rolmipvar( ...
    n,n,'G','full',0,degrees.G);

Z = rolmipvar( ...
    nu,n,'Z','full',0,degrees.Z);

%% First H2 LMI

LMIs2 = [];
LMIs2 = [LMIs2, P>=0];

T11 = -X;
T12 = Cz*G + Dzu*Z;
T22 = P - G - G';

T = [
    T11   T12
    T12'  T22
];

LMIs2 = [LMIs2, [T11  T12; 
               T12' T22] <= 0];
%% Second H2 LMI

M11=A*G+G'*A'+B*Z + Z'*B';
M12=P-G'+beta2*(A*G+B*Z);
M13=Be*H;
M22=beta2*(-G-G');
M23=zeros(n,ne);
M33=eye(ne)-H-H';

LMIs2=[LMIs2, [ M11  M12  M13;
                M12' M22  M23;
                M13' M23' M33 ] <= 0];


%% Optimisation
LMIs2 = [LMIs2, 0 <= trace(Xsdp) <= H2_max];
out=solvesdp(LMIs2, -trace(Xsdp));
%solvesdp(LMIs2, trace(Xsdp)); %to minimise

% Checagem e extração de K
[primal,~] = checkset(LMIs2);
    if min(round(primal*1e8)) >= 0
    Gv = double(G);
    Zv = double(Z);
    K  = Zv / Gv;                           % K = Z*G^{-1}
    else
    disp('infactivel');
    K = NaN;
    end
% --------- Norma H2 (coerente com o objetivo tr(X)) ---------
H2bound = sqrt(trace(double(Xsdp)));

end

