%% ============================================================
%  Closed-loop evaluation of the four controllers
%
%  Requirements already available from the main routine:
%    IMresults, KH2_best, KHinfty_best,
%    A_nominal, Be_nominal, Cz_nominal,
%    A_PTO, B_PTO, C_PTO, D_PTO.
%
%  Robust gain blocks in Simulink implement tau_u = -K*x.
%  Both PTO-force saturation levels are set to +/-200 N.
% ============================================================
modelName = 'Wavestar_simulink_controllers';

% Choose 3 to simulate ISS1--ISS3 or 6 to simulate ISS1--ISS6.
lastSeaState = 3;%6;
assert(ismember(lastSeaState,[3 6]), ...
    'lastSeaState must be either 3 or 6.');
seaStateIndices = 1:lastSeaState;
numberSeaStates = numel(seaStateIndices);
seaStateSetLabel = sprintf('ISS1_ISS%d',lastSeaState);

forceLimit = 200;
velocityLimit = 3.5;
strokeLimit = 0.14;
PTO_force_min = -forceLimit;
PTO_force_max = forceLimit;
controllerNames = {'Passive','Reactive','H2','Hinf'};
controllerSuffixes = {'p','pi','H2','Hinf'};
assert(numel(IMresults)>=lastSeaState, ...
    'IMresults must contain ISS1--ISS%d.',lastSeaState);
requiredVariables = { ...
    'KH2_best','KHinfty_best', ...
    'A_nominal','Be_nominal','Cz_nominal', ...
    'A_PTO','B_PTO','C_PTO','D_PTO'};
for variableIndex = 1:numel(requiredVariables)
    assert(exist(requiredVariables{variableIndex},'var')==1, ...
        'Required variable %s is not available.', ...
        requiredVariables{variableIndex});
end
if ~exist('baseDir','var') || isempty(baseDir)
    baseDir = pwd;
end
resultsFile = fullfile( ...
    baseDir,['closed_loop_optimal_nominal_saturated_' ...
    seaStateSetLabel '.mat']);
energyCSV = fullfile( ...
    baseDir,['closed_loop_energy_summary_' seaStateSetLabel '.csv']);
physicalCSV = fullfile( ...
    baseDir,['closed_loop_physical_summary_' seaStateSetLabel '.csv']);
%% ============================================================
%  Nominal model aliases used by the existing Simulink diagram
% ============================================================
A_mid = A_nominal;
B_mid = Be_nominal;
Be_mid = Be_nominal;
Cz_mid = Cz_nominal;
Dzu_mid = zeros(size(Cz_nominal,1),size(Be_nominal,2));
Dze_mid = zeros(size(Cz_nominal,1),size(Be_nominal,2));
x0_WEC = zeros(size(A_nominal,1),1);
x0_PTO = zeros(size(A_PTO,1),1);
assert(all(isfinite(KH2_best(:))), ...
    'KH2_best contains NaN or Inf.');
assert(all(isfinite(KHinfty_best(:))), ...
    'KHinfty_best contains NaN or Inf.');
%% ============================================================
%  Optional incident-wave energy from the main routine
% ============================================================
incidentWaveEnergy = nan(lastSeaState,1);
if exist('waveEnergyTable','var')==1 && ...
        istable(waveEnergyTable) && ...
        any(strcmp(waveEnergyTable.Properties.VariableNames,'WaveEnergy_J'))
    numberAvailable = min(lastSeaState,height(waveEnergyTable));
    incidentWaveEnergy(1:numberAvailable) = ...
        waveEnergyTable.WaveEnergy_J(1:numberAvailable);
end
%% ============================================================
%  Output definitions
% ============================================================
requiredSignals = {
    'angularVelocity',   'angularVelocity'
    'angularPosition',   'angularPosition'
    'rawForce',          'fu'
    'unsaturatedPTOForce','fu_PTO'
    'referenceTorque',   'TauU'
    'appliedPTOTorque',  'TauU_PTO'
    'PTOvelocity',       'vPTO'
    'PTOdisplacement',   'zPTO'
    'kinematicJacobian', 'KinematicJacobian'
    'PTOpower',          'PTOpower'
};
optionalSignals = {
    'saturatedCommandForce','fu_sat'
    'appliedPTOForce',      'fu_PTO_sat'
};
%% ============================================================
%  Result structures
% ============================================================
closedLoopResults = struct();
closedLoopResults.description = ...
    ['Nominal closed-loop simulations with passive, reactive, H2 and ' ...
     'Hinf controllers, including +/-200 N PTO-force saturation.'];
closedLoopResults.creationDate = ...
    char(datetime('now','Format','yyyy-MM-dd HH:mm:ss'));
closedLoopResults.modelName = modelName;
closedLoopResults.configuration.model = 'Nominal WEC model';
closedLoopResults.configuration.forceLimit_N = forceLimit;
closedLoopResults.configuration.velocityLimit_mps = velocityLimit;
closedLoopResults.configuration.strokeLimit_m = strokeLimit;
closedLoopResults.configuration.KH2 = KH2_best;
closedLoopResults.configuration.KHinf = KHinfty_best;
closedLoopResults.configuration.robustControlLaw = 'tau_u = -K*x';
closedLoopResults.configuration.reactiveIntegralGain = ...
    'K_i = IMresults.K_i';
closedLoopResults.configuration.seaStateIndices = seaStateIndices;
closedLoopResults.seaStates = struct([]);
energyRows = struct([]);
physicalRows = struct([]);
energyRowIndex = 0;
physicalRowIndex = 0;
%% ============================================================
%  Run the selected sea states sequentially
% ============================================================
load_system(modelName);
Simulink.sdi.clear;
Simulink.sdi.setRecordData(true);
fprintf('\n============================================================\n');
fprintf('OPTIMAL CLOSED-LOOP EVALUATION: ISS1--ISS%d\n', ...
    lastSeaState);
fprintf('Nominal WEC model and +/-%.1f N force saturation\n',forceLimit);
fprintf('============================================================\n');
for simulationIndex = 1:numberSeaStates
    seaStateIndex = seaStateIndices(simulationIndex);
    selectedISS = IMresults(seaStateIndex);
    input_torque = selectedISS.f_e_timeseries;
    t_end = selectedISS.t(end);
    dt = selectedISS.dt;
    K_p = selectedISS.K_p;
    K_r = selectedISS.K_r;
    K_i = selectedISS.K_i;
    assert(isa(input_torque,'timeseries'), ...
        'Excitation input is not a timeseries for %s.', ...
        selectedISS.label);
    assert(all(isfinite(input_torque.Time(:))) && ...
        all(isfinite(input_torque.Data(:))), ...
        'Invalid excitation input for %s.',selectedISS.label);
    fprintf('\nSimulation %d/%d: %s\n', ...
        simulationIndex,numberSeaStates,selectedISS.label);
    fprintf('Kp = %.6f, Kr = %.6f, Ki = %.6f\n',K_p,K_r,K_i);
    simulationInput = Simulink.SimulationInput(modelName);
    simulationInput = simulationInput.setVariable('A_mid',A_nominal);
    simulationInput = simulationInput.setVariable('B_mid',Be_nominal);
    simulationInput = simulationInput.setVariable('Be_mid',Be_nominal);
    simulationInput = simulationInput.setVariable('B_min',Be_nominal);
    simulationInput = simulationInput.setVariable('Be_min',Be_nominal);
    simulationInput = simulationInput.setVariable('Cz_mid',Cz_nominal);
    simulationInput = simulationInput.setVariable('Dzu_mid',Dzu_mid);
    simulationInput = simulationInput.setVariable('Dze_mid',Dze_mid);
    simulationInput = simulationInput.setVariable('A_PTO',A_PTO);
    simulationInput = simulationInput.setVariable('B_PTO',B_PTO);
    simulationInput = simulationInput.setVariable('C_PTO',C_PTO);
    simulationInput = simulationInput.setVariable('D_PTO',D_PTO);
    simulationInput = simulationInput.setVariable('x0_WEC',x0_WEC);
    simulationInput = simulationInput.setVariable('x0_PTO',x0_PTO);
    simulationInput = simulationInput.setVariable('input_torque',input_torque);
    simulationInput = simulationInput.setVariable('dt',dt);
    simulationInput = simulationInput.setVariable('K_p',K_p);
    simulationInput = simulationInput.setVariable('K_r',K_r);
    simulationInput = simulationInput.setVariable('K_i',K_i);
    simulationInput = simulationInput.setVariable('KH2_best',KH2_best);
    simulationInput = simulationInput.setVariable( ...
        'KHinfty_best',KHinfty_best);
    simulationInput = simulationInput.setVariable( ...
        'PTO_force_min',PTO_force_min);
    simulationInput = simulationInput.setVariable( ...
        'PTO_force_max',PTO_force_max);
    simulationInput = simulationInput.setModelParameter( ...
        'StartTime','0', ...
        'StopTime',num2str(t_end,'%.15g'), ...
        'ReturnWorkspaceOutputs','on');
    simulationOutput = sim(simulationInput);
    time = simulationOutput.tout(:);
    availableOutputs = simulationOutput.who;
    caseResult = struct();
    caseResult.label = selectedISS.label;
    caseResult.source = selectedISS.source;
    caseResult.time_s = time;
    caseResult.duration_s = time(end)-time(1);
    caseResult.dt_s = dt;
    caseResult.Tp_s = selectedISS.Tp;
    caseResult.incidentWaveEnergy_J = ...
        incidentWaveEnergy(seaStateIndex);
    caseResult.excitationTorque_Nm = interp1( ...
        input_torque.Time(:),input_torque.Data(:),time, ...
        'linear','extrap');
    caseResult.gains.passive.Kp = K_p;
    caseResult.gains.reactive.Kr = K_r;
    caseResult.gains.reactive.Ki = K_i;
    caseResult.gains.H2 = KH2_best;
    caseResult.gains.Hinf = KHinfty_best;
    for controllerIndex = 1:numel(controllerNames)
        controllerName = controllerNames{controllerIndex};
        suffix = controllerSuffixes{controllerIndex};
        controllerResult = struct();
        for signalIndex = 1:size(requiredSignals,1)
            storedName = requiredSignals{signalIndex,1};
            outputName = [requiredSignals{signalIndex,2} '_' suffix];
            assert(any(strcmp(availableOutputs,outputName)), ...
                'Required output %s was not returned.',outputName);
            controllerResult.(storedName) = ...
                localConvertSignalToColumn( ...
                simulationOutput.(outputName));
        end
        for signalIndex = 1:size(optionalSignals,1)
            storedName = optionalSignals{signalIndex,1};
            outputName = [optionalSignals{signalIndex,2} '_' suffix];
            if any(strcmp(availableOutputs,outputName))
                controllerResult.(storedName) = ...
                    localConvertSignalToColumn( ...
                    simulationOutput.(outputName));
            end
        end
        if ~isfield(controllerResult,'saturatedCommandForce')
            controllerResult.saturatedCommandForce = ...
                min(max(controllerResult.rawForce, ...
                PTO_force_min),PTO_force_max);
        end
        if ~isfield(controllerResult,'appliedPTOForce')
            controllerResult.appliedPTOForce = ...
                min(max(controllerResult.unsaturatedPTOForce, ...
                PTO_force_min),PTO_force_max);
        end
        controllerFields = fieldnames(controllerResult);
        for fieldIndex = 1:numel(controllerFields)
            currentSignal = ...
                controllerResult.(controllerFields{fieldIndex});
            assert(numel(currentSignal)==numel(time), ...
                'Unexpected length for %s, %s, %s.', ...
                controllerFields{fieldIndex}, ...
                controllerName,selectedISS.label);
            assert(all(isfinite(currentSignal)), ...
                'NaN or Inf in %s, %s, %s.', ...
                controllerFields{fieldIndex}, ...
                controllerName,selectedISS.label);
        end
        % controllerResult.relativePTOdisplacement = ...
        %     controllerResult.PTOdisplacement ...
        %     -controllerResult.PTOdisplacement(1);
        % PTO position at the nominal equilibrium configuration.
% Since the simulation starts from the nominal equilibrium,
% the first sample represents z_PTO(theta_A^0).
zPTO_equilibrium = controllerResult.PTOdisplacement(1);

% PTO displacement relative to the nominal equilibrium position.
controllerResult.relativePTOdisplacement = ...
    controllerResult.PTOdisplacement - zPTO_equilibrium;

controllerResult.PTOequilibriumPosition = ...
    zPTO_equilibrium;
        controllerResult.powerFromForce = ...
            controllerResult.appliedPTOForce ...
            .*controllerResult.PTOvelocity;
        controllerResult.powerFromTorque = ...
            controllerResult.appliedPTOTorque ...
            .*controllerResult.angularVelocity;
        controllerResult.accumulatedEnergy = ...
            cumtrapz(time,controllerResult.PTOpower);
        controllerResult.commandForceClipping = ...
            controllerResult.rawForce ...
            -controllerResult.saturatedCommandForce;
        controllerResult.physicalForceClipping = ...
            controllerResult.unsaturatedPTOForce ...
            -controllerResult.appliedPTOForce;
        power = controllerResult.PTOpower;
        positivePower = max(power,0);
        returnedPower = max(-power,0);
        commandSaturationMask = ...
            abs(controllerResult.commandForceClipping)>1e-9;
        physicalSaturationMask = ...
            abs(controllerResult.physicalForceClipping)>1e-9;
        metrics = struct();
        metrics.netEnergy_J = trapz(time,power);
        metrics.positiveEnergy_J = trapz(time,positivePower);
        metrics.returnedEnergy_J = trapz(time,returnedPower);
        metrics.averagePower_W = ...
            metrics.netEnergy_J/(time(end)-time(1));
        metrics.RMSPower_W = sqrt( ...
            trapz(time,power.^2)/(time(end)-time(1)));
        metrics.peakPositivePower_W = max(power);
        metrics.peakNegativePower_W = min(power);
        metrics.negativePowerTime_percent = 100*mean(power<0);
        metrics.peakRawForce_N = ...
            max(abs(controllerResult.rawForce));
        metrics.peakSaturatedCommandForce_N = ...
            max(abs(controllerResult.saturatedCommandForce));
        metrics.peakUnsaturatedPTOForce_N = ...
            max(abs(controllerResult.unsaturatedPTOForce));
        metrics.peakAppliedPTOForce_N = ...
            max(abs(controllerResult.appliedPTOForce));
        metrics.commandSaturationTime_percent = ...
            100*mean(commandSaturationMask);
        metrics.physicalSaturationTime_percent = ...
            100*mean(physicalSaturationMask);
        metrics.maximumCommandClipping_N = ...
            max(abs(controllerResult.commandForceClipping));
        metrics.maximumPhysicalClipping_N = ...
            max(abs(controllerResult.physicalForceClipping));
        metrics.peakPTOvelocity_mps = ...
            max(abs(controllerResult.PTOvelocity));
        metrics.peakRelativeStroke_m = ...
            max(abs(controllerResult.relativePTOdisplacement));
        metrics.peakAngularVelocity_radps = ...
            max(abs(controllerResult.angularVelocity));
        metrics.peakAngularPosition_rad = ...
            max(abs(controllerResult.angularPosition));
        metrics.minimumAbsoluteJacobian_mPerRad = ...
            min(abs(controllerResult.kinematicJacobian));
        metrics.forceLimitSatisfied = ...
            metrics.peakAppliedPTOForce_N<=forceLimit*(1+1e-9);
        metrics.velocityLimitSatisfied = ...
            metrics.peakPTOvelocity_mps<=velocityLimit;
        metrics.strokeLimitSatisfied = ...
            metrics.peakRelativeStroke_m<=strokeLimit;
        metrics.allPhysicalLimitsSatisfied = ...
            metrics.forceLimitSatisfied && ...
            metrics.velocityLimitSatisfied && ...
            metrics.strokeLimitSatisfied;
        metrics.powerIdentityError_W = max(abs( ...
            controllerResult.powerFromForce ...
            -controllerResult.powerFromTorque));
        metrics.loggedPowerError_W = max(abs( ...
            controllerResult.PTOpower ...
            -controllerResult.powerFromForce));
        if isfinite(caseResult.incidentWaveEnergy_J) && ...
                caseResult.incidentWaveEnergy_J>0
            metrics.waveEnergyUtilisation_percent = ...
                100*metrics.netEnergy_J ...
                /caseResult.incidentWaveEnergy_J;
        else
            metrics.waveEnergyUtilisation_percent = NaN;
        end
        controllerResult.metrics = metrics;
        caseResult.controllers.(controllerName) = controllerResult;
        energyRowIndex = energyRowIndex+1;
        energyRows(energyRowIndex).SeaState = ...
            string(selectedISS.label);
        energyRows(energyRowIndex).Controller = ...
            string(controllerName);
        energyRows(energyRowIndex).IncidentWaveEnergy_J = ...
            caseResult.incidentWaveEnergy_J;
        energyRows(energyRowIndex).NetEnergy_J = ...
            metrics.netEnergy_J;
        energyRows(energyRowIndex).PositiveEnergy_J = ...
            metrics.positiveEnergy_J;
        energyRows(energyRowIndex).ReturnedEnergy_J = ...
            metrics.returnedEnergy_J;
        energyRows(energyRowIndex).AveragePower_W = ...
            metrics.averagePower_W;
        energyRows(energyRowIndex).RMSPower_W = ...
            metrics.RMSPower_W;
        energyRows(energyRowIndex).PeakPositivePower_W = ...
            metrics.peakPositivePower_W;
        energyRows(energyRowIndex).PeakNegativePower_W = ...
            metrics.peakNegativePower_W;
        energyRows(energyRowIndex).NegativePowerTime_percent = ...
            metrics.negativePowerTime_percent;
        energyRows(energyRowIndex).WaveEnergyUtilisation_percent = ...
            metrics.waveEnergyUtilisation_percent;
        physicalRowIndex = physicalRowIndex+1;
        physicalRows(physicalRowIndex).SeaState = ...
            string(selectedISS.label);
        physicalRows(physicalRowIndex).Controller = ...
            string(controllerName);
        physicalRows(physicalRowIndex).PeakRawForce_N = ...
            metrics.peakRawForce_N;
        physicalRows(physicalRowIndex).PeakSaturatedCommandForce_N = ...
            metrics.peakSaturatedCommandForce_N;
        physicalRows(physicalRowIndex).PeakUnsaturatedPTOForce_N = ...
            metrics.peakUnsaturatedPTOForce_N;
        physicalRows(physicalRowIndex).PeakAppliedPTOForce_N = ...
            metrics.peakAppliedPTOForce_N;
        physicalRows(physicalRowIndex).CommandSaturationTime_percent = ...
            metrics.commandSaturationTime_percent;
        physicalRows(physicalRowIndex).PhysicalSaturationTime_percent = ...
            metrics.physicalSaturationTime_percent;
        physicalRows(physicalRowIndex).MaximumCommandClipping_N = ...
            metrics.maximumCommandClipping_N;
        physicalRows(physicalRowIndex).MaximumPhysicalClipping_N = ...
            metrics.maximumPhysicalClipping_N;
        physicalRows(physicalRowIndex).PeakVelocity_mps = ...
            metrics.peakPTOvelocity_mps;
        physicalRows(physicalRowIndex).PeakStroke_m = ...
            metrics.peakRelativeStroke_m;
        physicalRows(physicalRowIndex).PeakAngularVelocity_radps = ...
            metrics.peakAngularVelocity_radps;
        physicalRows(physicalRowIndex).MinimumAbsJacobian_mPerRad = ...
            metrics.minimumAbsoluteJacobian_mPerRad;
        physicalRows(physicalRowIndex).ForceLimitOK = ...
            metrics.forceLimitSatisfied;
        physicalRows(physicalRowIndex).VelocityLimitOK = ...
            metrics.velocityLimitSatisfied;
        physicalRows(physicalRowIndex).StrokeLimitOK = ...
            metrics.strokeLimitSatisfied;
        physicalRows(physicalRowIndex).AllPhysicalLimitsOK = ...
            metrics.allPhysicalLimitsSatisfied;
    end
    % The first result initialises the structure fields. Assigning a
    % populated structure directly into struct([]) causes MATLAB's
    % "Subscripted assignment between dissimilar structures" error.
    if simulationIndex==1
        closedLoopResults.seaStates = caseResult;
    else
        closedLoopResults.seaStates(simulationIndex,1) = caseResult;
    end
    closedLoopResults.completedSeaStates = ...
        seaStateIndices(1:simulationIndex);
    save(resultsFile,'closedLoopResults','-v7.3');
    fprintf('Completed and saved %s.\n',selectedISS.label);
    for controllerIndex = 1:numel(controllerNames)
        controllerName = controllerNames{controllerIndex};
        m = caseResult.controllers.(controllerName).metrics;
        fprintf(['%-8s: E=% .4e J, F=%.2f N, ' ...
            'v=%.3f m/s, stroke=%.4f m, limits=%d\n'], ...
            controllerName,m.netEnergy_J, ...
            m.peakAppliedPTOForce_N,m.peakPTOvelocity_mps, ...
            m.peakRelativeStroke_m,m.allPhysicalLimitsSatisfied);
    end
    Simulink.sdi.clear;
end
%% ============================================================
%  Final tables and file
% ============================================================
energySummary = struct2table(energyRows);
physicalSummary = struct2table(physicalRows);
closedLoopResults.energySummary = energySummary;
closedLoopResults.physicalSummary = physicalSummary;
closedLoopResults.completed = true;
closedLoopResults.completionDate = ...
    char(datetime('now','Format','yyyy-MM-dd HH:mm:ss'));
save(resultsFile,'closedLoopResults', ...
    'energySummary','physicalSummary','-v7.3');
writetable(energySummary,energyCSV);
writetable(physicalSummary,physicalCSV);
fprintf('\n============================================================\n');
fprintf('ENERGY SUMMARY\n');
fprintf('============================================================\n');
disp(energySummary);
fprintf('\n============================================================\n');
fprintf('PTO AND PHYSICAL-LIMIT SUMMARY\n');
fprintf('============================================================\n');
disp(physicalSummary);
fprintf('\nResults saved to:\n%s\n',resultsFile);
%% ============================================================
%  Local function
% ============================================================
function signalColumn = localConvertSignalToColumn(signalValue)
if isa(signalValue,'timeseries')
    signalColumn = signalValue.Data(:);
elseif isa(signalValue,'timetable')
    signalColumn = signalValue.Variables(:);
elseif isnumeric(signalValue) || islogical(signalValue)
    signalColumn = signalValue(:);
else
    error('Unsupported Simulink output class: %s.',class(signalValue));
end
end
