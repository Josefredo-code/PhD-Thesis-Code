function [gamma,K] = Hinf_Sintese_WavestarMeu( ...
    A_min,A_max, ...
    B_min,B_max, ...
    Be_min,Be_max, ...
    Cz_min,Cz_max, ...
    Dzu_min,Dzu_max, ...
    Dze_min,Dze_max, ...
    betaInf,mu_max,Zmin,Zmax,Gmin,degrees)
%==========================================================================
% HINF_SINTESE_WAVESTARMEU
%
% Robust H-infinity state-feedback synthesis for a two-vertex polytopic
% system:
%
%   xdot = A(alpha)x + B(alpha)u + Be(alpha)fe
%      z = Cz(alpha)x + Dzu(alpha)u + Dze(alpha)fe
%
% with
%
%   u = Kx.
%
% The polynomial degrees of P, G, Z and H are supplied through:
%
%   degrees.P
%   degrees.G
%   degrees.Z
%   degrees.H
%
% A degree equal to zero defines a constant matrix.
%
% OUTPUTS
%   gamma    H-infinity guaranteed cost
%   K        State-feedback gain
%==========================================================================

%% Polytopic vertices

numberOfVertices = 2;

Av = {
    A_min
    A_max
};

Bv = {
    B_min
    B_max
};

Bev = {
    Be_min
    Be_max
};

Czv = {
    Cz_min
    Cz_max
};

Dzuv = {
    Dzu_min
    Dzu_max
};

Dzev = {
    Dze_min
    Dze_max
};

%% Dimensions

n  = size(A_min,1);
nu = size(B_min,2);
ne = size(Be_min,2);
nz = size(Cz_min,1);

%% Polynomial system matrices

A = rolmipvar( ...
    Av,'A',numberOfVertices,1);

B = rolmipvar( ...
    Bv,'B',numberOfVertices,1);

Be = rolmipvar( ...
    Bev,'Be',numberOfVertices,1);

Cz = rolmipvar( ...
    Czv,'Cz',numberOfVertices,1);

Dzu = rolmipvar( ...
    Dzuv,'Dzu',numberOfVertices,1);

Dze = rolmipvar( ...
    Dzev,'Dze',numberOfVertices,1);

%% Decision variables

P = rolmipvar( ...
    n,n,'P','sym',numberOfVertices,degrees.P);

H = rolmipvar( ...
    ne,ne,'H','full',numberOfVertices,degrees.H);

G = rolmipvar( ...
    n,n,'G','sym',0,degrees.G);

Zsdp = sdpvar(nu,n,'full');

Z = rolmipvar( ...
    Zsdp,'Z',0,degrees.Z);

mu = sdpvar(1,1);

%% H-infinity LMI

LMIsInf=[];%initialising

Q11=A*G+G'*A'+B*Z+Z'*B';
Q12=P- G'+betaInf*(A*G+B*Z);
Q13=G'*Cz'+Z'*Dzu';
Q14=-Be*H;
Q22=-betaInf*(G+G');
Q23=betaInf*(G'*Cz'+Z'*Dzu');
Q24=zeros(n,ne);
Q33=-mu*eye(nz);
Q34=-Dze*H;
Q44=eye(ne)+H+H';

Q=[[Q11 Q12 Q13 Q14];[Q12' Q22 Q23 Q24];[Q13' Q23' Q33 Q34];[Q14' Q24' Q34' Q44]];

%% Bounds on Z
%Bounds of Slack variable 0<=Z_ij<=3 (control variable Xc3)
for i = 1:nu
    for j = 1:n
        LMIsInf = [
            LMIsInf
            Zsdp(i,j) >= Zmin
            Zsdp(i,j) <= Zmax
        ];
    end
end


%% LMI conditions
LMIsInf=[LMIsInf,P>=0,Q<=0,G>=Gmin]; %conditions for LMIs Lemma 2, and bound for slack variable 0=<G
LMIsInf= [LMIsInf, 0 <= mu <= mu_max];
%LMIs=[LMIs,Pi>=0,Q<=0]; %conditions for LMIs Lemma 2, and bound for slack variable 0=<G

%% Optimisation

out = solvesdp(LMIsInf,-mu);
% solvesdp(LMIsInf,mu); % To minimise

%% Feasibility check and gain recovery
[primal,~]=checkset(LMIsInf);
if(min(round(primal*10^8))>=0)
Gv = double(G);
Zv = double(Zsdp);

K = Zv*inv(Gv);
else
disp('infactivel'); %no convergence of otimisation problem
K=NaN;
end

%% H-infinity guaranteed cost

gamma = sqrt(double(mu));

end