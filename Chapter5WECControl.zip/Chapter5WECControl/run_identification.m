function results = run_identification(runs,varargin)
%RUN_IDENTIFICATION Generic common-basis frequency-domain identification.
%
%   RESULTS = RUN_IDENTIFICATION(RUNS) identifies one common-basis model for
%   each experimental run described by the structure array RUNS.
%
%   RESULTS = RUN_IDENTIFICATION(...,'Passivate',true) applies the D = 0
%   passivation procedure to the individual, nominal and boundary models.
%
%   Required fields for each element of RUNS:
%       label       descriptive and unique run label
%       inputVar    input-variable name in the MAT file
%       outputVar   output-variable name in the MAT file
%
%   For signals stored in the same MAT file, also provide:
%       file        MAT-file name or path
%       timeVar     time-variable name
%
%   For signals stored in different MAT files, provide instead:
%       inputFile, outputFile
%       inputTimeVar, outputTimeVar
%
%   The same file may be repeated in RUNS with different variable names. This
%   supports, for example, several chirp experiments stored in IO_tests.mat.
%
%   Required external routines:
%       select_passivation_weights_D0.m          (when Passivate = true)
%       fit_passive_output_matrix_D0.m           (when Passivate = true)
%
%   Examples
%   --------
%   % Two PTO chirps stored in the same file:
%   runs(1) = struct('label','PTO chirp 1','file','IO_tests.mat', ...
%       'inputVar','referenceForce_chirp_1', ...
%       'outputVar','measuredForce_chirp_1','timeVar','time');
%   runs(2) = struct('label','PTO chirp 2','file','IO_tests.mat', ...
%       'inputVar','referenceForce_chirp_2', ...
%       'outputVar','measuredForce_chirp_2','timeVar','time');
%   results = run_identification(runs,'ModelOrder',3,'Passivate',false);

    parser = inputParser;
    parser.FunctionName = 'run_identification';

    parser.addRequired('runs',@(x) isstruct(x) && ~isempty(x));
    parser.addParameter('BaseDir',pwd,@is_text_scalar);
    parser.addParameter('Fs',[], ...
        @(x) isempty(x) || (isnumeric(x) && isscalar(x) && x>0));
    parser.addParameter('Band',[0.5 10],@is_valid_band);
    parser.addParameter('CoherenceThreshold',0.6, ...
        @(x) isnumeric(x) && isscalar(x) && x>=0 && x<=1);
    parser.addParameter('SegmentLength',[], ...
        @(x) isempty(x) || (isnumeric(x) && isscalar(x) && x>=2));
    parser.addParameter('Overlap',0.5, ...
        @(x) isnumeric(x) && isscalar(x) && x>=0 && x<1);
    parser.addParameter('NFFT',[], ...
        @(x) isempty(x) || (isnumeric(x) && isscalar(x) && x>=2));
    parser.addParameter('ModelOrder',4, ...
        @(x) isnumeric(x) && isscalar(x) && x>=1 && mod(x,1)==0);
    parser.addParameter('Passivate',true,@is_logical_scalar);
    parser.addParameter('FitBoundaryModels',true,@is_logical_scalar);
    parser.addParameter('BEMFile','',@is_text_scalar);
    parser.addParameter('Verbose',true,@is_logical_scalar);
    parser.parse(runs,varargin{:});
    options = parser.Results;

    baseDir = char(options.BaseDir);
    if ~isfolder(baseDir)
        error('run_identification:InvalidBaseDir', ...
            'BaseDir does not exist: %s',baseDir);
    end

    addpath(baseDir,'-begin');

    runDefinitions = normalise_run_definitions(runs,baseDir);
    nRuns = numel(runDefinitions);
    if nRuns<2
        error('run_identification:TooFewRuns', ...
            'At least two experimental runs are required.');
    end

    labels = {runDefinitions.label}.';

    print_header(options.Passivate,nRuns);

    %% Experimental H1 frequency-response estimates
    out = estimate_experimental_frfs(runDefinitions,options);
    w = out.nominal.w(:);
    nFrequencies = numel(w);
    Gexperimental = out.nominal.Gmatrix;
    GnominalExperimental = out.nominal.G;

    %% Stable reference dynamics and common-basis output matrices
    fprintf('\n[1] Fitting common reference dynamics...\n');
    referenceModel = fit_reference_model( ...
        GnominalExperimental,w,options.ModelOrder);
    [A,B,~,~] = ssdata(referenceModel);
    D = 0;
    nStates = size(A,1);

    if any(real(eig(A))>=0)
        error('run_identification:UnstableReference', ...
            'The common reference dynamics are not asymptotically stable.');
    end
    if rank(ctrb(A,B))<nStates
        error('run_identification:UncontrollableReference', ...
            'The common pair (A,B) is not controllable.');
    end

    fprintf('[2] Estimating common-basis output matrices...\n');
    Phi = frequency_regression_matrix(A,B,w);
    Craw = zeros(nRuns,nStates);
    rawModels = cell(nRuns,1);
    rawResponses = zeros(nFrequencies,nRuns);
    fitNRMSE = zeros(nRuns,1);

    for i = 1:nRuns
        Craw(i,:) = fit_output_matrix(Phi,Gexperimental(:,i));
        rawModels{i} = ss(A,B,Craw(i,:),D);
        assert_minimal(rawModels{i},labels{i});
        rawResponses(:,i) = squeeze(freqresp(rawModels{i},w));
        fitNRMSE(i) = complex_nrmse( ...
            Gexperimental(:,i),rawResponses(:,i));
        if options.Verbose
            fprintf('   %s: complex NRMSE = %.6f\n', ...
                labels{i},fitNRMSE(i));
        end
    end

    CnominalRaw = mean(Craw,1);
    nominalRaw = ss(A,B,CnominalRaw,D);
    assert_minimal(nominalRaw,'Nominal');

    %% Optional passivation
    Cactive = Craw;
    activeModels = rawModels;
    nominalActive = nominalRaw;
    passivationInfo = cell(nRuns,1);
    certificates = cell(nRuns,1);
    nominalCertificate = [];
    selectedWeights = [];

    if options.Passivate
        fprintf('[3] Selecting passivation weights and passivating models...\n');
        candidateWGammas = unique([0:0.005:0.05,0.10:0.05:0.80]).';
        selectedWeights = select_passivation_weights_D0( ...
            A,B,Craw,w,candidateWGammas);
        Cactive = selectedWeights.Cpass;
        activeModels = selectedWeights.models;
        passivationInfo = selectedWeights.passivationInfo;

        % Reuse the certificates obtained during the weight-selection
        % stage. Re-solving the same KYP feasibility problem here can give
        % an inconsistent result when SeDuMi returns a numerical warning.
        certificates = selectedWeights.certificates;

        for i = 1:nRuns
            assert_minimal(activeModels{i},labels{i});
            if isempty(certificates{i}) || ...
                    ~isfield(certificates{i},'certified') || ...
                    ~certificates{i}.certified
                error('run_identification:PassivityFailure', ...
                    ['The model %s was not certified as passive during ', ...
                     'the passivation-weight selection.'],labels{i});
            end
        end

        CnominalActive = mean(Cactive,1);
        nominalActive = ss(A,B,CnominalActive,D);
        assert_minimal(nominalActive,'Nominal');
        % The nominal transfer function is the convex average of the
        % passive vertex transfer functions. Since A and B are common, the
        % average of the vertex storage matrices is a KYP certificate for
        % the averaged output matrix.
        Pnominal = zeros(size(A));
        for i = 1:nRuns
            if ~isfield(certificates{i},'P') || isempty(certificates{i}.P)
                error('run_identification:MissingCertificate', ...
                    'The passivity certificate of model %s is unavailable.', ...
                    labels{i});
            end
            Pnominal = Pnominal + certificates{i}.P/nRuns;
        end

        nominalCertificate = verify_passivity_certificate_D0( ...
            A,B,CnominalActive,Pnominal,1e-7, ...
            'Constructed from the convex average of vertex certificates');
        if ~nominalCertificate.certified
            error('run_identification:NominalPassivityFailure', ...
                'The nominal model was not certified as passive.');
        end
    else
        fprintf('[3] Passivation disabled; retaining raw identified models.\n');
    end

    %% Responses of the selected models
    Gactive = zeros(nFrequencies,nRuns);
    for i = 1:nRuns
        Gactive(:,i) = squeeze(freqresp(activeModels{i},w));
    end

    %% Store the principal models before fitting the boundaries
    results.options = options;
    results.runs = runDefinitions;
    results.files.input = {runDefinitions.inputFile}.';
    results.files.output = {runDefinitions.outputFile}.';
    results.labels = labels;
    results.passivation_applied = logical(options.Passivate);
    results.reference_model = referenceModel;

    results.nominal.sys_raw = nominalRaw;
    results.nominal.sys_active = nominalActive;
    results.nominal.sys_pass = [];
    results.nominal.certificate = nominalCertificate;
    if options.Passivate
        results.nominal.sys_pass = nominalActive;
    end

    emptyVertex = struct( ...
        'label','', ...
        'sys_raw',[], ...
        'sys_pass',[], ...
        'sys_active',[], ...
        'C_raw',[], ...
        'C_pass',[], ...
        'C_active',[], ...
        'fit_nrmse',NaN, ...
        'passivation_info',[], ...
        'certificate',[]);
    results.vertices = repmat(emptyVertex,nRuns,1);

    for i = 1:nRuns
        results.vertices(i).label = labels{i};
        results.vertices(i).sys_raw = rawModels{i};
        results.vertices(i).sys_active = activeModels{i};
        results.vertices(i).C_raw = Craw(i,:);
        results.vertices(i).C_active = Cactive(i,:);
        results.vertices(i).fit_nrmse = fitNRMSE(i);
        results.vertices(i).passivation_info = passivationInfo{i};
        results.vertices(i).certificate = certificates{i};
        if options.Passivate
            results.vertices(i).sys_pass = activeModels{i};
            results.vertices(i).C_pass = Cactive(i,:);
        end
    end

    results.polytope.A = A;
    results.polytope.B = B;
    results.polytope.C_raw = Craw;
    results.polytope.C_active = Cactive;
    results.polytope.D = D;
    results.polytope.passivation_weights = selectedWeights;

    results.responses.frequency = w;
    results.responses.experimental = Gexperimental;
    results.responses.experimental_nominal = GnominalExperimental;
    results.responses.raw_vertices = rawResponses;
    results.responses.vertices = Gactive;
    results.responses.vertex_phase = unwrap(angle(Gactive),[],1);
    results.freq = w;
    results.out = out;
    results.sys_BEM = load_optional_bem(baseDir,options.BEMFile);

    % Wide-band passivity indicators are retained for compatibility with
    % the WNSS plotting routine, irrespective of whether passivation is used.
    results.diagnostics = build_diagnostics( ...
        A,rawModels,activeModels,nominalRaw,nominalActive,labels);

    %% Pointwise min/max targets and dynamically consistent models
    if options.FitBoundaryModels
        fprintf('[4] Constructing and fitting min/max boundary models...\n');
        results = fit_boundary_models(results,logical(options.Passivate));
    else
        results.min = [];
        results.max = [];
        results.boundaries = [];
    end

    fprintf('\nIdentification completed successfully for %d runs.\n',nRuns);
end

%% =====================================================================
% Boundary models
% ======================================================================
function results = fit_boundary_models(results,passivate)

    A = results.polytope.A;
    B = results.polytope.B;
    w = results.responses.frequency(:);
    Gvertices = results.responses.vertices;

    magnitude = abs(Gvertices);
    phase = unwrap(angle(Gvertices),[],1);
    magnitudeLower = min(magnitude,[],2);
    magnitudeUpper = max(magnitude,[],2);
    phaseLower = min(phase,[],2);
    phaseUpper = max(phase,[],2);

    GminimumTarget = magnitudeLower.*exp(1i*phaseLower);
    GmaximumTarget = magnitudeUpper.*exp(1i*phaseUpper);

    if passivate
        [Cminimum,Pminimum,minimumInfo] = ...
            fit_passive_output_matrix_D0(A,B,w,GminimumTarget, ...
                'SolverOrder',{'sedumi'}, ...
                'EpsilonP',1e-8, ...
                'FeasibilityTolerance',1e-6, ...
                'PRegularisation',1e-10, ...
                'Verbose',1);
        [Cmaximum,Pmaximum,maximumInfo] = ...
            fit_passive_output_matrix_D0(A,B,w,GmaximumTarget, ...
                'SolverOrder',{'sedumi'}, ...
                'EpsilonP',1e-8, ...
                'FeasibilityTolerance',1e-6, ...
                'PRegularisation',1e-10, ...
                'Verbose',1);
    else
        Phi = frequency_regression_matrix(A,B,w);
        Cminimum = fit_output_matrix(Phi,GminimumTarget);
        Cmaximum = fit_output_matrix(Phi,GmaximumTarget);
        Pminimum = [];
        Pmaximum = [];
        minimumInfo = struct('method','real-valued least squares');
        maximumInfo = struct('method','real-valued least squares');
    end

    sysMinimum = ss(A,B,Cminimum,0);
    sysMaximum = ss(A,B,Cmaximum,0);
    assert_minimal(sysMinimum,'Minimum boundary');
    assert_minimal(sysMaximum,'Maximum boundary');

    minimumCertificate = [];
    maximumCertificate = [];
    if passivate
        % The passive fitting routine already returns storage matrices.
        % Verify those matrices directly instead of solving the same KYP
        % feasibility problem a second time.
        minimumCertificate = verify_passivity_certificate_D0( ...
            A,B,Cminimum,Pminimum,1e-6, ...
            'Verified from the minimum-boundary fitting certificate');
        maximumCertificate = verify_passivity_certificate_D0( ...
            A,B,Cmaximum,Pmaximum,1e-6, ...
            'Verified from the maximum-boundary fitting certificate');
        if ~minimumCertificate.certified || ~maximumCertificate.certified
            error('run_identification:BoundaryPassivityFailure', ...
                'A boundary model failed the independent passivity test.');
        end
    end

    GminimumFit = squeeze(freqresp(sysMinimum,w));
    GmaximumFit = squeeze(freqresp(sysMaximum,w));

    results.min = boundary_structure( ...
        'Min',sysMinimum,Cminimum,Pminimum,GminimumTarget, ...
        GminimumFit,minimumInfo,minimumCertificate,passivate);
    results.max = boundary_structure( ...
        'Max',sysMaximum,Cmaximum,Pmaximum,GmaximumTarget, ...
        GmaximumFit,maximumInfo,maximumCertificate,passivate);

    results.boundaries.frequency = w;
    results.boundaries.magnitude_lower = magnitudeLower;
    results.boundaries.magnitude_upper = magnitudeUpper;
    results.boundaries.phase_lower = phaseLower;
    results.boundaries.phase_upper = phaseUpper;
    results.boundaries.minimum_target = GminimumTarget;
    results.boundaries.maximum_target = GmaximumTarget;
    results.auxiliary_models = { ...
        results.min.sys_active
        results.nominal.sys_active
        results.max.sys_active};
end

function boundary = boundary_structure( ...
    label,sys,C,P,target,fitted,info,certificate,passivate)

    boundary.label = label;
    boundary.sys = sys;
    boundary.sys_active = sys;
    boundary.sys_pass = [];
    if passivate
        boundary.sys_pass = sys;
    end
    boundary.C = C;
    boundary.P = P;
    boundary.target_response = target;
    boundary.fitted_response = fitted;
    boundary.fit_nrmse = complex_nrmse(target,fitted);
    boundary.identification_info = info;
    boundary.certificate = certificate;
    boundary.verification.stable = isstable(sys);
    boundary.verification.minimal = ...
        order(minreal(sys,1e-8,false))==order(sys);
    boundary.verification.passive = ...
        ~passivate || certificate.certified;
    boundary.verification.accepted = ...
        boundary.verification.stable && ...
        boundary.verification.minimal && ...
        boundary.verification.passive;
end

%% =====================================================================
% Identification helpers
% ======================================================================
function sys = fit_reference_model(G,w,modelOrder)
    valid = isfinite(real(G)) & isfinite(imag(G)) & isfinite(w);
    if nnz(valid)<2*modelOrder+1
        error('run_identification:InsufficientFrequencies', ...
            'Too few valid frequency points for an order-%d fit.',modelOrder);
    end
    response = reshape(G(valid),[1 1 nnz(valid)]);
    data = idfrd(response,w(valid),0);
    fitOptions = ssestOptions( ...
        'EnforceStability',true,'Focus','simulation');
    identifiedModel = ssest(data,modelOrder,fitOptions);
    [A,B,C,~] = ssdata(identifiedModel);
    sys = ss(A,B,C,0);
end

function Phi = frequency_regression_matrix(A,B,w)
    n = size(A,1);
    Phi = zeros(numel(w),n);
    identityMatrix = eye(n);
    for k = 1:numel(w)
        Phi(k,:) = ((1i*w(k)*identityMatrix-A)\B).';
    end
end

function C = fit_output_matrix(Phi,G)
    valid = all(isfinite(real(Phi)),2) & ...
        all(isfinite(imag(Phi)),2) & ...
        isfinite(real(G)) & isfinite(imag(G));
    X = [real(Phi(valid,:));imag(Phi(valid,:))];
    target = [real(G(valid));imag(G(valid))];
    if rank(X)<size(X,2)
        warning('run_identification:RankDeficientRegression', ...
            'The output-matrix regression is rank deficient.');
    end
    C = (X\target).';
end

function value = complex_nrmse(reference,estimate)
    valid = isfinite(real(reference)) & isfinite(imag(reference)) & ...
        isfinite(real(estimate)) & isfinite(imag(estimate));
    reference = reference(valid);
    estimate = estimate(valid);
    denominator = norm(reference-mean(reference),2);
    if denominator<=eps
        value = NaN;
    else
        value = 1-norm(reference-estimate,2)/denominator;
    end
end

function assert_minimal(sys,label)
    [A,B,C,~] = ssdata(sys);
    n = size(A,1);
    if rank(ctrb(A,B))<n || rank(obsv(A,C))<n
        error('run_identification:NonminimalModel', ...
            'The model %s is not a minimal realisation.',label);
    end
end

function certificate = certify_passivity_D0(A,B,C)
    if exist('sdpvar','file')~=2
        error('run_identification:YALMIPNotFound', ...
            'YALMIP is required when Passivate is true.');
    end
    n = size(A,1);
    P = sdpvar(n,n,'symmetric');
    constraints = [ ...
        P >= 1e-9*eye(n), ...
        P*A+A'*P <= 0, ...
        P*B == C'];
    diagnostics = optimize( ...
        constraints,[],sdpsettings('solver','sedumi','verbose',0));
    certificate.certified = false;
    certificate.solver_status = diagnostics.info;
    certificate.P = [];
    certificate.equality_residual = Inf;
    Pvalue = value(P);

    % Solver warnings alone do not prove infeasibility. Accept a finite
    % candidate only after checking the KYP relations explicitly below.
    if isempty(Pvalue) || any(~isfinite(Pvalue(:)))
        return;
    end

    Pvalue = (Pvalue+Pvalue')/2;
    equalityResidual = norm(Pvalue*B-C',2);
    minimumEigenvalueP = min(real(eig((Pvalue+Pvalue')/2)));
    L = Pvalue*A+A'*Pvalue;
    maximumEigenvalueL = max(real(eig((L+L')/2)));
    certificate.certified = equalityResidual<=1e-7 && ...
        minimumEigenvalueP>=-1e-7 && maximumEigenvalueL<=1e-7;
    certificate.P = Pvalue;
    certificate.equality_residual = equalityResidual;
    certificate.minimum_eigenvalue_P = minimumEigenvalueP;
    certificate.maximum_eigenvalue_Lyapunov = maximumEigenvalueL;
end

function certificate = verify_passivity_certificate_D0( ...
    A,B,C,P,tolerance,statusText)

    if nargin<5 || isempty(tolerance)
        tolerance = 1e-7;
    end
    if nargin<6 || isempty(statusText)
        statusText = 'Explicit verification of a supplied KYP certificate';
    end

    certificate.certified = false;
    certificate.solver_status = statusText;
    certificate.P = [];
    certificate.equality_residual = Inf;
    certificate.minimum_eigenvalue_P = -Inf;
    certificate.maximum_eigenvalue_Lyapunov = Inf;

    if isempty(P) || any(~isfinite(P(:)))
        return;
    end

    P = (P+P')/2;
    lyapunovMatrix = P*A+A'*P;
    lyapunovMatrix = (lyapunovMatrix+lyapunovMatrix')/2;

    equalityResidual = norm(P*B-C',2);
    minimumEigenvalueP = min(real(eig(P)));
    maximumEigenvalueLyapunov = max(real(eig(lyapunovMatrix)));

    scaleP = max(1,norm(P,2));
    scaleLyapunov = max(1,norm(lyapunovMatrix,2));
    scaleEquality = max([1,norm(P*B,2),norm(C,2)]);

    certificate.certified = ...
        equalityResidual <= tolerance*scaleEquality && ...
        minimumEigenvalueP >= -tolerance*scaleP && ...
        maximumEigenvalueLyapunov <= tolerance*scaleLyapunov;

    certificate.P = P;
    certificate.equality_residual = equalityResidual;
    certificate.minimum_eigenvalue_P = minimumEigenvalueP;
    certificate.maximum_eigenvalue_Lyapunov = maximumEigenvalueLyapunov;
end

function diagnostics = build_diagnostics( ...
    A,rawModels,activeModels,nominalRaw,nominalActive,labels)

    poleMagnitudes = abs(eig(A));
    poleMagnitudes = poleMagnitudes(poleMagnitudes>0 & isfinite(poleMagnitudes));
    if isempty(poleMagnitudes)
        minimumFrequency = 1e-6;
        maximumFrequency = 1e3;
    else
        minimumFrequency = max(1e-6,min(poleMagnitudes)*1e-4);
        maximumFrequency = max(1e3,max(poleMagnitudes)*1e4);
    end

    wCheck = logspace( ...
        log10(minimumFrequency),log10(maximumFrequency),6000).';
    rawModelsForCheck = [rawModels;{nominalRaw}];
    activeModelsForCheck = [activeModels;{nominalActive}];
    verificationLabels = [labels(:);{'Nominal'}];
    nModels = numel(verificationLabels);
    passivityRaw = zeros(numel(wCheck),nModels);
    passivityActive = zeros(numel(wCheck),nModels);

    for i = 1:nModels
        rawResponse = squeeze(freqresp(rawModelsForCheck{i},wCheck));
        activeResponse = squeeze(freqresp(activeModelsForCheck{i},wCheck));
        passivityRaw(:,i) = 2*real(rawResponse(:));
        passivityActive(:,i) = 2*real(activeResponse(:));
    end

    diagnostics.wide_frequency_grid = wCheck;
    diagnostics.passivity_raw = passivityRaw;
    diagnostics.passivity_pass = passivityActive;
    diagnostics.verification_labels = verificationLabels;
    diagnostics.minimum_passivity_indicator = min(passivityActive,[],1).';
end

%% =====================================================================
% Experimental H1 frequency-response estimation
% ======================================================================
function out = estimate_experimental_frfs(runs,options)

    nRuns = numel(runs);
    raw = repmat(struct( ...
        'label','', ...
        'w_raw',[], ...
        'G_raw',[], ...
        'coherence_raw',[], ...
        'valid_raw',[], ...
        'Fs',[], ...
        'segment_length',[], ...
        'overlap_samples',[], ...
        'NFFT',[], ...
        'input',[], ...
        'output',[], ...
        'time',[]),nRuns,1);

    for i = 1:nRuns
        [u,y,t,fs] = load_run_signals(runs(i),options.Fs);
        N = numel(u);

        if isempty(options.SegmentLength)
            segmentLength = max(256,round(N/8));
        else
            segmentLength = round(options.SegmentLength);
        end
        if segmentLength>N
            error('run_identification:SegmentTooLong', ...
                ['SegmentLength (%d) exceeds the number of samples (%d) ', ...
                 'in run %s.'],segmentLength,N,runs(i).label);
        end

        overlapSamples = round(options.Overlap*segmentLength);
        if isempty(options.NFFT)
            nfft = 2^nextpow2(segmentLength);
        else
            nfft = round(options.NFFT);
        end
        if nfft<segmentLength
            error('run_identification:NFFTTooShort', ...
                'NFFT must be greater than or equal to SegmentLength.');
        end

        window = hann(segmentLength,'periodic');
        [G,f] = tfestimate( ...
            u,y,window,overlapSamples,nfft,fs);
        coherence = mscohere( ...
            u,y,window,overlapSamples,nfft,fs);
        w = 2*pi*f(:);
        G = G(:);
        coherence = coherence(:);

        valid = w>=options.Band(1) & w<=options.Band(2) & ...
            coherence>=options.CoherenceThreshold & ...
            isfinite(real(G)) & isfinite(imag(G));

        if nnz(valid)<max(10,2*options.ModelOrder+1)
            error('run_identification:InsufficientValidFrequencies', ...
                ['Run %s contains only %d valid frequency points. ', ...
                 'Review Band and CoherenceThreshold.'], ...
                runs(i).label,nnz(valid));
        end

        raw(i).label = runs(i).label;
        raw(i).w_raw = w;
        raw(i).G_raw = G;
        raw(i).coherence_raw = coherence;
        raw(i).valid_raw = valid;
        raw(i).Fs = fs;
        raw(i).segment_length = segmentLength;
        raw(i).overlap_samples = overlapSamples;
        raw(i).NFFT = nfft;
        raw(i).input = u;
        raw(i).output = y;
        raw(i).time = t;
    end

    % Use valid frequencies from the first run inside the common supported
    % interval. Other responses are interpolated only within their valid
    % frequency support; extrapolation is never allowed.
    lowerCommon = -Inf;
    upperCommon = Inf;
    for i = 1:nRuns
        wi = raw(i).w_raw(raw(i).valid_raw);
        lowerCommon = max(lowerCommon,min(wi));
        upperCommon = min(upperCommon,max(wi));
    end
    if lowerCommon>=upperCommon
        error('run_identification:NoCommonFrequencyBand', ...
            'The experimental runs have no common valid frequency band.');
    end

    firstW = raw(1).w_raw(raw(1).valid_raw);
    wCommon = firstW(firstW>=lowerCommon & firstW<=upperCommon);
    if numel(wCommon)<max(10,2*options.ModelOrder+1)
        error('run_identification:CommonGridTooShort', ...
            'The common frequency grid contains too few points.');
    end

    Gmatrix = NaN(numel(wCommon),nRuns);
    coherenceMatrix = NaN(numel(wCommon),nRuns);
    aligned = repmat(struct( ...
        'label','', 'w',[], 'G',[], 'coherence',[], 'coh',[], ...
        'w_raw',[], 'G_raw',[], 'coherence_raw',[], 'coh_raw',[], ...
        'mask_raw',[], 'Fs',[], 'segment_length',[], ...
        'overlap_samples',[], 'NFFT',[], ...
        'input',[], 'output',[], 'time',[], ...
        'fileT2','', 'fileT3',''),nRuns,1);

    for i = 1:nRuns
        wi = raw(i).w_raw(raw(i).valid_raw);
        Gi = raw(i).G_raw(raw(i).valid_raw);
        ci = raw(i).coherence_raw(raw(i).valid_raw);
        [wi,uniqueIndices] = unique(wi,'stable');
        Gi = Gi(uniqueIndices);
        ci = ci(uniqueIndices);

        Gmatrix(:,i) = interp1(wi,real(Gi),wCommon,'linear',NaN) + ...
            1i*interp1(wi,imag(Gi),wCommon,'linear',NaN);
        coherenceMatrix(:,i) = interp1(wi,ci,wCommon,'linear',NaN);

        aligned(i).label = raw(i).label;
        aligned(i).w = wCommon;
        aligned(i).G = Gmatrix(:,i);
        aligned(i).coherence = coherenceMatrix(:,i);
        aligned(i).coh = coherenceMatrix(:,i);
        aligned(i).w_raw = raw(i).w_raw;
        aligned(i).G_raw = raw(i).G_raw;
        aligned(i).coherence_raw = raw(i).coherence_raw;
        aligned(i).coh_raw = raw(i).coherence_raw;
        aligned(i).mask_raw = raw(i).valid_raw;
        aligned(i).Fs = raw(i).Fs;
        aligned(i).segment_length = raw(i).segment_length;
        aligned(i).overlap_samples = raw(i).overlap_samples;
        aligned(i).NFFT = raw(i).NFFT;
        aligned(i).input = raw(i).input;
        aligned(i).output = raw(i).output;
        aligned(i).time = raw(i).time;
        aligned(i).fileT2 = runs(i).inputFile;
        aligned(i).fileT3 = runs(i).outputFile;
    end

    commonFinite = all(isfinite(real(Gmatrix)) & ...
        isfinite(imag(Gmatrix)),2);
    wCommon = wCommon(commonFinite);
    Gmatrix = Gmatrix(commonFinite,:);
    coherenceMatrix = coherenceMatrix(commonFinite,:);
    for i = 1:nRuns
        aligned(i).w = wCommon;
        aligned(i).G = Gmatrix(:,i);
        aligned(i).coherence = coherenceMatrix(:,i);
        aligned(i).coh = coherenceMatrix(:,i);
    end

    out.runs = aligned;
    out.nominal.w = wCommon;
    out.nominal.Gmatrix = Gmatrix;
    out.nominal.G = mean(Gmatrix,2,'omitnan');
    out.nominal.Gmin = min(abs(Gmatrix),[],2);
    out.nominal.Gmax = max(abs(Gmatrix),[],2);
    out.opts.InputVar = common_or_cell({runs.inputVar});
    out.opts.OutputVar = common_or_cell({runs.outputVar});
    out.opts.TimeVar = common_or_cell({runs.inputTimeVar});
    out.opts.Fs = options.Fs;
    out.opts.Band = options.Band;
    out.opts.CoherenceThr = options.CoherenceThreshold;
end

function value = common_or_cell(values)
    if numel(unique(values))==1
        value = values{1};
    else
        value = values(:);
    end
end

function [u,y,t,fs] = load_run_signals(run,globalFs)

    inputData = load(run.inputFile,run.inputVar,run.inputTimeVar);
    if strcmp(run.inputFile,run.outputFile)
        outputData = load(run.outputFile,run.outputVar,run.outputTimeVar);
    else
        outputData = load(run.outputFile,run.outputVar,run.outputTimeVar);
    end

    require_loaded_field(inputData,run.inputVar,run.inputFile,run.label);
    require_loaded_field(outputData,run.outputVar,run.outputFile,run.label);
    require_loaded_field(inputData,run.inputTimeVar,run.inputFile,run.label);
    require_loaded_field(outputData,run.outputTimeVar,run.outputFile,run.label);

    u = double(inputData.(run.inputVar));
    y = double(outputData.(run.outputVar));
    tu = double(inputData.(run.inputTimeVar));
    ty = double(outputData.(run.outputTimeVar));

    if ~isvector(u) || ~isvector(y) || ~isvector(tu) || ~isvector(ty)
        error('run_identification:NonvectorSignal', ...
            'Input, output and time must be vectors for run %s.',run.label);
    end

    u = u(:);
    y = y(:);
    tu = tu(:);
    ty = ty(:);

    if numel(u)~=numel(tu) || numel(y)~=numel(ty)
        error('run_identification:TimeLengthMismatch', ...
            'Signal and time-vector lengths differ in run %s.',run.label);
    end
    if any(~isfinite(u)) || any(~isfinite(y)) || ...
            any(~isfinite(tu)) || any(~isfinite(ty))
        error('run_identification:NonfiniteData', ...
            'Run %s contains NaN or Inf values.',run.label);
    end

    dtu = diff(tu);
    dty = diff(ty);
    if any(dtu<=0) || any(dty<=0)
        error('run_identification:NonmonotonicTime', ...
            'Time vectors must be strictly increasing in run %s.',run.label);
    end

    sampleTimeInput = median(dtu);
    sampleTimeOutput = median(dty);
    timeTolerance = 1e-6*max([sampleTimeInput,sampleTimeOutput,1]);
    if max(abs(dtu-sampleTimeInput))>timeTolerance || ...
            max(abs(dty-sampleTimeOutput))>timeTolerance
        error('run_identification:NonuniformSampling', ...
            'Run %s is not uniformly sampled.',run.label);
    end
    if abs(sampleTimeInput-sampleTimeOutput)>timeTolerance
        error('run_identification:SamplingMismatch', ...
            'Input and output sampling intervals differ in run %s.',run.label);
    end

    if ~isempty(globalFs)
        fs = globalFs;
        if abs(fs-1/sampleTimeInput)>1e-4*fs
            error('run_identification:SpecifiedFsMismatch', ...
                ['Specified Fs is inconsistent with the time vector ', ...
                 'in run %s.'],run.label);
        end
    elseif ~isempty(run.Fs)
        fs = run.Fs;
        if abs(fs-1/sampleTimeInput)>1e-4*fs
            error('run_identification:RunFsMismatch', ...
                'Run-specific Fs is inconsistent with run %s.',run.label);
        end
    else
        fs = 1/sampleTimeInput;
    end

    % Align by time if necessary, using the overlapping interval only.
    if numel(tu)==numel(ty) && max(abs(tu-ty))<=timeTolerance
        t = tu;
    else
        initialTime = max(tu(1),ty(1));
        finalTime = min(tu(end),ty(end));
        t = tu(tu>=initialTime & tu<=finalTime);
        u = u(tu>=initialTime & tu<=finalTime);
        y = interp1(ty,y,t,'linear',NaN);
        finite = isfinite(u) & isfinite(y) & isfinite(t);
        u = u(finite);
        y = y(finite);
        t = t(finite);
    end

    u = detrend(u,0);
    y = detrend(y,0);
end

function require_loaded_field(data,fieldName,fileName,label)
    if ~isfield(data,fieldName)
        error('run_identification:VariableNotFound', ...
            'Variable "%s" was not found in %s for run %s.', ...
            fieldName,fileName,label);
    end
end

%% =====================================================================
% Run-definition handling
% ======================================================================
function runs = normalise_run_definitions(inputRuns,baseDir)

    required = {'label','inputVar','outputVar'};
    runs = inputRuns(:);

    for i = 1:numel(runs)
        for j = 1:numel(required)
            fieldName = required{j};
            if ~isfield(runs,fieldName) || ...
                    ~is_text_scalar(runs(i).(fieldName)) || ...
                    isempty(char(runs(i).(fieldName)))
                error('run_identification:MissingRunField', ...
                    'Run %d requires a non-empty field named %s.',i,fieldName);
            end
        end

        hasCommonFile = isfield(runs,'file') && ...
            is_text_scalar(runs(i).file) && ~isempty(char(runs(i).file));
        hasSeparateFiles = isfield(runs,'inputFile') && ...
            isfield(runs,'outputFile') && ...
            is_text_scalar(runs(i).inputFile) && ...
            is_text_scalar(runs(i).outputFile) && ...
            ~isempty(char(runs(i).inputFile)) && ...
            ~isempty(char(runs(i).outputFile));

        if hasCommonFile
            runs(i).inputFile = resolve_file(baseDir,runs(i).file);
            runs(i).outputFile = runs(i).inputFile;
        elseif hasSeparateFiles
            runs(i).inputFile = resolve_file(baseDir,runs(i).inputFile);
            runs(i).outputFile = resolve_file(baseDir,runs(i).outputFile);
        else
            error('run_identification:MissingRunFile', ...
                ['Run %s must define either file or both inputFile ', ...
                 'and outputFile.'],char(runs(i).label));
        end

        hasCommonTime = isfield(runs,'timeVar') && ...
            is_text_scalar(runs(i).timeVar) && ~isempty(char(runs(i).timeVar));
        hasSeparateTime = isfield(runs,'inputTimeVar') && ...
            isfield(runs,'outputTimeVar') && ...
            is_text_scalar(runs(i).inputTimeVar) && ...
            is_text_scalar(runs(i).outputTimeVar) && ...
            ~isempty(char(runs(i).inputTimeVar)) && ...
            ~isempty(char(runs(i).outputTimeVar));

        if hasCommonTime
            runs(i).inputTimeVar = char(runs(i).timeVar);
            runs(i).outputTimeVar = char(runs(i).timeVar);
        elseif ~hasSeparateTime
            error('run_identification:MissingTimeVariable', ...
                ['Run %s must define either timeVar or both ', ...
                 'inputTimeVar and outputTimeVar.'],char(runs(i).label));
        end

        runs(i).label = char(runs(i).label);
        runs(i).inputVar = char(runs(i).inputVar);
        runs(i).outputVar = char(runs(i).outputVar);
        runs(i).inputTimeVar = char(runs(i).inputTimeVar);
        runs(i).outputTimeVar = char(runs(i).outputTimeVar);
        if ~isfield(runs,'Fs') || isempty(runs(i).Fs)
            runs(i).Fs = [];
        elseif ~isnumeric(runs(i).Fs) || ~isscalar(runs(i).Fs) || runs(i).Fs<=0
            error('run_identification:InvalidRunFs', ...
                'Run-specific Fs must be a positive scalar.');
        end
    end

    labels = {runs.label};
    if numel(unique(labels))~=numel(labels)
        error('run_identification:DuplicateLabels', ...
            'Run labels must be unique.');
    end
end

function fileName = resolve_file(baseDir,source)
    source = char(source);
    if isfile(source)
        fileName = source;
    elseif isfile(fullfile(baseDir,source))
        fileName = fullfile(baseDir,source);
    else
        matches = dir(fullfile(baseDir,['*' source '*.mat']));
        if isempty(matches)
            error('run_identification:FileNotFound', ...
                'No MAT file was found for "%s".',source);
        elseif numel(matches)>1
            error('run_identification:AmbiguousFile', ...
                ['More than one MAT file matches "%s". ', ...
                 'Pass the complete filename.'],source);
        end
        fileName = fullfile(matches(1).folder,matches(1).name);
    end
end

function sysBEM = load_optional_bem(baseDir,BEMFile)
    sysBEM = [];
    BEMFile = char(BEMFile);
    if isempty(BEMFile)
        return;
    end
    if ~isfile(BEMFile)
        BEMFile = fullfile(baseDir,BEMFile);
    end
    if ~isfile(BEMFile)
        warning('run_identification:BEMFileNotFound', ...
            'The optional BEM file was not found.');
        return;
    end
    loaded = load(BEMFile,'G_ss');
    if isfield(loaded,'G_ss')
        sysBEM = loaded.G_ss;
    else
        warning('run_identification:BEMVariableNotFound', ...
            'The BEM file does not contain a variable named G_ss.');
    end
end

function print_header(passivate,nRuns)
    fprintf('\n=====================================================\n');
    fprintf(' GENERIC COMMON-BASIS IDENTIFICATION\n');
    fprintf(' Number of experimental runs: %d\n',nRuns);
    fprintf(' Passivation enabled:         %d\n',logical(passivate));
    fprintf('=====================================================\n');
end

function tf = is_text_scalar(value)
    tf = ischar(value) || (isstring(value) && isscalar(value));
end

function tf = is_logical_scalar(value)
    tf = (islogical(value) || isnumeric(value)) && isscalar(value);
end

function tf = is_valid_band(value)
    tf = isnumeric(value) && numel(value)==2 && ...
        value(1)>=0 && value(2)>value(1);
end
