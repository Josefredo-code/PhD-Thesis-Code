function comparison = plot_reactive_H2_comparison(closedLoopResults, options)
%PLOT_REACTIVE_H2_COMPARISON Independent Reactive versus H2 diagnostics.

%% Settings
if nargin < 2 || isempty(options), options = struct(); end
cfg = localOptions(options);
if nargin < 1, closedLoopResults = []; end
source = 'Function input';
if isempty(closedLoopResults)
    if isempty(cfg.ResultsFile) && evalin('base','exist(''closedLoopResults'',''var'') == 1')
        closedLoopResults = evalin('base','closedLoopResults');
        source = 'Base workspace';
    else
        file = cfg.ResultsFile;
        if isempty(file)
            candidates = {'closed_loop_optimal_nominal_saturated_ISS1_ISS6.mat', ...
                'closed_loop_optimal_nominal_saturated_ISS1_ISS3.mat'};
            for k = 1:numel(candidates)
                candidate = fullfile(cfg.DataDirectory,candidates{k});
                if isfile(candidate), file = candidate; break; end
            end
        end
        assert(~isempty(file) && isfile(file), ...
            'Supply closedLoopResults or set options.ResultsFile to the existing MAT file.');
        loaded = load(file,'closedLoopResults');
        assert(isfield(loaded,'closedLoopResults'), ...
            'The MAT file does not contain closedLoopResults: %s',file);
        closedLoopResults = loaded.closedLoopResults;
        source = file;
    end
end
assert(isstruct(closedLoopResults) && isscalar(closedLoopResults) && ...
    isfield(closedLoopResults,'seaStates') && ~isempty(closedLoopResults.seaStates), ...
    'Expected a scalar closedLoopResults structure with nonempty seaStates.');
assert(isfield(closedLoopResults,'configuration'), 'Missing results configuration.');
limits = closedLoopResults.configuration;
limitFields = {'forceLimit_N','velocityLimit_mps','strokeLimit_m'};
for k = 1:numel(limitFields)
    assert(isfield(limits,limitFields{k}), 'Missing configuration.%s.',limitFields{k});
    validateattributes(limits.(limitFields{k}),{'numeric'}, ...
        {'scalar','real','finite','positive'},mfilename,limitFields{k});
end
% strokeLimit_m is the ONE-SIDED relative displacement limit (0.14 m in
% the supplied simulation), not the total 0.280 m actuator stroke.
controllers = {'Reactive','H2'};
styles(1) = struct('colour',[0.55 0.70 0.85],'line','--','name','Reactive');
styles(2) = struct('colour',[0.05 0.30 0.20],'line','-.','name','$H_2$');
allLabels = string({closedLoopResults.seaStates.label});
selected = zeros(1,numel(cfg.SeaStateLabels));
for k = 1:numel(selected)
    idx = find(allLabels == string(cfg.SeaStateLabels{k}));
    assert(numel(idx)==1, 'Expected exactly one result for %s.',cfg.SeaStateLabels{k});
    selected(k) = idx;
    for c = 1:2
        assert(isfield(closedLoopResults.seaStates(idx).controllers,controllers{c}), ...
            'Controller %s is missing in %s.',controllers{c},cfg.SeaStateLabels{k});
    end
end
if cfg.SaveResults || (cfg.MakeFigures && cfg.ExportFigures)
    if ~isfolder(cfg.OutputDirectory), mkdir(cfg.OutputDirectory); end
end
comparison = struct();
comparison.source = source;
comparison.options = cfg;
comparison.originalConfiguration = limits;
comparison.description = 'Independent Reactive versus H2 comparison; positive PTOpower = absorption.';
comparison.geometryInterpretation = [ ...
    'Prescribed Test-2 WP4/WP5 levels and translated top/bottom geometry. ' ...
    'Both-probe events are geometric proxies, not proof of complete wetting/drying of the body. ' ...
    'Energy during events remains a diagnostic of the original simulation.'];
comparison.created = char(datetime('now','Format','yyyy-MM-dd HH:mm:ss'));
comparison.seaStates = struct([]);
energyRows = struct([]); physicalRows = struct([]); geometryRows = struct([]);
pairRows = struct([]); row = 0;

%% Analyse each selected sea state
for k = 1:numel(selected)
    ss = closedLoopResults.seaStates(selected(k));
    t = localVector(ss.time_s,[],[ss.label ' time_s']);
    assert(numel(t)>=2 && all(diff(t)>0), ...
        '%s time_s must contain at least two strictly increasing samples.',ss.label);
    duration = t(end)-t(1);
    result = struct('label',ss.label,'time_s',t);
    if isfield(ss,'excitationTorque_Nm')
        result.excitationTorque_Nm = localVector(ss.excitationTorque_Nm,t,'excitationTorque_Nm');
    else
        result.excitationTorque_Nm = [];
        warning('ReactiveH2:ExcitationUnavailable','No excitationTorque_Nm for %s.',ss.label);
    end
    [eta4,eta5,waveSource] = localWaves(ss,t,k,cfg);
    valid = isfinite(eta4) & isfinite(eta5);
    assert(~any(diff(find(valid))>1), 'Unexpected gap in finite wave coverage for %s.',ss.label);
    hasWaves = nnz(valid)>=2;
    result.localWaveElevationWP4 = eta4;
    result.localWaveElevationWP5 = eta5;
    result.waveSource = waveSource;
    result.waveCoverageMask = valid;
    if hasWaves
        waveDuration = t(find(valid,1,'last'))-t(find(valid,1,'first'));
    else
        waveDuration = 0;
    end
    result.geometryDuration_s = waveDuration;
    if cfg.IncludeGeometryResults && hasWaves && waveDuration < duration*(1-1e-9)
        warning('ReactiveH2:PartialWaveCoverage', ...
            '%s geometry coverage is %.2f%% of the simulation; no waves are extrapolated.', ...
            ss.label,100*waveDuration/duration);
    end
    for c = 1:2
        name = controllers{c};
        data = ss.controllers.(name);
        required = {'angularVelocity','angularPosition','rawForce', ...
            'unsaturatedPTOForce','referenceTorque','appliedPTOTorque', ...
            'PTOvelocity','PTOdisplacement','kinematicJacobian','PTOpower'};
        d = struct();
        for f = 1:numel(required)
            field = required{f};
            assert(isfield(data,field), 'Missing %s for %s / %s.',field,ss.label,name);
            d.(field) = localVector(data.(field),t,[ss.label ' / ' name ' / ' field]);
        end
        forceReconstructed = false;
        if isfield(data,'appliedPTOForce')
            d.appliedPTOForce = localVector(data.appliedPTOForce,t,'appliedPTOForce');
        else
            % Same fallback as closedloopSimulationUpdated; mark provenance.
            d.appliedPTOForce = min(max(d.unsaturatedPTOForce, ...
                -limits.forceLimit_N),limits.forceLimit_N);
            forceReconstructed = true;
            warning('ReactiveH2:ReconstructedForce', ...
                '%s / %s: applied force reconstructed by clipping unsaturatedPTOForce.',ss.label,name);
        end
        if isfield(data,'saturatedCommandForce')
            d.saturatedCommandForce = localVector(data.saturatedCommandForce,t,'saturatedCommandForce');
        else
            d.saturatedCommandForce = min(max(d.rawForce, ...
                -limits.forceLimit_N),limits.forceLimit_N);
        end
        if isfield(data,'PTOequilibriumPosition')
            equilibrium = data.PTOequilibriumPosition;
            validateattributes(equilibrium,{'numeric'},{'scalar','real','finite'});
            equilibriumSource = 'Stored PTOequilibriumPosition';
        else
            equilibrium = d.PTOdisplacement(1);
            equilibriumSource = 'First PTOdisplacement sample; assumes equilibrium initial condition';
        end
        d.PTOequilibriumPosition = equilibrium;
        d.equilibriumSource = equilibriumSource;
        d.relativePTOdisplacement = d.PTOdisplacement-equilibrium;
        d.powerFromForce = d.appliedPTOForce.*d.PTOvelocity;
        d.powerFromTorque = d.appliedPTOTorque.*d.angularVelocity;
        d.accumulatedEnergy = cumtrapz(t,d.PTOpower);
        d.accumulatedPositiveEnergy = cumtrapz(t,max(d.PTOpower,0));
        d.accumulatedReturnedEnergy = cumtrapz(t,max(-d.PTOpower,0));
        % Always reconstruct geometry: no dependency on floaterTopPosition.
        d.floaterVerticalDisplacement = -cfg.ArmLength_m.*( ...
            sin(cfg.EquilibriumAngle_rad+d.angularPosition)-sin(cfg.EquilibriumAngle_rad));
        d.floaterTopPosition = d.floaterVerticalDisplacement+cfg.Freeboard_m;
        d.floaterBottomPosition = d.floaterVerticalDisplacement-cfg.Draft_m;
        d.emergenceMarginWP4 = eta4-d.floaterBottomPosition;
        d.emergenceMarginWP5 = eta5-d.floaterBottomPosition;
        d.submergenceMarginWP4 = d.floaterTopPosition-eta4;
        d.submergenceMarginWP5 = d.floaterTopPosition-eta5;
        d.emergenceMarginConservative = min(d.emergenceMarginWP4,d.emergenceMarginWP5);
        d.submergenceMarginConservative = min(d.submergenceMarginWP4,d.submergenceMarginWP5);
        e4 = valid & d.floaterBottomPosition>=eta4;
        e5 = valid & d.floaterBottomPosition>=eta5;
        s4 = valid & d.floaterTopPosition<=eta4;
        s5 = valid & d.floaterTopPosition<=eta5;
        d.emergedEitherSide = e4 | e5;
        d.emergedBothProbes = e4 & e5;
        d.topBelowEitherSide = s4 | s5;
        d.topBelowBothProbes = s4 & s5;
        d.geometryEvent = d.emergedEitherSide | d.topBelowEitherSide;
        d.geometryAvailable = hasWaves;
        d.appliedForceReconstructed = forceReconstructed;

        %% Energy metrics: full simulation, signed integration
        row = row+1;
        er = struct('SeaState',string(ss.label),'Controller',string(name), ...
            'Duration_s',duration,'NetEnergy_J',trapz(t,d.PTOpower), ...
            'PositiveEnergy_J',trapz(t,max(d.PTOpower,0)), ...
            'ReturnedEnergy_J',trapz(t,max(-d.PTOpower,0)));
        er.AveragePower_W = er.NetEnergy_J/duration;
        er.RMSPower_W = localRMS(t,d.PTOpower);
        er.PeakPositivePower_W = max(d.PTOpower);
        er.MinimumPower_W = min(d.PTOpower);
        er.NegativePowerTime_percent = localPercent(t,d.PTOpower<0);
        er.ReturnedToPositiveEnergy_percent = NaN;
        if er.PositiveEnergy_J>0
            er.ReturnedToPositiveEnergy_percent = 100*er.ReturnedEnergy_J/er.PositiveEnergy_J;
        end
        er.PowerIdentityMaxError_W = max(abs(d.powerFromForce-d.powerFromTorque));
        er.LoggedPowerMaxError_W = max(abs(d.PTOpower-d.powerFromForce));
        if max(er.PowerIdentityMaxError_W,er.LoggedPowerMaxError_W) > ...
                cfg.PowerErrorRelativeTolerance*max(1,max(abs(d.PTOpower)))
            warning('ReactiveH2:PowerIdentity', ...
                '%s / %s: power identity mismatch. Inspect energySummary and signal signs.',ss.label,name);
        end
        if row==1, energyRows = er; else, energyRows(row) = er; end

        %% PTO metrics: actual relative displacement, variable Jacobian
        forceBad = abs(d.appliedPTOForce)>limits.forceLimit_N*(1+1e-9);
        velocityBad = abs(d.PTOvelocity)>limits.velocityLimit_mps*(1+1e-9);
        strokeBad = abs(d.relativePTOdisplacement)>limits.strokeLimit_m*(1+1e-9);
        commandClipped = abs(d.rawForce-d.saturatedCommandForce)>cfg.ForceClippingTolerance_N;
        physicalClipped = abs(d.unsaturatedPTOForce-d.appliedPTOForce)>cfg.ForceClippingTolerance_N;
        pr = struct('SeaState',string(ss.label),'Controller',string(name));
        pr.PeakRawForce_N = max(abs(d.rawForce));
        pr.PeakUnsaturatedPTOForce_N = max(abs(d.unsaturatedPTOForce));
        pr.PeakAppliedPTOForce_N = max(abs(d.appliedPTOForce));
        pr.RMSAppliedPTOForce_N = localRMS(t,d.appliedPTOForce);
        pr.RMSForceTrackingError_N = localRMS(t,d.saturatedCommandForce-d.appliedPTOForce);
        pr.CommandSaturationTime_percent = localPercent(t,commandClipped);
        pr.PhysicalSaturationTime_percent = localPercent(t,physicalClipped);
        pr.PeakVelocity_mps = max(abs(d.PTOvelocity));
        pr.PeakRelativeStroke_m = max(abs(d.relativePTOdisplacement));
        pr.PeakToPeakRelativeStroke_m = max(d.relativePTOdisplacement)-min(d.relativePTOdisplacement);
        pr.PeakAngularPosition_rad = max(abs(d.angularPosition));
        pr.PeakAngularVelocity_radps = max(abs(d.angularVelocity));
        pr.MinimumAbsJacobian_mPerRad = min(abs(d.kinematicJacobian));
        pr.JacobianCrossesOrTouchesZero = min(d.kinematicJacobian)<=0 && max(d.kinematicJacobian)>=0;
        pr.ForceViolationTime_percent = localPercent(t,forceBad);
        pr.VelocityViolationTime_percent = localPercent(t,velocityBad);
        pr.StrokeViolationTime_percent = localPercent(t,strokeBad);
        pr.MaximumStrokeExceedance_m = max(0,pr.PeakRelativeStroke_m-limits.strokeLimit_m);
        pr.MaximumVelocityExceedance_mps = max(0,pr.PeakVelocity_mps-limits.velocityLimit_mps);
        pr.ForceLimitOK = ~any(forceBad);
        pr.VelocityLimitOK = ~any(velocityBad);
        pr.StrokeLimitOK = ~any(strokeBad);
        pr.AllPhysicalLimitsOK = pr.ForceLimitOK && pr.VelocityLimitOK && pr.StrokeLimitOK;
        pr.AppliedForceReconstructed = forceReconstructed;
        if row==1, physicalRows = pr; else, physicalRows(row) = pr; end

        %% Geometry metrics: ONLY the common measured-wave interval
        gr = struct('SeaState',string(ss.label),'Controller',string(name), ...
            'GeometryAvailable',hasWaves,'GeometryDuration_s',waveDuration, ...
            'GeometryCoverage_percent',100*waveDuration/duration, ...
            'MinimumEmergenceMarginWP4_m',NaN,'MinimumEmergenceMarginWP5_m',NaN, ...
            'MinimumSubmergenceMarginWP4_m',NaN,'MinimumSubmergenceMarginWP5_m',NaN, ...
            'EmergenceEitherSideTime_percent',NaN,'EmergenceBothProbesTime_percent',NaN, ...
            'TopBelowEitherSideTime_percent',NaN,'TopBelowBothProbesTime_percent',NaN, ...
            'AnyGeometryEventTime_percent',NaN,'EmergenceEventCount',NaN, ...
            'SubmergenceEventCount',NaN,'LongestEmergenceEvent_s',NaN, ...
            'LongestSubmergenceEvent_s',NaN,'NetEnergyInWaveOverlap_J',NaN, ...
            'NetEnergyDuringGeometryEvents_J',NaN, ...
            'PositiveEnergyDuringGeometryEvents_J',NaN, ...
            'ReturnedEnergyDuringGeometryEvents_J',NaN);
        if hasWaves
            tw = t(valid); pw = d.PTOpower(valid); gw = d.geometryEvent(valid);
            gr.MinimumEmergenceMarginWP4_m = min(d.emergenceMarginWP4(valid));
            gr.MinimumEmergenceMarginWP5_m = min(d.emergenceMarginWP5(valid));
            gr.MinimumSubmergenceMarginWP4_m = min(d.submergenceMarginWP4(valid));
            gr.MinimumSubmergenceMarginWP5_m = min(d.submergenceMarginWP5(valid));
            gr.EmergenceEitherSideTime_percent = localPercent(tw,d.emergedEitherSide(valid));
            gr.EmergenceBothProbesTime_percent = localPercent(tw,d.emergedBothProbes(valid));
            gr.TopBelowEitherSideTime_percent = localPercent(tw,d.topBelowEitherSide(valid));
            gr.TopBelowBothProbesTime_percent = localPercent(tw,d.topBelowBothProbes(valid));
            gr.AnyGeometryEventTime_percent = localPercent(tw,gw);
            [gr.EmergenceEventCount,gr.LongestEmergenceEvent_s] = ...
                localEpisodes(tw,d.emergedEitherSide(valid));
            [gr.SubmergenceEventCount,gr.LongestSubmergenceEvent_s] = ...
                localEpisodes(tw,d.topBelowEitherSide(valid));
            gr.NetEnergyInWaveOverlap_J = trapz(tw,pw);
            gr.NetEnergyDuringGeometryEvents_J = trapz(tw,pw.*double(gw));
            gr.PositiveEnergyDuringGeometryEvents_J = trapz(tw,max(pw,0).*double(gw));
            gr.ReturnedEnergyDuringGeometryEvents_J = trapz(tw,max(-pw,0).*double(gw));
        end
        if row==1, geometryRows = gr; else, geometryRows(row) = gr; end
        d.energyMetrics = er; d.physicalMetrics = pr; d.geometryMetrics = gr;
        result.controllers.(name) = d;
    end
    if k==1, comparison.seaStates = result; else, comparison.seaStates(k) = result; end
    reactive = result.controllers.Reactive.energyMetrics;
    h2 = result.controllers.H2.energyMetrics;
    pair = struct('SeaState',string(ss.label), ...
        'ReactiveNetEnergy_J',reactive.NetEnergy_J,'H2NetEnergy_J',h2.NetEnergy_J, ...
        'H2MinusReactiveEnergy_J',h2.NetEnergy_J-reactive.NetEnergy_J, ...
        'H2RelativeGain_percent',NaN);
    % Only report a relative gain against a positive absorption baseline.
    if reactive.NetEnergy_J>1e-12
        pair.H2RelativeGain_percent = 100*pair.H2MinusReactiveEnergy_J/reactive.NetEnergy_J;
    end
    if k==1, pairRows = pair; else, pairRows(k) = pair; end
end

comparison.energySummary = struct2table(energyRows);
comparison.physicalSummary = struct2table(physicalRows);
comparison.geometrySummary = struct2table(geometryRows);
comparison.pairwiseSummary = struct2table(pairRows);
if cfg.SaveResults
    writetable(comparison.energySummary,fullfile(cfg.OutputDirectory,'reactive_H2_energy_summary.csv'));
    writetable(comparison.physicalSummary,fullfile(cfg.OutputDirectory,'reactive_H2_physical_summary.csv'));
    if cfg.IncludeGeometryResults
        writetable(comparison.geometrySummary,fullfile(cfg.OutputDirectory,'reactive_H2_geometry_summary.csv'));
    end
    writetable(comparison.pairwiseSummary,fullfile(cfg.OutputDirectory,'reactive_H2_pairwise_summary.csv'));
    save(fullfile(cfg.OutputDirectory,'reactive_H2_comparison.mat'),'comparison','-v7.3');
end
% Persist diagnostics before plotting so a graphics/export problem does not
% discard the computed tables and reconstructed geometry.
if cfg.MakeFigures
    for k = 1:numel(comparison.seaStates)
        localSeaStateFigures(comparison.seaStates(k),styles,limits,cfg);
    end
    localSummaryFigure(comparison,styles,limits,cfg);
end
fprintf('\nREACTIVE VERSUS H2: signed energy over each full simulation\n');
disp(comparison.pairwiseSummary);
disp(comparison.energySummary);
fprintf('PHYSICAL LIMITS: actual PTO displacement relative to equilibrium\n');
disp(comparison.physicalSummary);
if cfg.IncludeGeometryResults
    fprintf('GEOMETRY: Test-2 probe overlap; unavailable checks are NaN\n');
    disp(comparison.geometrySummary);
end
if cfg.SaveResults || (cfg.MakeFigures && cfg.ExportFigures)
    fprintf('Outputs: %s\n',cfg.OutputDirectory);
end
end

%% Configuration and input validation
function cfg = localOptions(options)
cfg = struct('DataDirectory',pwd,'ResultsFile','', ...
    'OutputDirectory',fullfile(pwd,'reactive_H2_figures_no_geometry'), ...
    'SeaStateLabels',{{'ISS1','ISS2','ISS3'}}, ...
    'WaveFiles',{{'11_ISS1_1.mat','13_ISS2_1.mat','15_ISS3_1.mat'}}, ...
    'WaveTimeOffsets_s',[0 0 0],'PlotTimeWindow_s',[0 300], ...
    'EquilibriumAngle_rad',0.523,'ArmLength_m',0.412, ...
    'Draft_m',0.110,'Freeboard_m',0.050,'AxesFontSize',16,'LabelFontSize',16, ...
    'LegendFontSize',13,'LineWidth',2.2,'ForceClippingTolerance_N',1e-6, ...
    'PowerErrorRelativeTolerance',1e-3,'MakeFigures',true, ...
    'ExportFigures',true,'SaveResults',true,'FigureVisible','on', ...
    'AllowStoredWaveFallback',false,'IncludeGeometryResults',false, ...
    'FigureWidth_cm',22,'TileHeight_cm',6.6);
assert(isstruct(options) && isscalar(options),'options must be a scalar struct.');
fields = fieldnames(options);
for k = 1:numel(fields)
    assert(isfield(cfg,fields{k}), 'Unknown option: %s.',fields{k});
    cfg.(fields{k}) = options.(fields{k});
end
cfg.SeaStateLabels = cellstr(string(cfg.SeaStateLabels));
cfg.WaveFiles = cellstr(string(cfg.WaveFiles));
assert(~isempty(cfg.SeaStateLabels) && numel(unique(string(cfg.SeaStateLabels)))==numel(cfg.SeaStateLabels), ...
    'SeaStateLabels must be nonempty and unique.');
assert(numel(cfg.SeaStateLabels)==numel(cfg.WaveFiles) && ...
    numel(cfg.SeaStateLabels)==numel(cfg.WaveTimeOffsets_s), ...
    'SeaStateLabels, WaveFiles and WaveTimeOffsets_s must have matching lengths.');
validateattributes(cfg.WaveTimeOffsets_s,{'numeric'},{'vector','real','finite'});
if ~isempty(cfg.PlotTimeWindow_s)
    validateattributes(cfg.PlotTimeWindow_s,{'numeric'},{'vector','numel',2,'real','finite'});
    assert(cfg.PlotTimeWindow_s(2)>cfg.PlotTimeWindow_s(1),'Invalid PlotTimeWindow_s.');
end
positive = {'ArmLength_m','Draft_m','Freeboard_m','AxesFontSize','LabelFontSize','LegendFontSize', ...
    'LineWidth','ForceClippingTolerance_N','PowerErrorRelativeTolerance', ...
    'FigureWidth_cm','TileHeight_cm'};
for k = 1:numel(positive)
    validateattributes(cfg.(positive{k}),{'numeric'},{'scalar','real','finite','positive'});
end
validateattributes(cfg.EquilibriumAngle_rad,{'numeric'},{'scalar','real','finite'});
for flag = {'MakeFigures','ExportFigures','SaveResults','AllowStoredWaveFallback','IncludeGeometryResults'}
    validateattributes(cfg.(flag{1}),{'logical'},{'scalar'});
end
assert(any(strcmp(cfg.FigureVisible,{'on','off'})), 'FigureVisible must be on or off.');
end

function y = localVector(value,t,label)
validateattributes(value,{'numeric','logical'},{'vector','real','finite'},mfilename,label);
y = double(value(:));
if ~isempty(t), assert(numel(y)==numel(t),'Signal length mismatch: %s.',label); end
end

function [eta4,eta5,source] = localWaves(ss,t,k,cfg)
eta4 = nan(size(t)); eta5 = eta4; source = 'Unavailable';
file = cfg.WaveFiles{k};
if ~isempty(file)
    if ~isfile(file), file = fullfile(cfg.DataDirectory,file); end
    if isfile(file)
        w = load(file,'time','waveElevation_WE');
        assert(isfield(w,'time') && isfield(w,'waveElevation_WE'), ...
            'Expected time and waveElevation_WE in %s.',file);
        wt = localVector(w.time,[],'wave file time')+cfg.WaveTimeOffsets_s(k);
        assert(numel(wt)>=2 && all(diff(wt)>0), 'Invalid wave-file time in %s.',file);
        wave = w.waveElevation_WE;
        assert(isnumeric(wave) && isreal(wave) && ismatrix(wave), ...
            'waveElevation_WE must be a real numeric matrix in %s.',file);
        % Supplied SWELL layout: probes in ROWS and time in COLUMNS.
        assert(size(wave,1)>=5 && size(wave,2)==numel(wt), ...
            'Expected probes in rows and one column per time sample in %s.',file);
        wp4 = localVector(wave(4,:),wt,'waveElevation_WE row 4');
        wp5 = localVector(wave(5,:),wt,'waveElevation_WE row 5');
        eta4 = interp1(wt,wp4,t,'linear',NaN);
        eta5 = interp1(wt,wp5,t,'linear',NaN);
        source = file;
        if cfg.IncludeGeometryResults && nnz(isfinite(eta4) & isfinite(eta5))<2
            warning('ReactiveH2:NoWaveOverlap','No usable wave-time overlap for %s.',ss.label);
        end
        return
    end
end
% If raw wave files are unavailable, use a consistent stored pair from
% either controller. Geometry is still recalculated for both controllers.
if cfg.AllowStoredWaveFallback && cfg.WaveTimeOffsets_s(k)==0
    for name = {'Reactive','H2'}
        d = ss.controllers.(name{1});
        if isfield(d,'localWaveElevationWP4') && isfield(d,'localWaveElevationWP5')
            eta4 = localVector(d.localWaveElevationWP4,t,'stored WP4');
            eta5 = localVector(d.localWaveElevationWP5,t,'stored WP5');
            source = ['Stored probes from ' name{1} ' (upstream interpolation retained)'];
            warning('ReactiveH2:StoredWaves', ...
                '%s: using stored WP4/WP5. The supplied upstream check extrapolates; raw coverage cannot be verified.',ss.label);
            return
        end
    end
end
if cfg.IncludeGeometryResults
    warning('ReactiveH2:MissingWaves', ...
        '%s: wave file absent; geometry checks will be unavailable (NaN). Expected %s.', ...
        ss.label,cfg.WaveFiles{k});
end
end

function r = localRMS(t,y)
r = sqrt(trapz(t,y.^2)/(t(end)-t(1)));
end

function p = localPercent(t,mask)
% Time weighting works with nonuniform solver output. Event boundaries are
% approximated midway between samples, consistently with trapz of a mask.
p = 100*trapz(t,double(mask))/(t(end)-t(1));
end

function [count,longest] = localEpisodes(t,mask)
mask = logical(mask(:));
starts = find(diff([false;mask])==1);
ends = find(diff([mask;false])==-1);
count = numel(starts); longest = 0;
if count>0
    edges = [t(1);(t(1:end-1)+t(2:end))/2;t(end)];
    longest = max(edges(ends+1)-edges(starts));
end
end

%% Figure helpers: local styling, no persistent changes to groot defaults
function [fig,layout] = localFigure(label,rows,cfg)
fig = figure('Color','w','Name',label,'Visible',cfg.FigureVisible, ...
    'Units','centimeters','Position',[2 2 cfg.FigureWidth_cm cfg.TileHeight_cm*rows+2]);
layout = tiledlayout(fig,rows,1,'TileSpacing','loose','Padding','loose');
end

function ax = localAxes(layout,label,cfg)
ax = nexttile(layout); hold(ax,'on'); grid(ax,'on'); box(ax,'on');
set(ax,'FontSize',cfg.AxesFontSize,'TickLabelInterpreter','latex','GridAlpha',0.18, ...
    'LabelFontSizeMultiplier',1,'TitleFontSizeMultiplier',1);
ylabel(ax,label,'Interpreter','latex','FontSize',cfg.LabelFontSize);
xlabel(ax,'$t$ [s]','Interpreter','latex','FontSize',cfg.LabelFontSize);
end

function localLine(ax,t,y,style,cfg)
plot(ax,t,y,'Color',style.colour,'LineStyle',style.line, ...
    'LineWidth',cfg.LineWidth,'DisplayName',style.name);
end

function localLegend(ax,cfg)
legend(ax,'Location','best','Interpreter','latex', ...
    'FontSize',cfg.LegendFontSize,'NumColumns',2);
end

function localLimits(ax,limit)
if isfinite(limit)
    yline(ax,limit,':','Color',[0.30 0.30 0.30], ...
        'LineWidth',1.2,'HandleVisibility','off');
    yline(ax,-limit,':','Color',[0.30 0.30 0.30], ...
        'LineWidth',1.2,'HandleVisibility','off');
end
% No fixed ylim: exceedances remain visible.
end

function window = localWindow(t,cfg)
window = [t(1) t(end)];
if ~isempty(cfg.PlotTimeWindow_s)
    proposed = [max(t(1),cfg.PlotTimeWindow_s(1)),min(t(end),cfg.PlotTimeWindow_s(2))];
    if proposed(2)>proposed(1), window = proposed; end
end
end

function localExport(fig,stem,cfg)
% Complete layout calculations before exporting, even with hidden figures.
drawnow;
if cfg.ExportFigures
    exportgraphics(fig,fullfile(cfg.OutputDirectory,[stem '.pdf']),'ContentType','vector');
    exportgraphics(fig,fullfile(cfg.OutputDirectory,[stem '.png']),'Resolution',200);
end
end

function localSeaStateFigures(ss,styles,limits,cfg)
t = ss.time_s; win = localWindow(t,cfg);
names = {'Reactive','H2'}; prefix = [ss.label '_Reactive_H2_'];

% 1. Angular response and applied torque, common axes for both controllers.
[fig,layout] = localFigure([ss.label ' angular response'],3,cfg);
fields = {'angularVelocity','angularPosition','appliedPTOTorque'};
labels = {'$\dot{\theta}_A$ [rad/s]','$\Delta\theta_A$ [rad]','$\tau_{u,\mathrm{PTO}}$ [N m]'};
for f = 1:3
    ax = localAxes(layout,labels{f},cfg);
    for c = 1:2, localLine(ax,t,ss.controllers.(names{c}).(fields{f}),styles(c),cfg); end
    xlim(ax,win); localLegend(ax,cfg);
end
localExport(fig,[prefix 'angular_response'],cfg);

% 2. Excitation and PTO mechanical limits (actual nonlinear kinematics).
[fig,layout] = localFigure([ss.label ' PTO response and limits'],4,cfg);
ax = localAxes(layout,'$\tau_e$ [N m]',cfg);
if ~isempty(ss.excitationTorque_Nm)
    plot(ax,t,ss.excitationTorque_Nm,'Color',[0.30 0.30 0.30],'LineWidth',cfg.LineWidth);
else
    text(ax,0.5,0.5,'Excitation signal unavailable','Units','normalized','HorizontalAlignment','center');
end
xlim(ax,win);
fields = {'PTOvelocity','appliedPTOForce','relativePTOdisplacement'};
labels = {'$v_{\mathrm{PTO}}$ [m/s]','$f_{u,\mathrm{PTO}}$ [N]','$\Delta z_{\mathrm{PTO}}$ [m]'};
bounds = [limits.velocityLimit_mps limits.forceLimit_N limits.strokeLimit_m];
for f = 1:3
    ax = localAxes(layout,labels{f},cfg);
    for c = 1:2, localLine(ax,t,ss.controllers.(names{c}).(fields{f}),styles(c),cfg); end
    localLimits(ax,bounds(f)); xlim(ax,win); localLegend(ax,cfg);
end
localExport(fig,[prefix 'PTO_response_limits'],cfg);

% 3. Force demand, saturated command and force actually applied by PTO.
[fig,layout] = localFigure([ss.label ' PTO force dynamics'],2,cfg);
for c = 1:2
    d = ss.controllers.(names{c}); ax = localAxes(layout,'Force [N]',cfg);
    plot(ax,t,d.rawForce,':','Color',[0.50 0.50 0.50],'LineWidth',1.2,'DisplayName','Raw command');
    plot(ax,t,d.saturatedCommandForce,'--','Color',styles(c).colour, ...
        'LineWidth',cfg.LineWidth,'DisplayName','Saturated command');
    plot(ax,t,d.appliedPTOForce,'-','Color',styles(c).colour, ...
        'LineWidth',cfg.LineWidth,'DisplayName','Applied PTO force');
    title(ax,styles(c).name,'Interpreter','latex');
    localLimits(ax,limits.forceLimit_N); xlim(ax,win); localLegend(ax,cfg);
end
localExport(fig,[prefix 'force_dynamics'],cfg);

% 4. Instantaneous signed power over the selected response window.
[fig,layout] = localFigure([ss.label ' instantaneous PTO power'],1,cfg);
ax = localAxes(layout,'$P_{\mathrm{PTO}}$ [W]',cfg);
for c = 1:2, localLine(ax,t,ss.controllers.(names{c}).PTOpower,styles(c),cfg); end
yline(ax,0,':','HandleVisibility','off'); xlim(ax,win); localLegend(ax,cfg);
localExport(fig,[prefix 'instantaneous_power'],cfg);

% 5. Cumulative energies over the ENTIRE simulation, starting at zero.
[fig,layout] = localFigure([ss.label ' full-record energy'],3,cfg);
fields = {'accumulatedEnergy','accumulatedPositiveEnergy','accumulatedReturnedEnergy'};
labels = {'$E_{\mathrm{net}}$ [J]','$E_{+}$ [J]','$E_{-}$ [J]'};
for f = 1:3
    ax = localAxes(layout,labels{f},cfg);
    for c = 1:2, localLine(ax,t,ss.controllers.(names{c}).(fields{f}),styles(c),cfg); end
    xlim(ax,[t(1) t(end)]); localLegend(ax,cfg);
end
localExport(fig,[prefix 'cumulative_energy'],cfg);

% 6. Variable Jacobian over the full record; singularity risk is visible.
[fig,layout] = localFigure([ss.label ' kinematic Jacobian'],1,cfg);
ax = localAxes(layout,'$J(\theta_A)$ [m/rad]',cfg);
for c = 1:2, localLine(ax,t,ss.controllers.(names{c}).kinematicJacobian,styles(c),cfg); end
yline(ax,0,':','HandleVisibility','off'); xlim(ax,[t(1) t(end)]); localLegend(ax,cfg);
localExport(fig,[prefix 'kinematic_Jacobian'],cfg);

% Raw probe records determine whether these checks are available.
if ~cfg.IncludeGeometryResults || ~ss.controllers.Reactive.geometryAvailable, return; end
% 7. Separate probe records and recalculated floater boundaries.
[fig,layout] = localFigure([ss.label ' WP4 WP5 and floater positions'],2,cfg);
for c = 1:2
    d = ss.controllers.(names{c}); ax = localAxes(layout,'$z$ [m]',cfg);
    plot(ax,t,ss.localWaveElevationWP4,'-','Color',[0.25 0.25 0.25], ...
        'LineWidth',1.3,'DisplayName','WP4');
    plot(ax,t,ss.localWaveElevationWP5,'--','Color',[0.65 0.65 0.65], ...
        'LineWidth',1.3,'DisplayName','WP5');
    plot(ax,t,d.floaterTopPosition,'-','Color',styles(c).colour, ...
        'LineWidth',cfg.LineWidth,'DisplayName','Floater top');
    plot(ax,t,d.floaterBottomPosition,'-.','Color',styles(c).colour, ...
        'LineWidth',cfg.LineWidth,'DisplayName','Floater bottom');
    yline(ax,0,':','HandleVisibility','off'); xlim(ax,win);
    title(ax,styles(c).name,'Interpreter','latex'); localLegend(ax,cfg);
end
localExport(fig,[prefix 'floater_WP4_WP5'],cfg);

% 8. Conservative margins: negative values indicate a boundary event
% at one or both probes. Use full horizon to reveal rare excursions.
[fig,layout] = localFigure([ss.label ' full-record geometry margins'],2,cfg);
fields = {'emergenceMarginConservative','submergenceMarginConservative'};
% Short labels fit vertically; definitions remain in the stored diagnostics.
labels = {'Emergence margin [m]','Submergence margin [m]'};
for f = 1:2
    ax = localAxes(layout,labels{f},cfg);
    for c = 1:2, localLine(ax,t,ss.controllers.(names{c}).(fields{f}),styles(c),cfg); end
    yline(ax,0,':','HandleVisibility','off'); xlim(ax,[t(1) t(end)]); localLegend(ax,cfg);
end
localExport(fig,[prefix 'geometry_margins_full_record'],cfg);
end

function localSummaryFigure(comparison,styles,limits,cfg)
n = numel(comparison.seaStates);
energy = zeros(n,2); velocity = energy; stroke = energy; events = nan(n,2);
for k = 1:n
    for c = 1:2
        name = {'Reactive','H2'};
        d = comparison.seaStates(k).controllers.(name{c});
        energy(k,c) = d.energyMetrics.NetEnergy_J;
        velocity(k,c) = d.physicalMetrics.PeakVelocity_mps/limits.velocityLimit_mps;
        stroke(k,c) = d.physicalMetrics.PeakRelativeStroke_m/limits.strokeLimit_m;
        events(k,c) = d.geometryMetrics.AnyGeometryEventTime_percent;
    end
end
[fig,layout] = localFigure('Reactive versus H2 summary',3+double(cfg.IncludeGeometryResults),cfg);
values = {energy,velocity,stroke};
labels = {'$E_{\mathrm{net}}$ [J]','$v_{\mathrm{pk}}/v_{\mathrm{lim}}$', ...
    '$|\Delta z|_{\mathrm{pk}}/z_{\mathrm{lim}}$'};
if cfg.IncludeGeometryResults
    values{4} = events;
    labels{4} = {'Geometry events','[\% of wave overlap]'};
end
for f = 1:numel(values)
    ax = localAxes(layout,labels{f},cfg);
    barValues = values{f};
    % A 1-by-2 vector otherwise produces one Bar object in MATLAB.
    if n==1, barValues = [barValues;nan(1,2)]; end
    b = bar(ax,barValues,'grouped');
    for c = 1:2, b(c).FaceColor = styles(c).colour; b(c).DisplayName = styles(c).name; end
    ax.XTick = 1:n; ax.XTickLabel = comparison.options.SeaStateLabels;
    xlim(ax,[0.5 n+0.5]);
    xlabel(ax,'Sea state','Interpreter','latex','FontSize',cfg.LabelFontSize);
    localLegend(ax,cfg);
    % Explicit padding prevents bar tops from touching the export boundary.
    finiteValues = values{f}(isfinite(values{f}));
    if ~isempty(finiteValues)
        low = min([0;finiteValues(:)]); high = max([0;finiteValues(:)]);
        if f==2 || f==3, high = max(high,1); end
        if high<=low, high = low+1; end
        span = high-low;
        ylim(ax,[low-0.08*span high+0.12*span]);
    end
    if f==2 || f==3
        yline(ax,1,':','LineWidth',1.2,'HandleVisibility','off');
    elseif f==1
        yline(ax,0,':','HandleVisibility','off');
    elseif all(isnan(events(:)))
        text(ax,0.5,0.5,'Geometry checks unavailable','Units','normalized', ...
            'HorizontalAlignment','center');
    end
end
localExport(fig,'Reactive_H2_summary',cfg);
end
