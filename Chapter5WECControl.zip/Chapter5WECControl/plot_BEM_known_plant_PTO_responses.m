% PLOT_BEM_KNOWN_PLANT_PTO_RESPONSES
% PTO velocity, applied force and power for singleton BEMh synthesis.
% Loads existing results; no synthesis or simulation is performed.

clc;
baseDirectory = pwd;
resultsFile = fullfile(baseDirectory,'known_plant_sensitivity_results.mat');
figureDirectory = fullfile(baseDirectory,'BEM_known_plant_figures');

% Select controllers and time interval for all three figures.
controllerNames = {'Passive','Reactive','H2','Hinf'};
seaStateNames = {'ISS1','ISS2','ISS3'};
plotTimeLimits_s = [40 70]; % Use [] for the full simulation horizon.
exportFigures = true;
axesFontSize = 16;
legendFontSize = 13;
lineWidth = 2.2;

assert(isfile(resultsFile),'Results file not found: %s',resultsFile);
S = load(resultsFile,'knownPlantResults');
assert(isfield(S,'knownPlantResults') && isfield(S.knownPlantResults,'BEM'), ...
    'The file does not contain knownPlantResults.BEM.');
BEMresults = S.knownPlantResults.BEM;
seaStates = BEMresults.closedLoopResults;

% Color palette
blueColors = [0.10 0.20 0.40; 0.25 0.45 0.70; 0.55 0.70 0.85];
greenColors = [0.05 0.30 0.20; 0.20 0.50 0.35; 0.55 0.75 0.60];
controllerStyle.Passive = struct('colour',blueColors(2,:), ...
    'lineStyle','-','displayName','Passive');
controllerStyle.Reactive = struct('colour',blueColors(3,:), ...
    'lineStyle','--','displayName','Reactive');
controllerStyle.H2 = struct('colour',greenColors(1,:), ...
    'lineStyle','-.','displayName','$H_2$');
controllerStyle.Hinf = struct('colour',greenColors(3,:), ...
    'lineStyle',':','displayName','$H_\infty$');

if exportFigures && ~exist(figureDirectory,'dir')
    mkdir(figureDirectory);
end
availableLabels = string({seaStates.label});
figureHandles = gobjects(numel(seaStateNames),1);
controllerTag = strjoin(string(controllerNames),'_');

for seaStateIndex = 1:numel(seaStateNames)
    seaStateName = seaStateNames{seaStateIndex};
    selectedIndex = find(availableLabels==string(seaStateName));
    assert(numel(selectedIndex)==1,'Expected one result for %s.',seaStateName);
    r = seaStates(selectedIndex);
    t = r.time_s(:);
    assert(numel(t)>1 && all(isfinite(t)) && all(diff(t)>0), ...
        'Invalid time vector for %s.',seaStateName);

    if isempty(plotTimeLimits_s)
        timeLimits = [t(1) t(end)];
    else
        assert(numel(plotTimeLimits_s)==2 && ...
            all(isfinite(plotTimeLimits_s)) && diff(plotTimeLimits_s)>0, ...
            'Specify an increasing two-element time interval.');
        timeLimits = [max(t(1),plotTimeLimits_s(1)), ...
            min(t(end),plotTimeLimits_s(2))];
        assert(timeLimits(2)>timeLimits(1), ...
            'Requested interval does not overlap %s.',seaStateName);
    end

    fig = figure('Color','w','Units','centimeters', ...
        'Position',[2 2 26 23],'Name',[seaStateName ' - BEMh PTO responses']);
    figureHandles(seaStateIndex) = fig;
    layout = tiledlayout(fig,3,1,'TileSpacing','compact','Padding','compact');
    signalFields = {'PTOvelocity','appliedPTOForce','PTOpower'};
    signalLabels = { ...
    '$v_{\mathrm{PTO}}$ [m/s]', ...
    '$f_{u,\mathrm{PTO}}$ [N]', ...
    '$P_{\mathrm{PTO}}$ [W]' ...
};
    responseAxes = gobjects(3,1);
    visibleMask = t>=timeLimits(1) & t<=timeLimits(2);
    assert(any(visibleMask),'No samples in the selected interval.');
    for signalIndex = 1:3
        ax = nexttile(layout);
        responseAxes(signalIndex) = ax;
        hold(ax,'on');
        controllerLines = gobjects(numel(controllerNames),1);
        legendLabels = cell(numel(controllerNames),1);
        visibleSignal = [];
        for controllerIndex = 1:numel(controllerNames)
            name = controllerNames{controllerIndex};
            assert(isfield(controllerStyle,name) && isfield(r.controllers,name), ...
                'Missing controller style or result for %s.',name);
            style = controllerStyle.(name);
            values = r.controllers.(name).(signalFields{signalIndex});
            values = values(:);
            assert(numel(values)==numel(t) && all(isfinite(values)), ...
                'Invalid %s for %s / %s.',signalFields{signalIndex},seaStateName,name);
            controllerLines(controllerIndex) = plot(ax,t,values, ...
                'Color',style.colour,'LineStyle',style.lineStyle,'LineWidth',lineWidth);
            legendLabels{controllerIndex} = style.displayName;
            visibleSignal = [visibleSignal; values(visibleMask)]; %#ok<AGROW>
        end
        yline(ax,0,'-','Color',[0.55 0.55 0.55], ...
            'LineWidth',0.8,'HandleVisibility','off');
        xlim(ax,timeLimits);
        signalMin = min(visibleSignal);
        signalMax = max(visibleSignal);
        margin = 0.08*max(signalMax-signalMin,1e-6);
        ylim(ax,[min(signalMin,0)-margin max(signalMax,0)+margin]);
        ylabel(ax,signalLabels{signalIndex},'Interpreter','latex');
        set(ax,'FontSize',axesFontSize,'TickLabelInterpreter','latex', ...
            'Box','on','XGrid','on','YGrid','on','GridAlpha',0.18);
        if signalIndex==1
            %title(ax,[seaStateName ' -- BEMh model'],'Interpreter','latex');
            legend(ax,controllerLines,legendLabels,'Interpreter','latex', ...
                'FontSize',legendFontSize,'Location','northoutside', ...
                'Orientation','horizontal');
        end
        if signalIndex<3
            ax.XTickLabel = [];
        else
            xlabel(ax,'Time [s]','Interpreter','latex');
        end
    end
    linkaxes(responseAxes,'x');

    if exportFigures
        if isempty(plotTimeLimits_s)
            intervalTag = 'full_horizon';
        else
            intervalTag = sprintf('t_%g_%g_s',timeLimits(1),timeLimits(2));
        end
        figureBase = fullfile(figureDirectory, ...
            [seaStateName '_BEM_known_plant_PTO_responses_' ...
             char(controllerTag) '_' intervalTag]);
        exportgraphics(fig,[figureBase '.pdf'],'ContentType','vector');
        exportgraphics(fig,[figureBase '.png'],'Resolution',300);
    end
end
fprintf('\nBEMh net PTO energy [J]:\n');
disp(BEMresults.energyTable);
if exportFigures
    fprintf('Figures exported to:\n%s\n',figureDirectory);
end

% Full-horizon physical diagnostics, independent of the plotted interval.
T = BEMresults.summary;
selected = ismember(string(T.SeaState),string(seaStateNames)) & ...
    ismember(string(T.Controller),string(controllerNames));
BEMphysicalReport = T(selected,{'SeaState','Controller','PeakForce_N', ...
    'PeakVelocity_mps','PeakStroke_m','MinimumStrokeMargin_m', ...
    'ForceLimitOK','VelocityLimitOK','StrokeLimitOK','AllLimitsOK'});
fprintf('\nBEMh physical limits: full simulation horizons\n');
disp(BEMphysicalReport);
fprintf('Cases with at least one physical-limit violation:\n');
disp(BEMphysicalReport(~BEMphysicalReport.AllLimitsOK,:));
fprintf(['The stored diagnostics use force +/-200 N, velocity 2.5 m/s, ' ...
    'and stroke +/-0.14 m. They are simulation checks, not constraint guarantees.\n']);
if exportFigures
    writetable(BEMresults.energyTable, ...
        fullfile(figureDirectory,'BEM_known_plant_energy.csv'));
    writetable(BEMphysicalReport, ...
        fullfile(figureDirectory,'BEM_known_plant_physical_limits.csv'));
end


load('known_plant_sensitivity_results.mat','knownPlantResults');

seaStates = knownPlantResults.BEM.closedLoopResults;
controllers = {'Passive','Reactive','H2','Hinf'};
forceLimit_N = 200;
records = struct([]);
row = 0;

for ss = 1:numel(seaStates)

    t = seaStates(ss).time_s(:);
    duration_s = t(end)-t(1);

    for c = 1:numel(controllers)

        name = controllers{c};
        f = seaStates(ss).controllers.(name).appliedPTOForce(:);

        % Applied force at the saturation boundary.
        atLimit = abs(f)>=forceLimit_N-1e-3;

        % Actual exceedance, allowing numerical tolerance.
        violation = abs(f)>forceLimit_N+1e-3;

        row = row+1;
        records(row).SeaState = string(seaStates(ss).label);
        records(row).Controller = string(name);
        records(row).PeakAppliedForce_N = max(abs(f));
        records(row).AppliedForceAtLimit_s = ...
            trapz(t,double(atLimit));
        records(row).AppliedForceAtLimit_percent = ...
            100*records(row).AppliedForceAtLimit_s/duration_s;
        records(row).AppliedForceViolation_s = ...
            trapz(t,double(violation));
        records(row).AppliedForceViolation_percent = ...
            100*records(row).AppliedForceViolation_s/duration_s;
        records(row).MaximumForceExceedance_N = ...
            max(0,max(abs(f))-forceLimit_N);
    end
end

BEMforceReport = struct2table(records);
disp(BEMforceReport);

load('known_plant_sensitivity_results.mat','knownPlantResults');

% Parâmetros, bounds e ganhos dos controladores H2 e Hinf
disp(knownPlantResults.BEM.bestH2);
disp(knownPlantResults.BEM.bestHinf);

% Ganhos passivos e reativos para ISS1--ISS3
disp(knownPlantResults.BEM.IM_gain_table);