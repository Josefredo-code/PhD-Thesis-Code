function [C,P,info] = fit_passive_output_matrix_D0( ...
    A,B,w,G,varargin)
%==========================================================================
% FIT_PASSIVE_OUTPUT_MATRIX_D0
%
% Directly identifies the output matrix C of
%
%   G(s) = C(sI-A)^(-1)B,     D = 0,
%
% while enforcing passivity during identification through the KYP
% conditions
%
%   P > 0,
%   PA + A'P <= 0,
%   PB = C'.
%
% The matrices A and B are fixed. The variables C and P are jointly
% estimated by minimising the complex frequency-domain least-squares error.
%
% Usage:
%   [C,P,info] = fit_passive_output_matrix_D0(A,B,w,G);
%   [C,P,info] = fit_passive_output_matrix_D0( ...
%       A,B,w,G,'SolverOrder',{'sedumi'});
%==========================================================================

    parser = inputParser;

    parser.addParameter( ...
        'SolverOrder',{'sedumi'}, ...
        @(x) iscell(x) || isstring(x));

    parser.addParameter( ...
        'EpsilonP',1e-8, ...
        @(x) isnumeric(x) && isscalar(x) && x>0);

    parser.addParameter( ...
        'FeasibilityTolerance',1e-6, ...
        @(x) isnumeric(x) && isscalar(x) && x>0);

    parser.addParameter( ...
        'PRegularisation',1e-10, ...
        @(x) isnumeric(x) && isscalar(x) && x>=0);

    parser.addParameter( ...
        'Verbose',1, ...
        @(x) isnumeric(x) && isscalar(x));

    parser.parse(varargin{:});
    options = parser.Results;

    solverOrder = cellstr(options.SolverOrder);

    %% Input checks

    A = double(A);
    B = double(B);
    w = double(w(:));
    G = double(G(:));

    n = size(A,1);

    if size(A,2)~=n
        error('A must be square.');
    end

    if size(B,1)~=n || size(B,2)~=1
        error('B must be an n-by-1 vector.');
    end

    if numel(w)~=numel(G)
        error('w and G must have the same number of samples.');
    end

    if any(real(eig(A))>=0)
        error('A must be asymptotically stable.');
    end

    valid = ...
        isfinite(w) & ...
        isfinite(real(G)) & ...
        isfinite(imag(G));

    w = w(valid);
    G = G(valid);

    if isempty(w)
        error('No finite frequency-response samples were provided.');
    end

    %% Frequency-domain regression matrix

    Phi = zeros(numel(w),n);
    identityMatrix = eye(n);

    for k = 1:numel(w)
        Phi(k,:) = ...
            ((1i*w(k)*identityMatrix-A)\B).';
    end

    regressionMatrix = [
        real(Phi)
        imag(Phi)
    ];

    regressionOutput = [
        real(G)
        imag(G)
    ];

    outputScale = max(norm(regressionOutput,2),eps);

    regressionMatrix = regressionMatrix/outputScale;
    regressionOutput = regressionOutput/outputScale;

    %% Passive identification problem

    Cvariable = sdpvar(1,n,'full');
    Pvariable = sdpvar(n,n,'symmetric');
    residualBound = sdpvar(1,1);

    residual = ...
        regressionMatrix*Cvariable' - regressionOutput;

    constraints = [
        Pvariable >= options.EpsilonP*eye(n)
        Pvariable*A + A'*Pvariable <= 0
        Pvariable*B == Cvariable'
        cone(residual,residualBound)
        residualBound >= 0
    ];

    objective = ...
        residualBound + ...
        options.PRegularisation*trace(Pvariable);

    %% Solver attempts and explicit candidate verification

    accepted = false;
    selectedSolver = '';
    selectedDiagnostic = [];
    selectedMetrics = struct();
    Ccandidate = [];
    Pcandidate = [];

    for solverIndex = 1:numel(solverOrder)
        solverName = char(solverOrder{solverIndex});

        fprintf( ...
            '\nAttempting passive identification with %s...\n', ...
            upper(solverName));

        solverOptions = sdpsettings( ...
            'solver',solverName, ...
            'verbose',options.Verbose);

        try
            diagnostic = optimize( ...
                constraints,objective,solverOptions);
        catch solverException
            fprintf( ...
                '   Solver call failed: %s\n', ...
                solverException.message);
            continue;
        end

        currentC = value(Cvariable);
        currentP = value(Pvariable);

        if isempty(currentC) || isempty(currentP) || ...
                any(~isfinite(currentC(:))) || ...
                any(~isfinite(currentP(:)))

            fprintf( ...
                '   %s did not return a finite candidate.\n', ...
                upper(solverName));
            continue;
        end

        metrics = verify_candidate( ...
            A,B,currentC,currentP, ...
            options.EpsilonP, ...
            options.FeasibilityTolerance);

        fprintf('   Solver status: %s\n',diagnostic.info);
        fprintf('   min eig(P):          %.6e\n',metrics.minEigP);
        fprintf('   max eig(PA+A''P):    %.6e\n',metrics.maxEigLyapunov);
        fprintf('   ||PB-C''||_2:         %.6e\n',metrics.equalityResidual);

        if metrics.accepted
            accepted = true;
            selectedSolver = solverName;
            selectedDiagnostic = diagnostic;
            selectedMetrics = metrics;
            Ccandidate = currentC;
            Pcandidate = currentP;
            break;
        end

        fprintf( ...
            '   Candidate rejected by the explicit KYP checks.\n');
    end

    if ~accepted
        error( ...
            ['Passive identification failed: no solver returned a ', ...
             'candidate satisfying the KYP constraints within tolerance.']);
    end

    C = Ccandidate;
    P = Pcandidate;

    %% Fit metrics on the original complex frequency response

    Gestimated = Phi*C';

    residualNorm = norm(G-Gestimated,2);
    referenceNorm = norm(G-mean(G),2);

    if referenceNorm<=eps
        nrmse = NaN;
    else
        nrmse = residualNorm/referenceNorm;
    end

    relativeError = residualNorm/max(norm(G,2),eps);

    info.solver = selectedSolver;
    info.diagnostic = selectedDiagnostic;
    info.kyp = selectedMetrics;
    info.objective = value(objective);
    info.residual_bound = value(residualBound);
    info.nrmse = nrmse;
    info.relative_error = relativeError;
    info.frequency = w;
    info.measured_response = G;
    info.estimated_response = Gestimated;
    info.passive = true;

    fprintf('\n=== Direct passive identification accepted ===\n');
    fprintf('Selected solver: %s\n',upper(selectedSolver));
    fprintf('NRMSE:            %.6e\n',nrmse);
    fprintf('Relative error:   %.6e\n',relativeError);
end

%% =====================================================================
% Explicit KYP verification
% ======================================================================

function metrics = verify_candidate( ...
    A,B,C,P,epsilonP,tolerance)

    P = (P+P')/2;
    lyapunovMatrix = P*A+A'*P;
    lyapunovMatrix = (lyapunovMatrix+lyapunovMatrix')/2;

    metrics.minEigP = min(real(eig(P)));
    metrics.maxEigLyapunov = ...
        max(real(eig(lyapunovMatrix)));
    metrics.equalityResidual = norm(P*B-C',2);

    metrics.accepted = ...
        metrics.minEigP >= epsilonP-tolerance && ...
        metrics.maxEigLyapunov <= tolerance && ...
        metrics.equalityResidual <= tolerance;
end
